package com.automans.mobile

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * The player aims with his own finger on the attack stick. The moment the white aim line touches an enemy's
 * hitbox ring, the helper moves the finger's aim to where that enemy is going to be and lets go: one shot.
 */
class ManualAssist {
    private var touchSinceMs = 0L
    private var touchedSlot = -1
    private var lastFireMs = 0L
    private var lastLogMs = 0L

    @Synchronized fun frame(
        d: AimDecision?, w: Int, h: Int, s: DodgeSettings, now: Long,
        originX: Float, originY: Float, lobbed: Boolean, rangePx: Float, ammo: Int = -1,
    ) {
        if (!ShellTouch.ready || d == null || w < 100 || h < 100) { touchedSlot = -1; return }
        if (ammo == 0) { touchedSlot = -1; return } // out of shots: nothing to fire
        val minDim = min(w, h).toFloat()
        val radius = minDim * s.attackRadiusPct.coerceIn(0.04f, 0.14f)
        val bx = w * s.attackX.coerceIn(0.65f, 0.97f)
        val by = h * s.attackY.coerceIn(0.55f, 0.95f)
        val f = ShellTouch.attackFinger(bx, by, radius) ?: run { touchedSlot = -1; return }
        if (now - lastFireMs < 300L) return

        val vx = (f[1] - bx).toFloat()
        val vy = (f[2] - by).toFloat()
        val mag = hypot(vx, vy)
        if (mag < radius * 0.30f) { touchedSlot = -1; return } // still in the dead centre: not aiming yet
        val ux = vx / mag
        val uy = vy / mag
        val lineLen = (if (lobbed) rangePx * (mag / radius).coerceAtMost(1f) else rangePx).coerceAtLeast(minDim * 0.25f)
        val hitR = minDim * 0.055f

        // every known enemy: current spot and predicted spot
        var bestPerp = Float.MAX_VALUE
        var px = 0f
        var py = 0f
        fun consider(ex: Float, ey: Float, nx: Float, ny: Float) {
            val rx = ex - originX
            val ry = ey - originY
            val along = rx * ux + ry * uy
            if (along < 0f || along > lineLen + hitR) return
            val perp = abs(rx * uy - ry * ux)
            if (perp <= hitR && perp < bestPerp) { bestPerp = perp; px = nx; py = ny }
        }
        consider(d.targetX.toFloat(), d.targetY.toFloat(), d.predX.toFloat(), d.predY.toFloat())
        var i = 0
        while (i + 3 < d.others.size) {
            consider(d.others[i].toFloat(), d.others[i + 1].toFloat(), d.others[i + 2].toFloat(), d.others[i + 3].toFloat())
            i += 4
        }
        val slot = f[0].toInt()
        if (bestPerp == Float.MAX_VALUE) { touchedSlot = -1; return }
        if (touchedSlot != slot) { touchedSlot = slot; touchSinceMs = now }
        if (now - touchSinceMs < 55L) return // the line must stay on him for a moment, not just sweep past

        val dist = hypot(px - originX, py - originY).coerceAtLeast(1f)
        val dx = (px - originX) / dist
        val dy = (py - originY) / dist
        val use = if (lobbed && rangePx > 1f) radius * (dist / rangePx).coerceIn(0.12f, 1f) else mag.coerceAtLeast(radius * 0.6f)
        val ok = ShellTouch.fire(slot, bx + dx * use, by + dy * use)
        lastFireMs = now
        touchedSlot = -1
        MansAccessibilityService.shotCounter++
        if (now - lastLogMs > 300L) {
            lastLogMs = now
            AimLog.add("ПОМОЩЬ: твоя линия коснулась врага, выстрел с упреждением (${if (ok) "ок" else "ошибка записи"})")
        }
    }
}
