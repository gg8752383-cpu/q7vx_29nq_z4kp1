package com.automans.mobile

import android.media.Image
import java.nio.ByteBuffer
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Automatic target finder. No taps needed:
 *  - an enemy is recognised by the RED health bar above it,
 *  - the player's own fighter by the GREEN health bar (nearest to the screen centre),
 *  - allies (blue bars) are ignored.
 * Enemies are tracked from frame to frame, so the helper also knows where each one is heading and
 * where it will be in a moment. The nearest enemy becomes the aim target.
 */
class EnemyAutoAim {
    private class Bar(val x: Float, val y: Float)

    private class Track(var x: Float, var y: Float, var lastMs: Long) {
        var vx = 0f
        var vy = 0f
        var hits = 1
    }

    private var gridW = 0
    private var gridH = 0
    private var stride = 3
    private var sourceW = 0
    private var sourceH = 0
    private var mask = ByteArray(0)
    private var visited = ByteArray(0)
    private var queue = IntArray(0)
    private var lastProcessedMs = 0L
    private var lastTargetMs = 0L
    private var lastTx = 0f
    private var lastTy = 0f
    private var hasTarget = false
    private var lastDecision: AimDecision? = null
    private var lastSelfMs = 0L
    private val tracks = ArrayList<Track>()

    @Volatile var isLocked: Boolean = false
        private set
    @Volatile var enemyCount: Int = 0
        private set
    @Volatile var hasSelf: Boolean = false
        private set
    @Volatile var selfFx: Float = 0.5f
        private set
    @Volatile var selfFy: Float = 0.5f
        private set

    /** Kept for compatibility with the old tap-to-pick flow; targets are now found automatically. */
    fun selectTarget(screenX: Float, screenY: Float, width: Int, height: Int) = Unit

    @Synchronized fun clear() {
        hasTarget = false
        lastDecision = null
        lastProcessedMs = 0L
        lastTargetMs = 0L
        lastSelfMs = 0L
        tracks.clear()
        isLocked = false
        enemyCount = 0
        hasSelf = false
    }

    @Synchronized fun process(image: Image, nowMs: Long, settings: DodgeSettings): AimDecision? {
        val plane = image.planes.firstOrNull() ?: return null
        return processBuffer(plane.buffer, plane.rowStride, plane.pixelStride, image.width, image.height, nowMs, settings)
    }

    /** Pure pixel logic, separated from android.media.Image so it can be tested on a normal JVM. */
    @Synchronized fun processBuffer(
        buffer: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        w: Int,
        h: Int,
        nowMs: Long,
        settings: DodgeSettings,
    ): AimDecision? {
        if (nowMs - lastProcessedMs < MIN_INTERVAL_MS) return null
        lastProcessedMs = nowMs
        if (w < 100 || h < 100) return null
        ensureGrid(w, h)
        val minDim = min(w, h).toFloat()

        val enemies = ArrayList<Bar>()
        val selves = ArrayList<Bar>()
        scan(buffer, rowStride, pixelStride, w, h, minDim, enemies, selves)
        enemyCount = enemies.size

        // ---- the player's own fighter (green bar nearest to the screen centre) ----
        var originX = settings.playerX.coerceIn(0.05f, 0.95f) * w
        var originY = settings.playerY.coerceIn(0.05f, 0.95f) * h
        var bestSelf: Bar? = null
        var bestSelfD = Float.MAX_VALUE
        for (s in selves) {
            val d = hypot(s.x - w / 2f, s.y - h / 2f)
            if (d < bestSelfD) {
                bestSelfD = d
                bestSelf = s
            }
        }
        if (bestSelf != null) {
            val fx = (bestSelf.x / w).coerceIn(0.05f, 0.95f)
            val fy = ((bestSelf.y + 0.08f * minDim) / h).coerceIn(0.05f, 0.95f)
            if (hasSelf) {
                // light smoothing only: heavy smoothing makes the helper trail behind the fighter
                selfFx = selfFx * 0.2f + fx * 0.8f
                selfFy = selfFy * 0.2f + fy * 0.8f
            } else {
                selfFx = fx
                selfFy = fy
            }
            hasSelf = true
            lastSelfMs = nowMs
        } else if (hasSelf && nowMs - lastSelfMs > 900L) {
            hasSelf = false
        }
        if (hasSelf) {
            originX = selfFx * w
            originY = selfFy * h
        }

        // ---- enemy bodies sit a little below their health bars; follow them between frames ----
        val bodyDy = 0.07f * minDim
        updateTracks(enemies, bodyDy, nowMs, minDim)
        if (tracks.isEmpty()) {
            if (hasTarget && nowMs - lastTargetMs < 350L) return lastDecision
            hasTarget = false
            isLocked = false
            lastDecision = null
            return null
        }

        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in tracks.indices) {
            val d = hypot(tracks[i].x - originX, tracks[i].y - originY)
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        // Stick to the previous target unless another enemy is clearly closer (stops flicker).
        if (hasTarget) {
            var keep = -1
            var keepGap = Float.MAX_VALUE
            for (i in tracks.indices) {
                val gap = hypot(tracks[i].x - lastTx, tracks[i].y - lastTy)
                if (gap < keepGap) {
                    keepGap = gap
                    keep = i
                }
            }
            if (keep >= 0 && keepGap < minDim * 0.12f) {
                val dKeep = hypot(tracks[keep].x - originX, tracks[keep].y - originY)
                if (dKeep <= bestD * 1.35f) best = keep
            }
        }

        val target = tracks[best]
        val tx = target.x.coerceIn(0f, w - 1f)
        val ty = target.y.coerceIn(0f, h - 1f)
        lastTx = tx
        lastTy = ty
        hasTarget = true
        lastTargetMs = nowMs
        isLocked = true

        // where the target will be shortly (roughly the flight time of a shot)
        val pred = predict(target, minDim, w, h)
        val dx = pred[0] - originX
        val dy = pred[1] - originY
        val length = hypot(dx, dy)
        if (length < 1f) return null

        val others = ArrayList<Int>()
        for (i in tracks.indices) {
            if (i == best) continue
            val p = predict(tracks[i], minDim, w, h)
            others.add(tracks[i].x.toInt().coerceIn(0, w - 1))
            others.add(tracks[i].y.toInt().coerceIn(0, h - 1))
            others.add(p[0].toInt())
            others.add(p[1].toInt())
        }
        val decision = AimDecision(
            dx = dx / length,
            dy = dy / length,
            targetX = tx.toInt(),
            targetY = ty.toInt(),
            confidence = 0.9f,
            reason = "враг найден по полоске здоровья",
            playerFx = originX / w,
            playerFy = originY / h,
            others = others.toIntArray(),
            targetVx = if (target.hits >= 3) target.vx else 0f,
            targetVy = if (target.hits >= 3) target.vy else 0f,
            predX = pred[0].toInt(),
            predY = pred[1].toInt(),
        )
        lastDecision = decision
        return decision
    }

    /** Predicted screen position a moment from now; equals the current position if the enemy stands still. */
    private fun predict(t: Track, minDim: Float, w: Int, h: Int): FloatArray {
        var px = t.x
        var py = t.y
        if (t.hits >= 3) {
            val speed = hypot(t.vx, t.vy)
            if (speed > minDim * 0.06f) {
                var mx = t.vx * LEAD_SECONDS
                var my = t.vy * LEAD_SECONDS
                val mag = hypot(mx, my)
                val cap = minDim * 0.16f
                if (mag > cap) {
                    mx *= cap / mag
                    my *= cap / mag
                }
                px += mx
                py += my
            }
        }
        return floatArrayOf(px.coerceIn(0f, w - 1f), py.coerceIn(0f, h - 1f))
    }

    private fun updateTracks(enemies: List<Bar>, bodyDy: Float, nowMs: Long, minDim: Float) {
        val existing = tracks.size
        val used = BooleanArray(existing)
        val gate = minDim * 0.15f
        for (e in enemies) {
            val ex = e.x
            val ey = e.y + bodyDy
            var bestI = -1
            var bestD = gate
            for (i in 0 until existing) {
                if (used[i]) continue
                val d = hypot(tracks[i].x - ex, tracks[i].y - ey)
                if (d < bestD) {
                    bestD = d
                    bestI = i
                }
            }
            if (bestI >= 0) {
                used[bestI] = true
                val t = tracks[bestI]
                val dt = ((nowMs - t.lastMs) / 1000f).coerceIn(0.03f, 0.5f)
                val mvx = (ex - t.x) / dt
                val mvy = (ey - t.y) / dt
                val cap = minDim * 1.4f
                t.vx = (t.vx * 0.6f + mvx * 0.4f).coerceIn(-cap, cap)
                t.vy = (t.vy * 0.6f + mvy * 0.4f).coerceIn(-cap, cap)
                t.x = ex
                t.y = ey
                t.lastMs = nowMs
                t.hits++
            } else {
                tracks.add(Track(ex, ey, nowMs))
            }
        }
        // drop enemies that were not seen for a moment (bars hidden by bushes etc.)
        var i = tracks.size - 1
        while (i >= 0) {
            if (nowMs - tracks[i].lastMs > 450L) tracks.removeAt(i)
            i--
        }
    }

    private fun ensureGrid(w: Int, h: Int) {
        if (w == sourceW && h == sourceH && gridW > 0) return
        sourceW = w
        sourceH = h
        stride = max(2, Math.round(max(w, h) / 780f))
        gridW = max(1, w / stride)
        gridH = max(1, h / stride)
        val n = gridW * gridH
        mask = ByteArray(n)
        visited = ByteArray(n)
        queue = IntArray(n)
        hasTarget = false
        lastDecision = null
        tracks.clear()
    }

    /** Marks exact health-bar colours, groups them, keeps only bar-shaped groups. */
    private fun scan(
        buffer: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        w: Int,
        h: Int,
        minDim: Float,
        enemies: MutableList<Bar>,
        selves: MutableList<Bar>,
    ) {
        val base = buffer.position()
        val limit = buffer.limit()
        for (gy in 0 until gridH) {
            val y = min(h - 1, gy * stride + stride / 2)
            val row = base + y * rowStride
            val out = gy * gridW
            for (gx in 0 until gridW) {
                val x = min(w - 1, gx * stride + stride / 2)
                val idx = row + x * pixelStride
                var t = 0
                if (idx + 2 < limit) {
                    val r = buffer.get(idx).toInt() and 0xFF
                    val g = buffer.get(idx + 1).toInt() and 0xFF
                    val b = buffer.get(idx + 2).toInt() and 0xFF
                    if (r in 222..246 && g in 12..62 && b in 36..62) t = 1
                    else if (r in 55..82 && g in 195..235 && b in 42..66) t = 2
                }
                mask[out + gx] = t.toByte()
            }
        }
        java.util.Arrays.fill(visited, 0.toByte())

        val minW = minDim * 0.028f
        val minH = minDim * 0.0055f
        val maxH = minDim * 0.030f
        for (start in 0 until gridW * gridH) {
            val type = mask[start].toInt()
            if (type == 0 || visited[start].toInt() != 0) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = 1
            var count = 0
            var minX = gridW
            var maxX = 0
            var minY = gridH
            var maxY = 0
            while (head < tail) {
                val cur = queue[head++]
                val cx = cur % gridW
                val cy = cur / gridW
                count++
                if (cx < minX) minX = cx
                if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy
                if (cy > maxY) maxY = cy
                if (cx > 0) tail = push(cur - 1, type, tail)
                if (cx < gridW - 1) tail = push(cur + 1, type, tail)
                if (cy > 0) tail = push(cur - gridW, type, tail)
                if (cy < gridH - 1) tail = push(cur + gridW, type, tail)
            }
            val boxW = maxX - minX + 1
            val boxH = maxY - minY + 1
            val realW = boxW * stride
            val realH = boxH * stride
            if (realW < minW || realH < minH || realH > maxH) continue
            if (realW.toFloat() / realH.toFloat() < 2.5f) continue
            if (count.toFloat() / (boxW * boxH).toFloat() < 0.40f) continue
            val bar = Bar((minX + maxX + 1) / 2f * stride, (minY + maxY + 1) / 2f * stride)
            if (type == 1) enemies.add(bar) else selves.add(bar)
            if (enemies.size + selves.size >= 24) return
        }
    }

    private fun push(index: Int, type: Int, tail: Int): Int {
        if (mask[index].toInt() == type && visited[index].toInt() == 0 && tail < queue.size) {
            visited[index] = 1
            queue[tail] = index
            return tail + 1
        }
        return tail
    }

    private companion object {
        const val MIN_INTERVAL_MS = 45L
        const val LEAD_SECONDS = 0.35f
    }
}
