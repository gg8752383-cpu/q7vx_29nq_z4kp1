package com.automans.mobile

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * Dodges only when there is real danger, and then takes the move stick over from the player ("at any cost"):
 *  - an enemy dashes / rushes at the fighter (his own speed, with the camera motion added back, points at us),
 *  - an enemy is right on top of the fighter,
 *  - the fighter has just been hit (his green bar dropped): the next shots are on their way.
 * Allies are blue bars, which are never tracked, so they can never cause a dodge. Without danger the helper does nothing.
 * The way out is sideways to the threat (a straight shot or dash misses) with a step back when it is a rush.
 * When the danger is over the stick goes back to the player at once.
 */
class AutoDodge {
    private var holding = false
    private var holdStartMs = 0L
    private var lastThreatMs = 0L
    private var lastSteerMs = 0L
    private var lastStartSendMs = 0L
    private var lastReleaseMs = 0L
    private var lastX = 0f
    private var lastY = 0f
    private var baseX = 0f
    private var baseY = 0f
    private var sign = 0
    private var signUntilMs = 0L
    private var episodeWhy = ""
    private var viaTake = false
    private var lastLogMs = 0L
    private val rnd = java.util.Random()

    /** Unit direction of what the helper is doing on the stick now (0,0 when idle); used to keep aim prediction right. */
    @Volatile var vx = 0f
        private set
    @Volatile var vy = 0f
        private set
    @Volatile var isHolding = false
        private set

    class Plan(val dx: Float, val dy: Float, val level: Float, val why: String)

    /**
     * Pure threat logic. Positions and speeds are screen pixels (the camera follows the fighter, so the enemy's real speed
     * is his screen speed plus the fighter's own speed pvx/pvy). Returns null when nothing is dangerous.
     */
    fun plan(sn: EnemyAutoAim.Snapshot, minDim: Float, pvx: Float, pvy: Float, hitAgeMs: Long, sideSign: Int): Plan? {
        var ex = 0f
        var ey = 0f
        var level = 0f
        var why = ""
        var anyUnblocked = -1
        var rx0 = 0f // push away from enemies that are close but not a threat themselves: do not run into them
        var ry0 = 0f
        var nearestHit = Float.MAX_VALUE
        val hit = hitAgeMs in 0..900L
        val ox = sn.originX
        val oy = sn.originY
        for (i in 0 until sn.n) {
            val o = i * 8
            val rx = sn.d[o] - ox
            val ry = sn.d[o + 1] - oy
            val dist = hypot(rx, ry)
            if (dist < 1f) continue
            val ux = rx / dist
            val uy = ry / dist
            val dn = dist / minDim
            val blocked = sn.d[o + 6] > 0.5f
            val seen = sn.d[o + 7]
            val wvx = sn.d[o + 4] + pvx
            val wvy = sn.d[o + 5] + pvy
            // speed towards the fighter (positive = coming at us)
            val closing = -(wvx * ux + wvy * uy) / minDim
            var t = 0f
            var back = 0f
            var side = 0f
            var reason = ""
            if (!blocked && seen >= 5f) {
                if (closing >= 0.45f && dn < 1.0f) { t = 1.0f; back = 0.55f; side = 0.95f; reason = "рывок на тебя" }
                else if (closing >= 0.30f && dn < 0.60f) { t = 0.8f; back = 0.8f; side = 0.7f; reason = "бежит на тебя быстро" }
                else if (closing >= 0.18f && dn < 0.35f) { t = 0.7f; back = 0.9f; side = 0.5f; reason = "налетает вплотную" }
            }
            if (!blocked && dn < 0.15f && t < 0.75f) { t = 0.75f; back = 1.0f; side = 0.5f; reason = "враг вплотную" }
            if (hit && !blocked && dn < 0.95f && dist < nearestHit) {
                nearestHit = dist
                anyUnblocked = i
                if (t < 0.9f) { t = 0.9f; back = min(back, 0.3f).coerceAtLeast(0.25f); side = 1.0f; reason = "тебя ударили" }
            }
            if (t <= 0f) {
                if (!blocked && dn < 0.45f) { val k = 0.5f * (1f - dn / 0.45f); rx0 -= ux * k; ry0 -= uy * k }
                continue
            }
            val wgt = t * (1.3f - min(dn, 1f) * 0.6f)
            val px = -uy * sideSign
            val py = ux * sideSign
            ex += wgt * (-ux * back + px * side)
            ey += wgt * (-uy * back + py * side)
            if (t > level) { level = t; why = reason }
        }
        if (hit && anyUnblocked < 0 && sn.n > 0 && level < 0.9f) {
            // hit by something we cannot see the source of: go sideways to the nearest enemy
            var bi = 0
            var bd = Float.MAX_VALUE
            for (i in 0 until sn.n) {
                val d = hypot(sn.d[i * 8] - ox, sn.d[i * 8 + 1] - oy)
                if (d < bd) { bd = d; bi = i }
            }
            val rx = sn.d[bi * 8] - ox
            val ry = sn.d[bi * 8 + 1] - oy
            val dist = bd.coerceAtLeast(1f)
            ex += -ry / dist * sideSign
            ey += rx / dist * sideSign
            level = 0.9f
            why = "тебя ударили"
        }
        if (level <= 0f) return null
        ex += rx0
        ey += ry0
        val len = hypot(ex, ey)
        if (len < 0.05f) return null
        return Plan(ex / len, ey / len, level, why)
    }

    /** Which side to step to: where the player is already pushing the stick, else away from the other enemies. */
    private fun chooseSign(sn: EnemyAutoAim.Snapshot, minDim: Float, mvx: Float, mvy: Float): Int {
        val ox = sn.originX
        val oy = sn.originY
        // main threat direction: nearest enemy
        var bi = -1
        var bd = Float.MAX_VALUE
        for (i in 0 until sn.n) {
            val d = hypot(sn.d[i * 8] - ox, sn.d[i * 8 + 1] - oy)
            if (d < bd) { bd = d; bi = i }
        }
        if (bi < 0) return if (rnd.nextBoolean()) 1 else -1
        val ux = (sn.d[bi * 8] - ox) / bd.coerceAtLeast(1f)
        val uy = (sn.d[bi * 8 + 1] - oy) / bd.coerceAtLeast(1f)
        // sideways component of the player's own push: +1 means "to the (-uy, ux) side"
        val lat = mvx * -uy + mvy * ux
        if (abs(lat) > 0.25f) return if (lat > 0) 1 else -1
        // otherwise the side with fewer other enemies
        var score = 0f
        for (i in 0 until sn.n) {
            if (i == bi) continue
            val rx = sn.d[i * 8] - ox
            val ry = sn.d[i * 8 + 1] - oy
            val dd = hypot(rx, ry).coerceAtLeast(1f)
            val l = (rx * -uy + ry * ux) / dd
            score += l / (0.3f + dd / minDim)
        }
        if (abs(score) > 0.05f) return if (score > 0) -1 else 1
        return if (rnd.nextBoolean()) 1 else -1
    }

    /**
     * Call for every analysed picture. [pvx]/[pvy] is the fighter's own speed (px/s) as the aim code knows it,
     * [hitAgeMs] how long ago the fighter's health bar dropped (large = never).
     */
    @Synchronized fun frame(sn: EnemyAutoAim.Snapshot, w: Int, h: Int, s: DodgeSettings, now: Long, pvx: Float, pvy: Float, hitAgeMs: Long) {
        if (!s.autoDodge || !ShellTouch.ready || w < 100 || h < 100) { release(now, "выключен"); return }
        val minDim = min(w, h).toFloat()
        val lf = ShellTouch.leftFinger()
        val mvLen = if (lf != null) hypot(lf[0] - lf[2], lf[1] - lf[3]) else 0f
        val mvx = if (lf != null && mvLen > minDim * 0.012f) (lf[0] - lf[2]) / mvLen * (mvLen / (minDim * 0.07f)).coerceAtMost(1f) else 0f
        val mvy = if (lf != null && mvLen > minDim * 0.012f) (lf[1] - lf[3]) / mvLen * (mvLen / (minDim * 0.07f)).coerceAtMost(1f) else 0f

        if (sign == 0) {
            sign = chooseSign(sn, minDim, mvx, mvy)
            signUntilMs = now + 450L + rnd.nextInt(350)
        } else if (holding && episodeWhy == "тебя ударили" && now >= signUntilMs) {
            // after a hit the next shots come at once: change side now and then so they miss
            sign = -sign
            signUntilMs = now + 450L + rnd.nextInt(350)
        }
        val p = plan(sn, minDim, pvx, pvy, hitAgeMs, sign)
        if (p != null) lastThreatMs = now
        if (!holding) {
            if (p == null) return
            if (now - lastReleaseMs < 200L) return
            // while the player is steering himself, only a real dash at him is worth taking the stick for
            if (lf != null && p.level < 0.95f) return
            // the player already runs the right way: let him
            if (mvx * p.dx + mvy * p.dy > 0.6f && hypot(mvx, mvy) > 0.5f) return
            start(sn, minDim, w, h, s, now, p, lf)
            if (!holding) return
        } else {
            if (p == null && now - lastThreatMs > 350L) { release(now, "опасность прошла"); return }
            if (now - holdStartMs > 2400L && (p == null || p.level < 0.9f)) { release(now, "слишком долго"); return }
        }
        val use = p ?: return
        vx = use.dx
        vy = use.dy
        val radius = minDim * s.joystickRadiusPct.coerceIn(0.04f, 0.14f)
        val tx = baseX + use.dx * radius * 0.92f
        val ty = baseY + use.dy * radius * 0.92f
        if (viaTake && now - lastStartSendMs >= 220L) {
            // the bridge ends a takeover by itself when the player's finger leaves; asking again is harmless if it still runs
            ShellTouch.takeStart(baseX, baseY)
            lastStartSendMs = now
        }
        if (now - lastSteerMs >= 28L && hypot(tx - lastX, ty - lastY) > 2f) {
            if (viaTake) ShellTouch.takeSteer(tx, ty) else ShellTouch.move(tx, ty)
            lastX = tx
            lastY = ty
            lastSteerMs = now
        }
    }

    private fun start(sn: EnemyAutoAim.Snapshot, minDim: Float, w: Int, h: Int, s: DodgeSettings, now: Long, p: Plan, lf: FloatArray?) {
        val take = ShellTouch.canTake()
        if (!take && lf != null) return // the old extra-finger path cannot fight the player's own finger
        if (lf != null && !ShellTouch.proxyActive) return // without owning the screen the player's own finger would win anyway
        if (lf != null) { baseX = lf[2]; baseY = lf[3] } else {
            baseX = w * s.joystickX.coerceIn(0.03f, 0.25f)
            baseY = h * s.joystickY.coerceIn(0.55f, 0.95f)
        }
        val ok = if (take) ShellTouch.takeStart(baseX, baseY) else ShellTouch.down(baseX, baseY)
        if (!ok) return
        viaTake = take
        holding = true
        isHolding = true
        holdStartMs = now
        lastStartSendMs = now
        lastSteerMs = 0L
        lastX = baseX
        lastY = baseY
        episodeWhy = p.why
        if (p.why != "тебя ударили") signUntilMs = now + 4000L
        if (now - lastLogMs > 300L) {
            lastLogMs = now
            AimLog.add("УКЛОНЕНИЕ: ${p.why} (опасность %.1f), %s".format(java.util.Locale.US, p.level, if (lf != null) "перехватил твой стик" else "стик был свободен"))
        }
    }

    @Synchronized fun release(now: Long, why: String = "") {
        vx = 0f
        vy = 0f
        if (!holding) return
        if (viaTake) ShellTouch.takeEnd() else { ShellTouch.move(baseX, baseY); ShellTouch.up() }
        holding = false
        isHolding = false
        lastReleaseMs = now
        sign = 0
        if (why.isNotEmpty() && why != "выключен") AimLog.add("УКЛОНЕНИЕ: отдал стик ($why)")
    }

    fun cancel() = release(android.os.SystemClock.elapsedRealtime())
}
