package com.automans.mobile

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * The player aims with his own finger on the attack stick. The very moment the white aim line touches an enemy's
 * hitbox ring, the finger is moved to where that enemy will be when the shot arrives and lifted: one shot, at once.
 * It is checked on every new picture AND on every movement of the finger, so a quick sweep across an enemy is not missed.
 */
class ManualAssist {
    private var snap: EnemyAutoAim.Snapshot? = null
    private var w = 0
    private var h = 0
    private var s = DodgeSettings()
    private var lobbed = false
    private var rangePx = 0f
    private var ammo = -1
    private var frameAgeMs = 0f
    private var picTimeMs = 0L
    private var lastFireMs = 0L
    private var lastLogMs = 0L
    private var lastBlockLogMs = 0L
    private var lastDiagMs = 0L
    private var lastNoFingerMs = 0L
    private var fireAmmo = -1
    private var fireAtMs = 0L

    /** New picture analysed: remember the enemies and check right away. */
    @Synchronized fun update(
        snapshot: EnemyAutoAim.Snapshot, w: Int, h: Int, s: DodgeSettings, lobbed: Boolean, rangePx: Float, ammo: Int,
        frameAgeMs: Float, nowMs: Long,
    ) {
        this.snap = snapshot
        // when the picture was really taken, on the same clock as "now" below
        this.picTimeMs = nowMs - frameAgeMs.toLong()
        this.w = w; this.h = h; this.s = s; this.lobbed = lobbed; this.rangePx = rangePx; this.ammo = ammo; this.frameAgeMs = frameAgeMs
        // did the last shot really go off? the ammo pips under the fighter tell
        if (fireAtMs != 0L && nowMs - fireAtMs >= 260L) {
            if (ammo >= 0 && fireAmmo >= 0) AimLog.add("ПРОВЕРКА выстрела: патронов было %d, стало %d — %s".format(fireAmmo, ammo, if (ammo < fireAmmo) "выстрел прошёл" else "выстрел НЕ прошёл"))
            fireAtMs = 0L
        }
        evaluate(android.os.SystemClock.elapsedRealtime())
    }

    /** The player's finger moved: check with the enemies we know. */
    @Synchronized fun onFinger() {
        if (snap == null) return
        evaluate(android.os.SystemClock.elapsedRealtime())
    }

    private fun evaluate(now: Long) {
        val sn = snap ?: return
        if (!ShellTouch.ready || sn.n == 0 || w < 100 || h < 100) return
        // the picture must be fresh: the enemies are tracked, but never trust something older than a quarter second
        val picAge = now - picTimeMs
        if (picAge > 250L || picAge < -1000L) return
        if (now - lastFireMs < 90L) return
        val minDim = min(w, h).toFloat()
        val radius = minDim * s.attackRadiusPct.coerceIn(0.04f, 0.14f)
        val bx = w * s.attackX.coerceIn(0.65f, 0.97f)
        val by = h * s.attackY.coerceIn(0.55f, 0.95f)
        val f = ShellTouch.attackFinger(bx, by, radius)
        if (f == null) {
            if (ShellTouch.fingerCount() > 0 && now - lastNoFingerMs > 6000L) {
                lastNoFingerMs = now
                AimLog.add("ПОМОЩЬ: пальцев на экране ${ShellTouch.fingerCount()}, но у кнопки атаки (%.2f,%.2f) пальца нет".format(java.util.Locale.US, s.attackX, s.attackY))
            }
            return
        }
        val vx = (f[1] - bx).toFloat()
        val vy = (f[2] - by).toFloat()
        val mag = hypot(vx, vy)
        if (mag < radius * 0.30f) return // still in the dead centre: not aiming yet
        val ux = vx / mag
        val uy = vy / mag
        val reach = if (lobbed) rangePx * (mag / radius).coerceAtMost(1f) else rangePx * 1.08f
        val lineLen = reach.coerceAtLeast(minDim * 0.25f)
        val hitR = minDim * 0.055f
        val ox = sn.originX
        val oy = sn.originY
        val dt = picAge.coerceIn(0L, 90L) / 1000f // the enemies have moved on since the picture

        var bestPerp = Float.MAX_VALUE
        var best = -1
        var blockedHit = false
        for (i in 0 until sn.n) {
            val o = i * 8
            val ex = sn.d[o] + sn.d[o + 4] * dt
            val ey = sn.d[o + 1] + sn.d[o + 5] * dt
            val rx = ex - ox
            val ry = ey - oy
            val along = rx * ux + ry * uy
            if (along < 0f || along > lineLen + hitR) continue
            val perp = abs(rx * uy - ry * ux)
            if (perp > hitR) continue
            if (sn.d[o + 6] > 0.5f && !lobbed) { blockedHit = true; continue }
            if (perp < bestPerp) { bestPerp = perp; best = i }
        }
        if (best < 0) {
            if (now - lastDiagMs > 1200L) {
                lastDiagMs = now
                var nearest = Float.MAX_VALUE
                for (i in 0 until sn.n) {
                    val o = i * 8
                    val rx = sn.d[o] + sn.d[o + 4] * dt - ox
                    val ry = sn.d[o + 1] + sn.d[o + 5] * dt - oy
                    val along = rx * ux + ry * uy
                    if (along < 0f) continue
                    nearest = min(nearest, abs(rx * uy - ry * ux))
                }
                AimLog.add("ПОМОЩЬ: целюсь, врагов %d, ближе всего к линии %s (надо ≤ %.0f px), длина линии %.0f px, кадр %.0f мс".format(
                    sn.n, if (nearest == Float.MAX_VALUE) "—" else "%.0f px".format(java.util.Locale.US, nearest), hitR, lineLen, picAge.toFloat()))
            }
            if (blockedHit && now - lastBlockLogMs > 1500L) {
                lastBlockLogMs = now
                AimLog.add("ПОМОЩЬ: враг на линии, но между вами стена: не стреляю")
            }
            return
        }
        val o = best * 8
        val px = sn.d[o + 2] + sn.d[o + 4] * dt
        val py = sn.d[o + 3] + sn.d[o + 5] * dt
        val dist = hypot(px - ox, py - oy).coerceAtLeast(1f)
        val dx = (px - ox) / dist
        val dy = (py - oy) / dist
        val use = if (lobbed && rangePx > 1f) radius * (dist / rangePx).coerceIn(0.12f, 1f) else radius * 0.95f
        val slot = f[0].toInt()
        val ok = ShellTouch.fire(slot, bx + dx * use, by + dy * use)
        lastFireMs = now
        fireAmmo = ammo
        fireAtMs = now
        MansAccessibilityService.shotCounter++
        if (now - lastLogMs > 250L) {
            lastLogMs = now
            val cur = hypot(sn.d[o] - ox, sn.d[o + 1] - oy)
            val lead = hypot(px - (sn.d[o] + sn.d[o + 4] * dt), py - (sn.d[o + 1] + sn.d[o + 5] * dt))
            AimLog.add(
                "ВЫСТРЕЛ: враг %.0f px, упреждение %.0f px, скорость врага %.0f px/с, точность линии %.0f px, патронов %d, кадр %.0f мс, палец-ход %s"
                    .format(java.util.Locale.US, cur, lead, hypot(sn.d[o + 4], sn.d[o + 5]), bestPerp, ammo, picAge.toFloat(), if (ok) "ок" else "ОШИБКА"),
            )
        }
    }
}
