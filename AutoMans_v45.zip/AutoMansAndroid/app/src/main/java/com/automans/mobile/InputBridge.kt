package com.automans.mobile

import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.BufferedReader
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Runs in a separate process with ADB (shell) rights, started through Shizuku with app_process.
 *  - It always READS the real touchscreen (/dev/input/eventN) and tells the app where the player's fingers are.
 *  - To touch the screen it first tries to WRITE into the same device (an unused slot, "evdev" mode).
 *    Many phones (Samsung) forbid that for the shell; then it injects Android touch events instead ("im" mode):
 *      * "F": the player's own attack finger is moved to the predicted spot and lifted, as part of the SAME touch device
 *        stream, so the game sees exactly one release there and the other fingers are untouched;
 *      * "D/M/U": one extra finger on a virtual touch device (used for the move stick).
 *
 * Arguments: <device> <injectSlot> <eventSize 24|16> <extras "code=value,..."> [writePath or -] [touch device name]
 * Commands on stdin (panel coordinates): "T rot sw sh pw ph" geometry, "D x y", "M x y", "U", "F slot x y", "Q".
 * Lines on stdout: "READY evdev|im|ro", then "D slot x y", "M slot x y", "U slot" for the player's fingers,
 * and "ERR ..." / "INF ..." diagnostics.
 */
object InputBridge {
    private const val EV_SYN = 0
    private const val EV_KEY = 1
    private const val EV_ABS = 3
    private const val ABS_MT_SLOT = 0x2f
    private const val ABS_MT_POSITION_X = 0x35
    private const val ABS_MT_POSITION_Y = 0x36
    private const val ABS_MT_TRACKING_ID = 0x39
    private const val BTN_TOUCH = 0x14a
    private const val SLOTS = 32
    private const val POINTER_SHIFT = 8

    private val trackId = IntArray(SLOTS) { -1 }
    private val posX = IntArray(SLOTS)
    private val posY = IntArray(SLOTS)
    private val lastEmit = LongArray(SLOTS)
    private val pointerId = IntArray(SLOTS) { -1 }
    private val lock = Any()
    private var gestureDownMs = 0L

    @Volatile private var userFingers = 0
    private var injecting = false
    private var nextTid = 52000

    // geometry for the injected mode
    private var rot = 1
    private var sw = 2340
    private var sh = 1080
    private var pw = 1080
    private var ph = 2340

    // injected mode
    private var injTarget: Any? = null
    private var injMethod: Method? = null
    private var injArgs = 2
    private var touchDeviceId = -1
    private var virtDownMs = 0L
    private var virtActive = false
    private var errCount = 0
    private var fireInfoCount = 0
    /** When the touchscreen last sent a report (nanoTime), how often it does, and how many reports there were so far. */
    @Volatile private var lastSynNs = 0L
    @Volatile private var periodNs = 8_300_000L
    @Volatile private var synCount = 0L

    private fun toScreen(x: Float, y: Float): FloatArray {
        val fx = x / pw
        val fy = y / ph
        return when (rot) {
            1 -> floatArrayOf(fy * sw, (1f - fx) * sh)
            3 -> floatArrayOf((1f - fy) * sw, fx * sh)
            2 -> floatArrayOf((1f - fx) * sw, (1f - fy) * sh)
            else -> floatArrayOf(fx * sw, fy * sh)
        }
    }

    private fun say(line: String) {
        synchronized(System.out) { System.out.println(line); System.out.flush() }
    }

    private fun err(what: String, e: Throwable?) {
        if (errCount++ < 12) say("ERR $what" + (if (e != null) ": " + (e.cause ?: e) else ""))
    }

    /** Finds a way to inject touch events as the shell user. Returns null when it worked, else a reason. */
    private fun initInjection(deviceName: String): String? {
        val reasons = StringBuilder()
        // 1) the input service directly
        try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "input") as android.os.IBinder
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            val iim = stub.getMethod("asInterface", android.os.IBinder::class.java).invoke(null, binder)!!
            val m = iim.javaClass.methods.filter { it.name == "injectInputEvent" }.minByOrNull { it.parameterTypes.size }
            if (m != null && m.parameterTypes.size in 2..3) {
                injTarget = iim; injMethod = m; injArgs = m.parameterTypes.size
            } else reasons.append("IInputManager: нет injectInputEvent; ")
        } catch (e: Throwable) {
            reasons.append("IInputManager: ${e.cause ?: e}; ")
        }
        // 2) the InputManager object
        if (injMethod == null) {
            try {
                val c = Class.forName("android.hardware.input.InputManager")
                val inst = c.getDeclaredMethod("getInstance").also { it.isAccessible = true }.invoke(null)!!
                val m = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
                injTarget = inst; injMethod = m; injArgs = 2
            } catch (e: Throwable) {
                reasons.append("InputManager: ${e.cause ?: e}; ")
            }
        }
        if (injMethod == null) return reasons.toString()
        // the real touchscreen as Android knows it: events carrying its id join the player's own touch stream
        try {
            var any = -1
            for (id in InputDevice.getDeviceIds()) {
                val d = InputDevice.getDevice(id) ?: continue
                if ((d.sources and InputDevice.SOURCE_TOUCHSCREEN) != InputDevice.SOURCE_TOUCHSCREEN) continue
                if (any < 0) any = id
                if (deviceName.isNotEmpty() && d.name == deviceName) { touchDeviceId = id; break }
            }
            if (touchDeviceId < 0) touchDeviceId = any
        } catch (e: Throwable) {
            say("INF не получил список устройств ввода: ${e.cause ?: e}")
        }
        say("INF внедрение событий готово, touch-устройство id=$touchDeviceId")
        return null
    }

    private fun inject(ev: MotionEvent) {
        try {
            val t = injTarget ?: return
            val m = injMethod ?: return
            val ok = if (injArgs == 2) m.invoke(t, ev, 0) else m.invoke(t, ev, 0, -1)
            if (ok == false && errCount < 6) err("событие отклонено", null)
        } catch (e: Throwable) {
            err("внедрение", e)
        } finally {
            try { ev.recycle() } catch (ignored: Throwable) { }
        }
    }

    private fun motion(down: Long, action: Int, ids: IntArray, xs: FloatArray, ys: FloatArray, deviceId: Int): MotionEvent {
        val n = ids.size
        val props = Array(n) { i -> MotionEvent.PointerProperties().also { it.id = ids[i]; it.toolType = MotionEvent.TOOL_TYPE_FINGER } }
        val coords = Array(n) { i -> MotionEvent.PointerCoords().also { it.x = xs[i]; it.y = ys[i]; it.pressure = 1f; it.size = 0.1f } }
        return MotionEvent.obtain(down, (System.nanoTime() / 1_000_000L), action, n, props, coords, 0, 0, 1f, 1f, deviceId, 0, InputDevice.SOURCE_TOUCHSCREEN, 0)
    }

    private fun assignId(slot: Int) {
        val used = BooleanArray(SLOTS)
        var active = 0
        for (s in 0 until SLOTS) if (s != slot && pointerId[s] >= 0) { used[pointerId[s]] = true; active++ }
        var id = 0
        while (id < SLOTS - 1 && used[id]) id++
        pointerId[slot] = id
        if (active == 0) gestureDownMs = (System.nanoTime() / 1_000_000L)
    }

    // ---- takeover of the move stick (injected mode only) ----
    private const val TAKE_ID = 20
    private val takeLock = Any()
    @Volatile private var takeActive = false
    private var takeSlot = -1
    private var takeX = 0f
    private var takeY = 0f
    @Volatile private var takeLastMs = 0L

    private class Pt(val id: Int, val slot: Int, val x: Float, val y: Float)

    /** The fingers the game should see now, ordered by pointer id. Call with [lock] held. */
    private fun points(): List<Pt> {
        val list = ArrayList<Pt>()
        for (s in 0 until SLOTS) {
            if (pointerId[s] < 0) continue
            if (takeActive && s == takeSlot) continue // his move finger is released for the game while we steer
            val p = toScreen(posX[s].toFloat(), posY[s].toFloat())
            list.add(Pt(pointerId[s], s, p[0], p[1]))
        }
        if (takeActive) list.add(Pt(TAKE_ID, -2, takeX, takeY))
        list.sortBy { it.id }
        return list
    }

    /** kind: 0 move, 1 pointer down, 2 pointer up; idx = index (in pts) of the pointer that goes down / up. */
    private fun sendPts(down: Long, pts: List<Pt>, kind: Int, idx: Int) {
        val n = pts.size
        if (n == 0) return
        val action = when (kind) {
            0 -> MotionEvent.ACTION_MOVE
            1 -> if (n == 1) MotionEvent.ACTION_DOWN else (MotionEvent.ACTION_POINTER_DOWN or (idx shl POINTER_SHIFT))
            else -> if (n == 1) MotionEvent.ACTION_UP else (MotionEvent.ACTION_POINTER_UP or (idx shl POINTER_SHIFT))
        }
        inject(motion(down, action, IntArray(n) { pts[it].id }, FloatArray(n) { pts[it].x }, FloatArray(n) { pts[it].y }, touchDeviceId))
    }

    /** Takes the move stick: his own finger there is released for the game, ours takes over at (px,py). */
    private fun takeStart(px: Int, py: Int) {
        synchronized(takeLock) {
            if (takeActive) return
            val now = (System.nanoTime() / 1_000_000L)
            var mvIdx = -1
            var before: List<Pt> = emptyList()
            var down = 0L
            synchronized(lock) {
                before = points()
                down = gestureDownMs
                // his move finger: the one on the left half of the screen
                for (pt in before) if (pt.x < sw * 0.5f) { mvIdx = before.indexOf(pt); break }
                if (mvIdx >= 0) takeSlot = before[mvIdx].slot
            }
            if (mvIdx >= 0) sendPts(down, before, 2, mvIdx) // lift his finger for the game
            val p = toScreen(px.toFloat(), py.toFloat())
            val after: List<Pt>
            synchronized(lock) {
                takeX = p[0]; takeY = p[1]
                takeActive = true
                after = points()
                if (after.size == 1) { gestureDownMs = now; down = now } else down = gestureDownMs
            }
            sendPts(down, after, 1, after.indexOfFirst { it.id == TAKE_ID })
            takeLastMs = now
            say("INF перехват стика: пальцев было ${before.size}, его палец ${if (mvIdx >= 0) "отпущен для игры" else "не найден"}")
        }
    }

    private fun takeSteer(px: Int, py: Int) {
        synchronized(takeLock) {
            if (!takeActive) return
            val p = toScreen(px.toFloat(), py.toFloat())
            val pts: List<Pt>
            val down: Long
            synchronized(lock) { takeX = p[0]; takeY = p[1]; pts = points(); down = gestureDownMs }
            sendPts(down, pts, 0, 0)
            takeLastMs = (System.nanoTime() / 1_000_000L)
        }
    }

    /** Gives the stick back: our finger lifts, his finger (if still on the glass) is put back where it is now. */
    private fun takeEnd(why: String) {
        synchronized(takeLock) {
            if (!takeActive) return
            val now = (System.nanoTime() / 1_000_000L)
            val withTake: List<Pt>
            var down = 0L
            synchronized(lock) { withTake = points(); down = gestureDownMs }
            sendPts(down, withTake, 2, withTake.indexOfFirst { it.id == TAKE_ID })
            val k: Int
            val back: List<Pt>
            synchronized(lock) {
                takeActive = false
                k = takeSlot
                takeSlot = -1
                back = points()
            }
            if (k >= 0 && pointerId[k] >= 0) {
                // his finger is still down: let the game see it again from where it is now
                val idx = back.indexOfFirst { it.slot == k }
                if (back.size == 1) { synchronized(lock) { gestureDownMs = now }; sendPts(now, back, 1, idx) }
                else sendPts(down, back, 1, idx)
            }
            say("INF стик возвращён ($why)")
        }
    }

    /**
     * While the player drags his attack finger, the touchscreen sends a report about every 8 ms, and each one repeats the
     * finger's REAL position. If such a report lands between our "move" and our "lift", the game aims where the finger really
     * is. So the two events go out right after a report has passed and are done long before the next one is due.
     */
    private fun waitQuiet(): Float {
        val t0 = System.nanoTime()
        val period = periodNs.coerceIn(4_000_000L, 16_000_000L)
        val start = 1_800_000L
        val end = maxOf(start + 500_000L, period - 3_200_000L)
        while (true) {
            val now = System.nanoTime()
            val syn = lastSynNs
            val el = now - syn
            if (syn == 0L || el > period * 18 / 10) break // nothing is moving on the glass: no report is due, go now
            if (el in start..end) break
            if (now - t0 > 14_000_000L) break
            java.util.concurrent.locks.LockSupport.parkNanos(250_000L)
        }
        return (System.nanoTime() - t0) / 1_000_000f
    }

    /** The player's attack finger is moved to (px,py) and lifted there, inside the real touch stream. */
    private fun fireInjected(slot: Int, px: Int, py: Int) {
        val waited = waitQuiet()
        val pts: List<Pt>
        val down: Long
        val idx: Int
        synchronized(lock) {
            if (slot !in 0 until SLOTS || pointerId[slot] < 0 || (takeActive && slot == takeSlot)) { err("выстрел: палец не найден (слот $slot)", null); return }
            val list = points()
            idx = list.indexOfFirst { it.slot == slot }
            if (idx < 0) { err("выстрел: палец не в списке (слот $slot)", null); return }
            val t = toScreen(px.toFloat(), py.toFloat())
            pts = list.mapIndexed { i, pt -> if (i == idx) Pt(pt.id, pt.slot, t[0], t[1]) else pt }
            down = gestureDownMs
        }
        val n = pts.size
        val ids = IntArray(n) { pts[it].id }
        val xs = FloatArray(n) { pts[it].x }
        val ys = FloatArray(n) { pts[it].y }
        val upAction = if (n == 1) MotionEvent.ACTION_UP else (MotionEvent.ACTION_POINTER_UP or (idx shl POINTER_SHIFT))
        val mv = motion(down, MotionEvent.ACTION_MOVE, ids, xs, ys, touchDeviceId)
        val up = motion(down, upAction, ids, xs, ys, touchDeviceId)
        val synBefore = synCount
        val t0 = System.nanoTime()
        inject(mv)
        inject(up)
        val gap = (System.nanoTime() - t0) / 1_000_000f
        val between = synCount - synBefore
        if (fireInfoCount++ < 14) {
            say("INF выстрел: пальцев=$n индекс=$idx id=${pts[idx].id} экран=(${pts[idx].x.toInt()},${pts[idx].y.toInt()}) ждал %.1f мс, MOVE→UP %.2f мс, отчётов экрана за это время %d, период %.1f мс"
                .format(java.util.Locale.US, waited, gap, between, periodNs / 1_000_000f))
        }
    }

    private fun virtual(action: Int, px: Int, py: Int) {
        val p = toScreen(px.toFloat(), py.toFloat())
        if (action == MotionEvent.ACTION_DOWN) { virtDownMs = (System.nanoTime() / 1_000_000L); virtActive = true }
        if (!virtActive) return
        inject(motion(virtDownMs, action, intArrayOf(12), floatArrayOf(p[0]), floatArrayOf(p[1]), -1))
        if (action == MotionEvent.ACTION_UP) virtActive = false
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val dev = args[0]
        val injSlot = args[1].toInt()
        val size = args[2].toInt()
        val extras = ArrayList<IntArray>()
        if (args.size > 3 && args[3].isNotEmpty()) {
            for (part in args[3].split(',')) {
                val kv = part.split('=')
                if (kv.size == 2) extras.add(intArrayOf(kv[0].toInt(), kv[1].toInt()))
            }
        }
        val writePath = if (args.size > 4 && args[4] != "-") args[4] else dev
        val deviceName = if (args.size > 5) args[5] else ""
        val stdout = System.out

        // ---- how to touch: write into the device, or inject Android events ----
        var out: FileOutputStream? = null
        var mode = "evdev"
        try {
            out = FileOutputStream(writePath)
        } catch (e: Throwable) {
            say("INF запись в $writePath закрыта (${e.message}), пробую внедрение событий")
            val why = initInjection(deviceName)
            if (why == null) mode = "im" else { say("ERR внедрение не готово: $why"); mode = "ro" }
        }

        val reader = Thread {
            try {
                val input = FileInputStream(dev)
                val buf = ByteArray(size)
                val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
                var slot = 0
                val dirty = BooleanArray(SLOTS)
                while (true) {
                    var got = 0
                    while (got < size) {
                        val n = input.read(buf, got, size - got)
                        if (n < 0) return@Thread
                        got += n
                    }
                    val type = bb.getShort(size - 8).toInt() and 0xffff
                    val code = bb.getShort(size - 6).toInt() and 0xffff
                    val value = bb.getInt(size - 4)
                    if (type == EV_ABS) {
                        when (code) {
                            ABS_MT_SLOT -> slot = value.coerceIn(0, SLOTS - 1)
                            ABS_MT_TRACKING_ID -> {
                                synchronized(lock) {
                                    val old = trackId[slot]
                                    trackId[slot] = value
                                    if (value >= 0 && old < 0) assignId(slot)
                                    else if (value < 0 && old >= 0) pointerId[slot] = -1
                                }
                                if (value < 0 && takeActive) {
                                    var anyReal = false
                                    synchronized(lock) { for (q in 0 until SLOTS) if (pointerId[q] >= 0) anyReal = true }
                                    if (!anyReal || slot == takeSlot) takeEnd("палец ушёл")
                                }
                                dirty[slot] = true
                            }
                            ABS_MT_POSITION_X -> { posX[slot] = value; dirty[slot] = true }
                            ABS_MT_POSITION_Y -> { posY[slot] = value; dirty[slot] = true }
                        }
                    } else if (type == EV_SYN && code == 0) {
                        val nowNs = System.nanoTime()
                        val prev = lastSynNs
                        if (prev != 0L) {
                            val dd = nowNs - prev
                            if (dd in 2_000_000L..30_000_000L) periodNs = (periodNs * 8 + dd * 2) / 10
                        }
                        lastSynNs = nowNs
                        synCount++
                        var count = 0
                        val now = System.currentTimeMillis()
                        for (s in 0 until SLOTS) {
                            if (s != injSlot && trackId[s] >= 0) count++
                            if (!dirty[s]) continue
                            dirty[s] = false
                            if (s == injSlot && mode == "evdev") continue
                            synchronized(stdout) {
                                if (trackId[s] < 0) {
                                    if (lastEmit[s] != 0L) {
                                        stdout.println("U $s")
                                        lastEmit[s] = 0
                                    }
                                } else if (lastEmit[s] == 0L) {
                                    stdout.println("D $s ${posX[s]} ${posY[s]}")
                                    lastEmit[s] = now
                                } else if (now - lastEmit[s] >= 8L) {
                                    stdout.println("M $s ${posX[s]} ${posY[s]}")
                                    lastEmit[s] = now
                                }
                                stdout.flush()
                            }
                        }
                        userFingers = count
                    }
                }
            } catch (e: Throwable) {
                say("ERR read $dev: $e")
            }
        }
        reader.isDaemon = true
        reader.start()

        fun frame(events: List<IntArray>) {
            val o = out ?: return
            val bb = ByteBuffer.allocate(events.size * size).order(ByteOrder.LITTLE_ENDIAN)
            for (e in events) {
                bb.position(bb.position() + (size - 8))
                bb.putShort(e[0].toShort())
                bb.putShort(e[1].toShort())
                bb.putInt(e[2])
            }
            o.write(bb.array())
            o.flush()
        }

        say("READY $mode")
        if (mode == "im") {
            val wd = Thread {
                while (true) {
                    try { Thread.sleep(100) } catch (e: InterruptedException) { return@Thread }
                    if (takeActive && (System.nanoTime() / 1_000_000L) - takeLastMs > 700L) takeEnd("тишина от приложения")
                }
            }
            wd.isDaemon = true
            wd.start()
        }

        val cmds = BufferedReader(InputStreamReader(System.`in`))
        try {
            while (true) {
                val line = cmds.readLine() ?: break
                val p = line.trim().split(' ')
                try {
                    when (p[0]) {
                        "T" -> if (p.size >= 6) {
                            rot = p[1].toInt(); sw = p[2].toInt(); sh = p[3].toInt(); pw = p[4].toInt(); ph = p[5].toInt()
                        }
                        "D" -> if (p.size >= 3) {
                            if (mode == "im") virtual(MotionEvent.ACTION_DOWN, p[1].toInt(), p[2].toInt())
                            else if (mode == "evdev") {
                                val ev = ArrayList<IntArray>()
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, nextTid))
                                nextTid = if (nextTid > 60000) 52000 else nextTid + 1
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[1].toInt()))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[2].toInt()))
                                for (x in extras) ev.add(intArrayOf(EV_ABS, x[0], x[1]))
                                if (userFingers == 0) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 1))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                frame(ev)
                                injecting = true
                            }
                        }
                        "M" -> if (p.size >= 3) {
                            if (mode == "im") virtual(MotionEvent.ACTION_MOVE, p[1].toInt(), p[2].toInt())
                            else if (mode == "evdev" && injecting) {
                                frame(listOf(
                                    intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot),
                                    intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[1].toInt()),
                                    intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[2].toInt()),
                                    intArrayOf(EV_SYN, 0, 0),
                                ))
                            }
                        }
                        "U" -> {
                            if (mode == "im") virtual(MotionEvent.ACTION_UP, 0, 0)
                            else if (mode == "evdev" && injecting) {
                                val ev = ArrayList<IntArray>()
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1))
                                if (userFingers == 0) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 0))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                frame(ev)
                                injecting = false
                            }
                        }
                        "F" -> if (p.size >= 4) {
                            val slot = p[1].toInt().coerceIn(0, SLOTS - 1)
                            if (mode == "im") fireInjected(slot, p[2].toInt(), p[3].toInt())
                            else if (mode == "evdev") {
                                // fire: move the player's finger to a new spot and let go of it, in one write,
                                // so the game sees the last move and the release at the new position
                                val ev = ArrayList<IntArray>()
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, slot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[2].toInt()))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[3].toInt()))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, slot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1))
                                if (userFingers <= 1 && !injecting) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 0))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                frame(ev)
                            }
                        }
                        "G" -> if (p.size >= 3 && mode == "im") takeStart(p[1].toInt(), p[2].toInt())
                        "S" -> if (p.size >= 3 && mode == "im") takeSteer(p[1].toInt(), p[2].toInt())
                        "H" -> if (mode == "im") takeEnd("команда")
                        "Q" -> break
                    }
                } catch (e: java.io.IOException) {
                    err("запись", e)
                } catch (e: NumberFormatException) {
                }
            }
        } catch (ignored: Throwable) {
        }
        if (mode == "evdev" && injecting) {
            try {
                frame(listOf(
                    intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot),
                    intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1),
                    intArrayOf(EV_SYN, 0, 0),
                ))
            } catch (ignored: Throwable) { }
        }
        if (mode == "im" && takeActive) takeEnd("выход")
        if (mode == "im" && virtActive) {
            try { virtual(MotionEvent.ACTION_UP, 0, 0) } catch (ignored: Throwable) { }
        }
        System.exit(0)
    }
}
