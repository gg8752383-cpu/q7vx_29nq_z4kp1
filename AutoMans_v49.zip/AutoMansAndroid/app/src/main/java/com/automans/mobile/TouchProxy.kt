package com.automans.mobile

/**
 * Pure logic of the touch proxy (no Android classes, so it can be tested on a normal JVM).
 *
 * The bridge grabs the touchscreen device, so the system gets NO touch events from the glass any more; this class turns the
 * fingers the bridge reads into the only touch stream the game sees (through [Sink]). Because nothing else competes with it:
 *  - a shot is "move the attack finger to the predicted spot, lift it" without the real finger's own reports undoing the move,
 *  - the move stick can be taken over and given back without lifting or re-touching anything.
 *
 * Pointer ids, "which pointers the game was told about" and the order of events follow what Android itself does
 * (ids ascending, DOWN only for the first finger, POINTER_DOWN/UP carry the index of the pointer).
 */
class TouchProxy(private val sink: Sink) {
    interface Sink {
        /** Delivers one touch event to the system; false when it was refused. */
        fun send(downMs: Long, action: Int, ids: IntArray, xs: FloatArray, ys: FloatArray): Boolean
    }

    companion object {
        const val SLOTS = 32
        const val DOWN = 0
        const val UP = 1
        const val MOVE = 2
        const val POINTER_DOWN = 5
        const val POINTER_UP = 6
        const val SHIFT = 8
    }

    // the real fingers (screen pixels)
    private val present = BooleanArray(SLOTS)
    private val pid = IntArray(SLOTS) { -1 }
    private val rx = FloatArray(SLOTS)
    private val ry = FloatArray(SLOTS)
    private val suppressed = BooleanArray(SLOTS)
    /** A shot in progress: the finger sits on the target for a moment (the game must see it there) before it is lifted. */
    private val held = BooleanArray(SLOTS)
    private val holdX = FloatArray(SLOTS)
    private val holdY = FloatArray(SLOTS)
    private val downSeq = LongArray(SLOTS)
    private var seq = 0L

    // what the game has been told, ordered by pointer id
    private val tId = IntArray(SLOTS)
    private val tX = FloatArray(SLOTS)
    private val tY = FloatArray(SLOTS)
    private var tN = 0
    private var downMs = 0L

    // the move stick taken over: either his own finger is moved by us (ovSlot) or, when he has none there, a ghost finger
    private var take = false
    private var ovSlot = -1
    private var ovX = 0f
    private var ovY = 0f
    private var ghostId = -1
    private var ghostX = 0f
    private var ghostY = 0f

    /** Fingers whose position is left of this x (screen pixels) belong to the move stick. */
    @Volatile var leftLimit = 1000f
    @Volatile var failures = 0
        private set
    @Volatile var sent = 0L
        private set

    // scratch for the wanted list
    private val dId = IntArray(SLOTS + 1)
    private val dX = FloatArray(SLOTS + 1)
    private val dY = FloatArray(SLOTS + 1)

    @Synchronized fun isTaken(): Boolean = take
    @Synchronized fun told(): Int = tN
    @Synchronized fun anyFinger(): Boolean { for (s in 0 until SLOTS) if (present[s]) return true; return false }

    @Synchronized fun setFinger(slot: Int, down: Boolean, x: Float, y: Float) {
        if (slot !in 0 until SLOTS) return
        if (down) {
            if (!present[slot]) {
                present[slot] = true
                suppressed[slot] = false
                held[slot] = false
                pid[slot] = freeId()
                downSeq[slot] = ++seq
                if (take && ghostId >= 0 && x < leftLimit) {
                    // he put a finger on the stick while the ghost holds it: the new finger carries on from the ghost's place
                    ovSlot = slot; ovX = ghostX; ovY = ghostY; ghostId = -1
                }
            }
            rx[slot] = x
            ry[slot] = y
        } else if (present[slot]) {
            present[slot] = false
            if (slot == ovSlot) {
                // his finger left while we steer: the stick stays where we hold it, now as a ghost with the same id
                ghostId = pid[slot]; ghostX = ovX; ghostY = ovY; ovSlot = -1
            }
            pid[slot] = -1
            suppressed[slot] = false
            held[slot] = false
        }
    }

    private fun freeId(): Int {
        var id = 0
        while (id < SLOTS - 1) {
            var used = id == ghostId
            if (!used) for (s in 0 until SLOTS) if (present[s] && pid[s] == id) { used = true; break }
            if (!used) for (i in 0 until tN) if (tId[i] == id) { used = true; break }
            if (!used) return id
            id++
        }
        return id
    }

    /** Brings what the game has been told in line with the fingers now (lifts, new touches, then one move). */
    @Synchronized fun flush(nowMs: Long): Boolean {
        var n = 0
        for (s in 0 until SLOTS) {
            if (!present[s] || suppressed[s]) continue
            dId[n] = pid[s]
            if (s == ovSlot) { dX[n] = ovX; dY[n] = ovY } else if (held[s]) { dX[n] = holdX[s]; dY[n] = holdY[s] } else { dX[n] = rx[s]; dY[n] = ry[s] }
            n++
        }
        if (ghostId >= 0) { dId[n] = ghostId; dX[n] = ghostX; dY[n] = ghostY; n++ }
        // sort by id (few elements)
        for (i in 1 until n) {
            var j = i
            while (j > 0 && dId[j - 1] > dId[j]) {
                val a = dId[j]; dId[j] = dId[j - 1]; dId[j - 1] = a
                val bx = dX[j]; dX[j] = dX[j - 1]; dX[j - 1] = bx
                val by = dY[j]; dY[j] = dY[j - 1]; dY[j - 1] = by
                j--
            }
        }
        var ok = true
        // 1) fingers that are gone
        var i = 0
        while (i < tN) {
            var wanted = false
            for (j in 0 until n) if (dId[j] == tId[i]) { wanted = true; break }
            if (wanted) { i++; continue }
            ok = emit(UP, i, nowMs) && ok
            removeTold(i)
        }
        // 2) new fingers
        for (j in 0 until n) {
            var have = false
            for (k in 0 until tN) if (tId[k] == dId[j]) { have = true; break }
            if (have) continue
            var at = tN
            while (at > 0 && tId[at - 1] > dId[j]) {
                tId[at] = tId[at - 1]; tX[at] = tX[at - 1]; tY[at] = tY[at - 1]
                at--
            }
            tId[at] = dId[j]; tX[at] = dX[j]; tY[at] = dY[j]
            tN++
            if (tN == 1) downMs = nowMs
            ok = emit(DOWN, at, nowMs) && ok
        }
        // 3) movement of the fingers that stay
        var changed = false
        for (j in 0 until n) {
            for (k in 0 until tN) {
                if (tId[k] != dId[j]) continue
                if (Math.abs(tX[k] - dX[j]) > 0.05f || Math.abs(tY[k] - dY[j]) > 0.05f) { tX[k] = dX[j]; tY[k] = dY[j]; changed = true }
            }
        }
        if (changed) ok = emit(MOVE, 0, nowMs) && ok
        return ok
    }

    private fun removeTold(i: Int) {
        for (k in i until tN - 1) { tId[k] = tId[k + 1]; tX[k] = tX[k + 1]; tY[k] = tY[k + 1] }
        tN--
    }

    /** kind: DOWN / UP (for the pointer at index idx of the told list, which already includes it) or MOVE. */
    private fun emit(kind: Int, idx: Int, nowMs: Long): Boolean {
        if (tN == 0) return true
        val action = when (kind) {
            DOWN -> if (tN == 1) DOWN else (POINTER_DOWN or (idx shl SHIFT))
            UP -> if (tN == 1) UP else (POINTER_UP or (idx shl SHIFT))
            else -> MOVE
        }
        val ok = sink.send(downMs, action, tId.copyOf(tN), tX.copyOf(tN), tY.copyOf(tN))
        if (ok) { failures = 0; sent++ } else failures++
        return ok
    }

    /** True when a shot can be started for this finger: it is down, not already shot and not the stick we steer. */
    @Synchronized fun canFire(slot: Int): Boolean =
        slot in 0 until SLOTS && present[slot] && !suppressed[slot] && !held[slot] && slot != ovSlot

    /**
     * First half of a shot: the attack finger of [slot] jumps to (tx, ty) and STAYS there (whatever the real finger does meanwhile);
     * [finishFire] lifts it a moment later, so the game has seen the aim at the target before the release.
     */
    @Synchronized fun fire(slot: Int, tx: Float, ty: Float, nowMs: Long): Boolean {
        flush(nowMs)
        if (!canFire(slot)) return false
        val id = pid[slot]
        var k = -1
        for (i in 0 until tN) if (tId[i] == id) { k = i; break }
        if (k < 0) return false
        held[slot] = true
        holdX[slot] = tx
        holdY[slot] = ty
        return flush(nowMs)
    }

    /** Second half of a shot: lifts the finger where it was put. The real finger stays dead for the game until it is lifted for real. */
    @Synchronized fun finishFire(slot: Int, nowMs: Long): Boolean {
        if (slot !in 0 until SLOTS || !held[slot]) return false
        held[slot] = false
        suppressed[slot] = true
        return flush(nowMs)
    }

    /** True while a shot of this slot waits for its release. */
    @Synchronized fun isHeld(slot: Int): Boolean = slot in 0 until SLOTS && held[slot]

    @Synchronized fun takeStart(bx: Float, by: Float, nowMs: Long): Boolean {
        if (take) { takeSteer(bx, by, nowMs); return true }
        var s = -1
        for (slot in 0 until SLOTS) {
            if (!present[slot] || suppressed[slot] || rx[slot] >= leftLimit) continue
            if (s < 0 || downSeq[slot] < downSeq[s]) s = slot
        }
        if (s >= 0) { ovSlot = s; ovX = bx; ovY = by } else { ghostId = freeId(); ghostX = bx; ghostY = by }
        take = true
        flush(nowMs)
        return true
    }

    @Synchronized fun takeSteer(x: Float, y: Float, nowMs: Long) {
        if (!take) return
        if (ovSlot >= 0) { ovX = x; ovY = y } else if (ghostId >= 0) { ghostX = x; ghostY = y }
        flush(nowMs)
    }

    @Synchronized fun takeEnd(nowMs: Long) {
        if (!take) return
        take = false
        ovSlot = -1
        ghostId = -1
        flush(nowMs)
    }

    /** Lifts everything the game was told about (before the grab is let go, or on exit). */
    @Synchronized fun releaseAll(nowMs: Long) {
        take = false
        ovSlot = -1
        ghostId = -1
        while (tN > 0) {
            emit(UP, tN - 1, nowMs)
            tN--
        }
        for (s in 0 until SLOTS) { present[s] = false; pid[s] = -1; suppressed[s] = false; held[s] = false }
    }
}
