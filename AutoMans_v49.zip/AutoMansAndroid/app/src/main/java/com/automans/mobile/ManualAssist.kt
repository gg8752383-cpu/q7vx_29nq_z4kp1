package com.automans.mobile

import kotlin.math.min

/**
 * The player aims with his own finger on the attack stick. The very moment the white aim line touches an enemy (or passes
 * close to him) the finger is moved to where that enemy will be when the shot arrives and lifted: one shot, at once.
 *
 * While the bridge owns the touchscreen (the normal case) the decision is made INSIDE the bridge, on every touchscreen report,
 * and this class only hands it the settings and every new picture's enemy list. When the bridge could not take the screen over,
 * this class makes the same decision itself (with the same [AssistCore]) and asks the bridge to inject the shot.
 */
class ManualAssist {
    private var snap: EnemyAutoAim.Snapshot? = null
    private var w = 0
    private var h = 0
    private var picTimeMs = 0L
    private var ammo = -1
    private var pvx = 0f
    private var pvy = 0f
    private var fireAmmo = -1
    private var fireAtMs = 0L
    private var lastFireMs = 0L
    private var lastLogMs = 0L
    private var lastDiagMs = 0L
    private var lastNoFingerMs = 0L
    private val cfg = AssistCore.Cfg()
    private val out = AssistCore.Out()

    /** New picture analysed: tell the bridge, or (without the bridge's screen takeover) check right away. */
    @Synchronized fun update(
        snapshot: EnemyAutoAim.Snapshot, w: Int, h: Int, s: DodgeSettings, lobbed: Boolean, rangePx: Float, ammo: Int,
        frameAgeMs: Float, pvx: Float, pvy: Float,
    ) {
        val now = android.os.SystemClock.elapsedRealtime()
        this.snap = snapshot
        // when the picture was really taken, on the same clock as "now"
        this.picTimeMs = now - frameAgeMs.toLong()
        this.w = w; this.h = h; this.ammo = ammo
        val minDim = min(w, h).toFloat()
        cfg.minDim = minDim
        cfg.radius = minDim * s.attackRadiusPct.coerceIn(0.04f, 0.14f)
        cfg.bx = w * s.attackX.coerceIn(0.65f, 0.97f)
        cfg.by = h * s.attackY.coerceIn(0.55f, 0.95f)
        cfg.rangePx = rangePx
        cfg.lobbed = lobbed
        cfg.on = true
        cfg.projPx = BrawlerData.speedPx(s.brawler, minDim)
        cfg.latencyMs = 70f
        cfg.mirror = s.autoDodge
        cfg.jx = w * s.joystickX.coerceIn(0.03f, 0.25f)
        cfg.jy = h * s.joystickY.coerceIn(0.55f, 0.95f)
        cfg.jr = minDim * s.joystickRadiusPct.coerceIn(0.04f, 0.14f)
        cfg.moveSpeed = BrawlerData.movePx(s.brawler, minDim)
        this.pvx = pvx; this.pvy = pvy
        if (ShellTouch.ready) {
            ShellTouch.assistConfig(cfg)
            if (ShellTouch.proxyActive) ShellTouch.assistFrame(frameAgeMs, snapshot, pvx, pvy)
        }
        // did the last shot really go off? the ammo pips under the fighter tell
        if (fireAtMs != 0L && now - fireAtMs >= 260L) {
            if (ammo >= 0 && fireAmmo >= 0) AimLog.add("ПРОВЕРКА выстрела: патронов было %d, стало %d — %s".format(fireAmmo, ammo, if (ammo < fireAmmo) "выстрел прошёл" else "выстрел НЕ прошёл"))
            fireAtMs = 0L
        }
        if (!ShellTouch.proxyActive) evaluate(now)
    }

    /** The assist is switched off in the settings. */
    fun disable() {
        if (ShellTouch.ready) { cfg.on = false; ShellTouch.assistConfig(cfg) }
    }

    /** The bridge has just made a shot (reported on its output). */
    @Synchronized fun noteShot() {
        fireAmmo = ammo
        fireAtMs = android.os.SystemClock.elapsedRealtime()
        MansAccessibilityService.shotCounter++
    }

    /** The player's finger moved: check with the enemies we know (only used without the bridge's screen takeover). */
    @Synchronized fun onFinger() {
        if (snap == null || ShellTouch.proxyActive) return
        evaluate(android.os.SystemClock.elapsedRealtime())
    }

    private fun evaluate(now: Long) {
        val sn = snap ?: return
        if (!ShellTouch.ready || w < 100 || h < 100) return
        if (now - lastFireMs < 70L) return
        val f = ShellTouch.attackFinger(cfg.bx, cfg.by, cfg.radius)
        if (f == null) {
            if (ShellTouch.fingerCount() > 0 && now - lastNoFingerMs > 6000L) {
                lastNoFingerMs = now
                AimLog.add("ПОМОЩЬ: пальцев на экране ${ShellTouch.fingerCount()}, но у кнопки атаки пальца нет")
            }
            return
        }
        val picAge = now - picTimeMs
        if (!AssistCore.evaluate(cfg, sn.n, sn.d, sn.originX, sn.originY, picAge, pvx, pvy, f[1].toFloat(), f[2].toFloat(), f[4].toFloat(), f[5].toFloat(), f[6].toFloat(), out)) {
            if (out.reason != AssistCore.R_CENTER && now - lastDiagMs > 1500L) {
                lastDiagMs = now
                AimLog.add("ПОМОЩЬ (без захвата): " + AssistCore.reasonText(out, picAge))
            }
            return
        }
        val ok = ShellTouch.fire(f[0].toInt(), out.tx, out.ty)
        lastFireMs = now
        fireAmmo = ammo
        fireAtMs = now
        MansAccessibilityService.shotCounter++
        if (now - lastLogMs > 250L) {
            lastLogMs = now
            AimLog.add(
                "ВЫСТРЕЛ (без захвата): враг %.0f px, упреждение %.0f px, скорость врага %.0f px/с, точность линии %.0f из %.0f px, патронов %d, кадру %d мс, отчёту пальца %.0f мс, палец-ход %s"
                    .format(java.util.Locale.US, out.dist, out.lead, out.speed, out.perp, out.tol, ammo, picAge, f[6], if (ok) "ок" else "ОШИБКА"),
            )
        }
    }
}
