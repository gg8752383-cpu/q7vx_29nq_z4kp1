package com.automans.mobile

import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.BufferedReader
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Runs in a separate process with ADB (shell) rights, started through Shizuku with app_process.
 *  - It always READS the real touchscreen (/dev/input/eventN) and tells the app where the player's fingers are.
 *  - To touch the screen it first tries to WRITE into the same device (an unused slot, "evdev" mode).
 *    Many phones (Samsung) forbid that for the shell; then it injects Android touch events instead ("im" mode):
 *      * "F": the player's own attack finger is moved to the predicted spot and lifted, as part of the SAME touch device
 *        stream, so the game sees exactly one release there and the other fingers are untouched;
 *      * "D/M/U": one extra finger on a virtual touch device (used for the move stick).
 *
 * Arguments: <device> <injectSlot> <eventSize 24|16> <extras "code=value,..."> [writePath or -] [touch device name]
 * Commands on stdin (panel coordinates): "T rot sw sh pw ph" geometry, "D x y", "M x y", "U", "F slot x y", "Q".
 * Lines on stdout: "READY evdev|im|ro", then "D slot x y", "M slot x y", "U slot" for the player's fingers,
 * and "ERR ..." / "INF ..." diagnostics.
 */
object InputBridge {
    private const val EV_SYN = 0
    private const val EV_KEY = 1
    private const val EV_ABS = 3
    private const val ABS_MT_SLOT = 0x2f
    private const val ABS_MT_POSITION_X = 0x35
    private const val ABS_MT_POSITION_Y = 0x36
    private const val ABS_MT_TRACKING_ID = 0x39
    private const val BTN_TOUCH = 0x14a
    private const val SLOTS = 32
    private const val POINTER_SHIFT = 8

    private val trackId = IntArray(SLOTS) { -1 }
    private val posX = IntArray(SLOTS)
    private val posY = IntArray(SLOTS)
    private val lastEmit = LongArray(SLOTS)
    private val pointerId = IntArray(SLOTS) { -1 }
    private val lock = Any()
    private var gestureDownMs = 0L

    @Volatile private var userFingers = 0
    private var injecting = false
    private var nextTid = 52000

    // geometry for the injected mode
    private var rot = 1
    private var sw = 2340
    private var sh = 1080
    private var pw = 1080
    private var ph = 2340

    // injected mode
    private var injTarget: Any? = null
    private var injMethod: Method? = null
    private var injArgs = 2
    private var touchDeviceId = -1
    private var virtDownMs = 0L
    private var virtActive = false
    private var errCount = 0
    private var fireInfoCount = 0
    /** When the touchscreen last sent a report (nanoTime), how often it does, and how many reports there were so far. */
    @Volatile private var lastSynNs = 0L
    @Volatile private var periodNs = 8_300_000L
    @Volatile private var synCount = 0L

    // ---- touch proxy (the bridge owns the touchscreen while the game is in front) ----
    private const val EVIOCGRAB = 0x40044590
    @Volatile private var wantProxy = false
    @Volatile private var proxyOn = false
    @Volatile private var proxyDisabled = false
    @Volatile private var lastBeatMs = 0L
    @Volatile private var reopenRequested = false
    @Volatile private var curIn: FileInputStream? = null
    @Volatile private var geometryKnown = false
    private val grabLock = Any()
    private var proxyLogCount = 0
    private var proxyFireLog = 0
    private val proxy = TouchProxy(object : TouchProxy.Sink {
        override fun send(downMs: Long, action: Int, ids: IntArray, xs: FloatArray, ys: FloatArray): Boolean {
            val t0 = System.nanoTime()
            val ok = inject(motion(downMs, action, ids, xs, ys, touchDeviceId))
            if (proxyLogCount < 5) {
                proxyLogCount++
                say("INF прокси: действие=$action пальцев=${ids.size} ${if (ok) "внедрено" else "ОТКЛОНЕНО"} за %.2f мс".format(java.util.Locale.US, (System.nanoTime() - t0) / 1_000_000f))
            }
            return ok
        }
    })

    // ---- the shot decision inside the bridge: no round trip through the app, judged on every touchscreen report ----
    private const val HOLD_MS = 28L
    private const val MIRROR_MS = 400L
    private const val ASSIST_COOLDOWN_MS = 60L
    private val assistLock = Any()
    private val acfg = AssistCore.Cfg()
    @Volatile private var acfgOk = false
    private val aout = AssistCore.Out()
    private var aN = 0
    private var aD = FloatArray(0)
    private var aOx = 0f
    private var aOy = 0f
    private var aPvx = 0f
    private var aPvy = 0f
    private var aPicMs = 0L // when (this process's clock, ms) the picture with the enemies was taken
    private val afOn = BooleanArray(SLOTS)
    private val afSeq = LongArray(SLOTS)
    private var afCounter = 0L
    private val afDX = FloatArray(SLOTS)
    private val afDY = FloatArray(SLOTS)
    private val afCX = FloatArray(SLOTS)
    private val afCY = FloatArray(SLOTS)
    private val afPX = FloatArray(SLOTS)
    private val afPY = FloatArray(SLOTS)
    private val afCT = LongArray(SLOTS)
    private val afPT = LongArray(SLOTS)
    private var lastShotMs = 0L
    private var lastDiagMs = 0L
    private var shotCount = 0
    private var eCount = 0L
    private var lastStatMs = 0L
    private var lastStatSent = 0L
    private val timer: java.util.concurrent.ScheduledExecutorService by lazy {
        java.util.concurrent.Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "shot-timer").also { it.isDaemon = true } }
    }

    private fun afUpdate(s: Int, nowNs: Long) {
        synchronized(assistLock) {
            if (trackId[s] >= 0) {
                val sp = toScreen(posX[s].toFloat(), posY[s].toFloat())
                if (!afOn[s]) {
                    afOn[s] = true; afSeq[s] = ++afCounter
                    afDX[s] = sp[0]; afDY[s] = sp[1]
                    afCX[s] = sp[0]; afCY[s] = sp[1]; afPX[s] = sp[0]; afPY[s] = sp[1]
                    afCT[s] = nowNs; afPT[s] = nowNs
                } else {
                    afPX[s] = afCX[s]; afPY[s] = afCY[s]; afPT[s] = afCT[s]
                    afCX[s] = sp[0]; afCY[s] = sp[1]; afCT[s] = nowNs
                }
            } else afOn[s] = false
        }
    }

    // ---- "copy the enemy's step": while a burst flies out, the fighter walks with the enemy so every bullet meets him ----
    private val mirrorLock = Any()
    private var mirrorOwns = false
    private var mirrorStartMs = 0L
    private var mirrorUntil = 0L
    private var mirrorDx = 0f
    private var mirrorDy = 0f
    private var mirrorDuty = 1f
    private var mirrorBx = 0f
    private var mirrorBy = 0f
    private var mirrorTx = 0f
    private var mirrorTy = 0f
    private var mirrorLogCount = 0
    /** The app steers the move stick itself (a dodge): the mirror must not touch it. */
    @Volatile private var appTake = false
    @Volatile private var mirrorVx = 0f
    @Volatile private var mirrorVy = 0f

    private fun endMirror(why: String, giveBack: Boolean) {
        synchronized(mirrorLock) {
            if (!mirrorOwns) return
            mirrorOwns = false
            mirrorVx = 0f
            mirrorVy = 0f
            if (giveBack) { try { proxy.takeEnd(System.nanoTime() / 1_000_000L) } catch (ignored: Throwable) { } }
            if (mirrorLogCount++ < 8) say("INF копирование шага врага закончено ($why)")
        }
    }

    private fun mirrorTick() {
        synchronized(mirrorLock) {
            if (!mirrorOwns) return
            val now = System.nanoTime() / 1_000_000L
            if (!proxyOn || appTake) { endMirror(if (appTake) "стик взял уклон" else "захват снят", false); return }
            if (now >= mirrorUntil) { endMirror("время вышло", true); return }
            val period = 100L
            val on = mirrorDuty >= 0.92f || ((now - mirrorStartMs) % period) < (mirrorDuty * period).toLong()
            try { proxy.takeSteer(if (on) mirrorTx else mirrorBx, if (on) mirrorTy else mirrorBy, now) } catch (ignored: Throwable) { }
            takeLastMs = now
            mirrorVx = mirrorDx * mirrorDuty * acfg.moveSpeed
            mirrorVy = mirrorDy * mirrorDuty * acfg.moveSpeed
            try { timer.schedule(Runnable { mirrorTick() }, 25L, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: Throwable) { endMirror("ошибка таймера", true) }
        }
    }

    /** Starts (or prolongs) walking with the enemy whose real speed is (wx, wy) px/s. */
    private fun startMirror(wx: Float, wy: Float, nowMs: Long) {
        val sp = Math.hypot(wx.toDouble(), wy.toDouble()).toFloat()
        if (!acfg.mirror || sp < acfg.minDim * 0.10f || sp < 1f) return
        val dx = wx / sp
        val dy = wy / sp
        // his own move finger: the earliest finger down on the left half
        var f = -1
        var hisX = 0f
        var hisY = 0f
        var baseX = acfg.jx
        var baseY = acfg.jy
        synchronized(assistLock) {
            for (s in 0 until SLOTS) {
                if (!afOn[s] || afDX[s] >= sw * 0.5f) continue
                if (f < 0 || afSeq[s] < afSeq[f]) f = s
            }
            if (f >= 0) { baseX = afDX[f]; baseY = afDY[f]; hisX = afCX[f]; hisY = afCY[f] }
        }
        if (f >= 0) {
            // he already walks the same way himself: let him
            val hl = Math.hypot((hisX - baseX).toDouble(), (hisY - baseY).toDouble()).toFloat()
            if (hl > acfg.minDim * 0.04f && ((hisX - baseX) * dx + (hisY - baseY) * dy) / hl > 0.8f) return
        }
        synchronized(mirrorLock) {
            if (appTake) return
            val tx = baseX + dx * acfg.jr * 0.92f
            val ty = baseY + dy * acfg.jr * 0.92f
            mirrorDx = dx; mirrorDy = dy
            mirrorDuty = (sp / acfg.moveSpeed.coerceAtLeast(1f)).coerceIn(0.3f, 1f)
            mirrorBx = baseX; mirrorBy = baseY; mirrorTx = tx; mirrorTy = ty
            mirrorUntil = nowMs + MIRROR_MS
            if (mirrorOwns) return
            if (proxy.isTaken()) return
            mirrorOwns = true
            mirrorStartMs = nowMs
            takeLastMs = nowMs
            // his own finger is simply carried to the target; with no finger on the stick a new one goes down at the rest place first
            if (f >= 0) proxy.takeStart(tx, ty, nowMs) else proxy.takeStart(baseX, baseY, nowMs)
            if (mirrorLogCount++ < 8) say("INF копирую шаг врага: %.0f px/с, ${if (f >= 0) "перехватил твой стик" else "стик был свободен"}".format(java.util.Locale.US, sp))
            try { timer.schedule(Runnable { mirrorTick() }, 25L, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: Throwable) { endMirror("ошибка таймера", true) }
        }
    }

    /** Judges the attack finger against the enemies we know; when the aim line meets one, the shot goes out right now. */
    private fun assistTick(nowNs: Long) {
        if (!proxyOn || !acfgOk) return
        val nowMs = nowNs / 1_000_000L
        var slot = -1
        var tx = 0f
        var ty = 0f
        var info = ""
        var diag = ""
        var wvx = 0f
        var wvy = 0f
        synchronized(assistLock) {
            if (!acfg.on || nowMs - lastShotMs < ASSIST_COOLDOWN_MS) return
            var best = -1
            for (s in 0 until SLOTS) {
                if (!afOn[s]) continue
                if (Math.hypot((afDX[s] - acfg.bx).toDouble(), (afDY[s] - acfg.by).toDouble()) > acfg.radius * 1.6) continue
                if (best < 0 || afSeq[s] < afSeq[best]) best = s
            }
            if (best < 0 || !proxy.canFire(best)) return
            val picAge = if (aPicMs == 0L) 100000L else nowMs - aPicMs
            var fvx = 0f
            var fvy = 0f
            val dtp = (afCT[best] - afPT[best]) / 1_000_000.0
            if (dtp in 2.0..40.0) {
                fvx = ((afCX[best] - afPX[best]) / dtp * 1000.0).toFloat()
                fvy = ((afCY[best] - afPY[best]) / dtp * 1000.0).toFloat()
            }
            val fAge = (nowNs - afCT[best]) / 1_000_000f
            // the fighter's own speed: the app's figure, or what the mirror is making him do right now
            val pvx = if (mirrorOwns) mirrorVx else aPvx
            val pvy = if (mirrorOwns) mirrorVy else aPvy
            if (!AssistCore.evaluate(acfg, aN, aD, aOx, aOy, picAge, pvx, pvy, afCX[best], afCY[best], fvx, fvy, fAge, aout)) {
                if (aout.reason != AssistCore.R_CENTER && nowMs - lastDiagMs > 1500L) {
                    lastDiagMs = nowMs
                    diag = AssistCore.reasonText(aout, picAge)
                }
            } else {
                lastShotMs = nowMs
                slot = best
                tx = aout.tx
                ty = aout.ty
                wvx = aout.wvx
                wvy = aout.wvy
                info = "%.0f %.0f %.0f %.0f %.0f %d %.0f %.0f %.0f %.0f %.0f".format(java.util.Locale.US, aout.dist, aout.lead, aout.speed, aout.perp, aout.tol, picAge, fAge, aout.wvx, aout.wvy, aout.flightMs, if (acfg.mirror && aout.speed >= acfg.minDim * 0.10f) 1f else 0f)
            }
        }
        if (diag.isNotEmpty()) say("NOSHOT $diag")
        if (slot < 0) return
        val ok = startShot(slot, tx, ty, nowMs)
        shotCount++
        say("SHOT ${if (ok) 1 else 0} $slot $info")
        if (ok) startMirror(wvx, wvy, nowMs)
    }

    /** Aim goes onto the target now; the release follows [HOLD_MS] later (the game has to see the aim there first). */
    private fun startShot(slot: Int, tx: Float, ty: Float, nowMs: Long): Boolean {
        val ok = proxy.fire(slot, tx, ty, nowMs)
        if (ok || proxy.isHeld(slot)) {
            try {
                timer.schedule(Runnable { try { proxy.finishFire(slot, System.nanoTime() / 1_000_000L) } catch (ignored: Throwable) { } }, HOLD_MS, java.util.concurrent.TimeUnit.MILLISECONDS)
            } catch (e: Throwable) {
                proxy.finishFire(slot, nowMs)
            }
        }
        return ok
    }

    /** Takes the touchscreen device exclusively (the system stops getting touches from it). Returns null on success, else why not. */
    private fun grabFd(fd: java.io.FileDescriptor): String? {
        val sb = StringBuilder()
        val targets = ArrayList<Pair<Class<*>, Any?>>()
        try {
            val os = Class.forName("libcore.io.Libcore").getField("os").get(null)
            if (os != null) targets.add(Pair(Class.forName("libcore.io.Os"), os))
        } catch (e: Throwable) { sb.append("Libcore: ${e.cause ?: e}; ") }
        try { targets.add(Pair(Class.forName("android.system.Os"), null)) } catch (e: Throwable) { sb.append("android.system.Os: ${e.cause ?: e}; ") }
        for ((cls, obj) in targets) {
            for (m in cls.methods) {
                if (m.name != "ioctlInt") continue
                val pt = m.parameterTypes
                if (pt.size < 2 || pt[0] != java.io.FileDescriptor::class.java) continue
                // with two arguments the third one is not ours to choose: ask a few times, success means the grab is on
                repeat(if (pt.size == 2) 6 else 1) {
                    try {
                        if (pt.size == 2) m.invoke(obj, fd, EVIOCGRAB)
                        else if (pt.size == 3) {
                            val ref = pt[2].getConstructor(Int::class.javaPrimitiveType).newInstance(1)
                            m.invoke(obj, fd, EVIOCGRAB, ref)
                        } else return@repeat
                        return null
                    } catch (e: Throwable) {
                        if (sb.length < 400) sb.append("${cls.simpleName}.ioctlInt/${pt.size}: ${e.cause ?: e}; ")
                    }
                }
            }
        }
        return if (sb.isEmpty()) "нет ioctlInt" else sb.toString()
    }

    private fun tryGrab() {
        synchronized(grabLock) {
            if (proxyOn || proxyDisabled || !geometryKnown || injMethod == null) return
            val fd = try { curIn?.fd } catch (e: Throwable) { null } ?: return
            val why = grabFd(fd)
            if (why != null) {
                proxyDisabled = true
                say("ERR захват экрана не удался, остаюсь на обычном внедрении: $why")
                return
            }
            if (takeActive) takeEnd("захват экрана")
            proxy.releaseAll(System.nanoTime() / 1_000_000L)
            proxyOn = true
            say("GRAB 1")
            say("INF захват экрана включён: касания идут через помощника")
        }
    }

    private fun stopProxy(why: String, permanent: Boolean) {
        synchronized(grabLock) {
            if (!proxyOn) return
            proxyOn = false
            // the screen is given back; taking it again needs a fresh "yes" from the app
            wantProxy = false
            proxy.releaseAll(System.nanoTime() / 1_000_000L)
            if (permanent) proxyDisabled = true
            reopenRequested = true
            try { curIn?.close() } catch (ignored: Throwable) { }
            say("GRAB 0")
            say((if (permanent) "ERR" else "INF") + " захват снят: $why")
        }
    }

    private fun toScreen(x: Float, y: Float): FloatArray {
        val fx = x / pw
        val fy = y / ph
        return when (rot) {
            1 -> floatArrayOf(fy * sw, (1f - fx) * sh)
            3 -> floatArrayOf((1f - fy) * sw, fx * sh)
            2 -> floatArrayOf((1f - fx) * sw, (1f - fy) * sh)
            else -> floatArrayOf(fx * sw, fy * sh)
        }
    }

    private fun say(line: String) {
        synchronized(System.out) { System.out.println(line); System.out.flush() }
    }

    private fun err(what: String, e: Throwable?) {
        if (errCount++ < 12) say("ERR $what" + (if (e != null) ": " + (e.cause ?: e) else ""))
    }

    /** Finds a way to inject touch events as the shell user. Returns null when it worked, else a reason. */
    private fun initInjection(deviceName: String): String? {
        val reasons = StringBuilder()
        // 1) the input service directly
        try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "input") as android.os.IBinder
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            val iim = stub.getMethod("asInterface", android.os.IBinder::class.java).invoke(null, binder)!!
            val m = iim.javaClass.methods.filter { it.name == "injectInputEvent" }.minByOrNull { it.parameterTypes.size }
            if (m != null && m.parameterTypes.size in 2..3) {
                injTarget = iim; injMethod = m; injArgs = m.parameterTypes.size
            } else reasons.append("IInputManager: нет injectInputEvent; ")
        } catch (e: Throwable) {
            reasons.append("IInputManager: ${e.cause ?: e}; ")
        }
        // 2) the InputManager object
        if (injMethod == null) {
            try {
                val c = Class.forName("android.hardware.input.InputManager")
                val inst = c.getDeclaredMethod("getInstance").also { it.isAccessible = true }.invoke(null)!!
                val m = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
                injTarget = inst; injMethod = m; injArgs = 2
            } catch (e: Throwable) {
                reasons.append("InputManager: ${e.cause ?: e}; ")
            }
        }
        if (injMethod == null) return reasons.toString()
        // the real touchscreen as Android knows it: events carrying its id join the player's own touch stream
        try {
            var any = -1
            for (id in InputDevice.getDeviceIds()) {
                val d = InputDevice.getDevice(id) ?: continue
                if ((d.sources and InputDevice.SOURCE_TOUCHSCREEN) != InputDevice.SOURCE_TOUCHSCREEN) continue
                if (any < 0) any = id
                if (deviceName.isNotEmpty() && d.name == deviceName) { touchDeviceId = id; break }
            }
            if (touchDeviceId < 0) touchDeviceId = any
        } catch (e: Throwable) {
            say("INF не получил список устройств ввода: ${e.cause ?: e}")
        }
        say("INF внедрение событий готово, touch-устройство id=$touchDeviceId")
        return null
    }

    private fun inject(ev: MotionEvent): Boolean {
        var good = false
        try {
            val t = injTarget ?: return false
            val m = injMethod ?: return false
            val ok = if (injArgs == 2) m.invoke(t, ev, 0) else m.invoke(t, ev, 0, -1)
            good = ok != false
            if (!good && errCount < 6) err("событие отклонено", null)
        } catch (e: Throwable) {
            err("внедрение", e)
        } finally {
            try { ev.recycle() } catch (ignored: Throwable) { }
        }
        return good
    }

    private fun motion(down: Long, action: Int, ids: IntArray, xs: FloatArray, ys: FloatArray, deviceId: Int): MotionEvent {
        val n = ids.size
        val props = Array(n) { i -> MotionEvent.PointerProperties().also { it.id = ids[i]; it.toolType = MotionEvent.TOOL_TYPE_FINGER } }
        val coords = Array(n) { i -> MotionEvent.PointerCoords().also { it.x = xs[i]; it.y = ys[i]; it.pressure = 1f; it.size = 0.1f } }
        return MotionEvent.obtain(down, (System.nanoTime() / 1_000_000L), action, n, props, coords, 0, 0, 1f, 1f, deviceId, 0, InputDevice.SOURCE_TOUCHSCREEN, 0)
    }

    private fun assignId(slot: Int) {
        val used = BooleanArray(SLOTS)
        var active = 0
        for (s in 0 until SLOTS) if (s != slot && pointerId[s] >= 0) { used[pointerId[s]] = true; active++ }
        var id = 0
        while (id < SLOTS - 1 && used[id]) id++
        pointerId[slot] = id
        if (active == 0) gestureDownMs = (System.nanoTime() / 1_000_000L)
    }

    // ---- takeover of the move stick (injected mode only) ----
    private const val TAKE_ID = 20
    private val takeLock = Any()
    @Volatile private var takeActive = false
    private var takeSlot = -1
    private var takeX = 0f
    private var takeY = 0f
    @Volatile private var takeLastMs = 0L

    private class Pt(val id: Int, val slot: Int, val x: Float, val y: Float)

    /** The fingers the game should see now, ordered by pointer id. Call with [lock] held. */
    private fun points(): List<Pt> {
        val list = ArrayList<Pt>()
        for (s in 0 until SLOTS) {
            if (pointerId[s] < 0) continue
            if (takeActive && s == takeSlot) continue // his move finger is released for the game while we steer
            val p = toScreen(posX[s].toFloat(), posY[s].toFloat())
            list.add(Pt(pointerId[s], s, p[0], p[1]))
        }
        if (takeActive) list.add(Pt(TAKE_ID, -2, takeX, takeY))
        list.sortBy { it.id }
        return list
    }

    /** kind: 0 move, 1 pointer down, 2 pointer up; idx = index (in pts) of the pointer that goes down / up. */
    private fun sendPts(down: Long, pts: List<Pt>, kind: Int, idx: Int) {
        val n = pts.size
        if (n == 0) return
        val action = when (kind) {
            0 -> MotionEvent.ACTION_MOVE
            1 -> if (n == 1) MotionEvent.ACTION_DOWN else (MotionEvent.ACTION_POINTER_DOWN or (idx shl POINTER_SHIFT))
            else -> if (n == 1) MotionEvent.ACTION_UP else (MotionEvent.ACTION_POINTER_UP or (idx shl POINTER_SHIFT))
        }
        inject(motion(down, action, IntArray(n) { pts[it].id }, FloatArray(n) { pts[it].x }, FloatArray(n) { pts[it].y }, touchDeviceId))
    }

    /** Takes the move stick: his own finger there is released for the game, ours takes over at (px,py). */
    private fun takeStart(px: Int, py: Int) {
        synchronized(takeLock) {
            if (takeActive) return
            val now = (System.nanoTime() / 1_000_000L)
            var mvIdx = -1
            var before: List<Pt> = emptyList()
            var down = 0L
            synchronized(lock) {
                before = points()
                down = gestureDownMs
                // his move finger: the one on the left half of the screen
                for (pt in before) if (pt.x < sw * 0.5f) { mvIdx = before.indexOf(pt); break }
                if (mvIdx >= 0) takeSlot = before[mvIdx].slot
            }
            if (mvIdx >= 0) sendPts(down, before, 2, mvIdx) // lift his finger for the game
            val p = toScreen(px.toFloat(), py.toFloat())
            val after: List<Pt>
            synchronized(lock) {
                takeX = p[0]; takeY = p[1]
                takeActive = true
                after = points()
                if (after.size == 1) { gestureDownMs = now; down = now } else down = gestureDownMs
            }
            sendPts(down, after, 1, after.indexOfFirst { it.id == TAKE_ID })
            takeLastMs = now
            say("INF перехват стика: пальцев было ${before.size}, его палец ${if (mvIdx >= 0) "отпущен для игры" else "не найден"}")
        }
    }

    private fun takeSteer(px: Int, py: Int) {
        synchronized(takeLock) {
            if (!takeActive) return
            val p = toScreen(px.toFloat(), py.toFloat())
            val pts: List<Pt>
            val down: Long
            synchronized(lock) { takeX = p[0]; takeY = p[1]; pts = points(); down = gestureDownMs }
            sendPts(down, pts, 0, 0)
            takeLastMs = (System.nanoTime() / 1_000_000L)
        }
    }

    /** Gives the stick back: our finger lifts, his finger (if still on the glass) is put back where it is now. */
    private fun takeEnd(why: String) {
        synchronized(takeLock) {
            if (!takeActive) return
            val now = (System.nanoTime() / 1_000_000L)
            val withTake: List<Pt>
            var down = 0L
            synchronized(lock) { withTake = points(); down = gestureDownMs }
            sendPts(down, withTake, 2, withTake.indexOfFirst { it.id == TAKE_ID })
            val k: Int
            val back: List<Pt>
            synchronized(lock) {
                takeActive = false
                k = takeSlot
                takeSlot = -1
                back = points()
            }
            if (k >= 0 && pointerId[k] >= 0) {
                // his finger is still down: let the game see it again from where it is now
                val idx = back.indexOfFirst { it.slot == k }
                if (back.size == 1) { synchronized(lock) { gestureDownMs = now }; sendPts(now, back, 1, idx) }
                else sendPts(down, back, 1, idx)
            }
            say("INF стик возвращён ($why)")
        }
    }

    /**
     * While the player drags his attack finger, the touchscreen sends a report about every 8 ms, and each one repeats the
     * finger's REAL position. If such a report lands between our "move" and our "lift", the game aims where the finger really
     * is. So the two events go out right after a report has passed and are done long before the next one is due.
     */
    private fun waitQuiet(): Float {
        val t0 = System.nanoTime()
        val period = periodNs.coerceIn(4_000_000L, 16_000_000L)
        val start = 1_500_000L
        val end = maxOf(start + 500_000L, period - 3_200_000L)
        while (true) {
            val now = System.nanoTime()
            val syn = lastSynNs
            val el = now - syn
            if (syn == 0L || el > period * 18 / 10) break // nothing is moving on the glass: no report is due, go now
            if (el in start..end) break
            if (now - t0 > 14_000_000L) break
            java.util.concurrent.locks.LockSupport.parkNanos(250_000L)
        }
        return (System.nanoTime() - t0) / 1_000_000f
    }

    /** The player's attack finger is moved to (px,py) and lifted there, inside the real touch stream. */
    private fun fireInjected(slot: Int, px: Int, py: Int) {
        val waited = waitQuiet()
        val pts: List<Pt>
        val down: Long
        val idx: Int
        synchronized(lock) {
            if (slot !in 0 until SLOTS || pointerId[slot] < 0 || (takeActive && slot == takeSlot)) { err("выстрел: палец не найден (слот $slot)", null); return }
            val list = points()
            idx = list.indexOfFirst { it.slot == slot }
            if (idx < 0) { err("выстрел: палец не в списке (слот $slot)", null); return }
            val t = toScreen(px.toFloat(), py.toFloat())
            pts = list.mapIndexed { i, pt -> if (i == idx) Pt(pt.id, pt.slot, t[0], t[1]) else pt }
            down = gestureDownMs
        }
        val n = pts.size
        val ids = IntArray(n) { pts[it].id }
        val xs = FloatArray(n) { pts[it].x }
        val ys = FloatArray(n) { pts[it].y }
        val upAction = if (n == 1) MotionEvent.ACTION_UP else (MotionEvent.ACTION_POINTER_UP or (idx shl POINTER_SHIFT))
        val mv = motion(down, MotionEvent.ACTION_MOVE, ids, xs, ys, touchDeviceId)
        val up = motion(down, upAction, ids, xs, ys, touchDeviceId)
        val synBefore = synCount
        val t0 = System.nanoTime()
        inject(mv)
        inject(up)
        val gap = (System.nanoTime() - t0) / 1_000_000f
        val between = synCount - synBefore
        if (fireInfoCount++ < 14) {
            say("INF выстрел: пальцев=$n индекс=$idx id=${pts[idx].id} экран=(${pts[idx].x.toInt()},${pts[idx].y.toInt()}) ждал %.1f мс, MOVE→UP %.2f мс, отчётов экрана за это время %d, период %.1f мс"
                .format(java.util.Locale.US, waited, gap, between, periodNs / 1_000_000f))
        }
    }

    private fun virtual(action: Int, px: Int, py: Int) {
        val p = toScreen(px.toFloat(), py.toFloat())
        if (action == MotionEvent.ACTION_DOWN) { virtDownMs = (System.nanoTime() / 1_000_000L); virtActive = true }
        if (!virtActive) return
        inject(motion(virtDownMs, action, intArrayOf(12), floatArrayOf(p[0]), floatArrayOf(p[1]), -1))
        if (action == MotionEvent.ACTION_UP) virtActive = false
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val dev = args[0]
        val injSlot = args[1].toInt()
        val size = args[2].toInt()
        val extras = ArrayList<IntArray>()
        if (args.size > 3 && args[3].isNotEmpty()) {
            for (part in args[3].split(',')) {
                val kv = part.split('=')
                if (kv.size == 2) extras.add(intArrayOf(kv[0].toInt(), kv[1].toInt()))
            }
        }
        val writePath = if (args.size > 4 && args[4] != "-") args[4] else dev
        val deviceName = if (args.size > 5) args[5] else ""
        val stdout = System.out

        // ---- how to touch: write into the device, or inject Android events ----
        var out: FileOutputStream? = null
        var mode = "evdev"
        try {
            out = FileOutputStream(writePath)
        } catch (e: Throwable) {
            say("INF запись в $writePath закрыта (${e.message}), пробую внедрение событий")
            val why = initInjection(deviceName)
            if (why == null) mode = "im" else { say("ERR внедрение не готово: $why"); mode = "ro" }
        }

        val reader = Thread {
            val buf = ByteArray(size)
            val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
            val dirty = BooleanArray(SLOTS)
            var slot = 0
            var again = true
            while (again) {
                again = false
                var input: FileInputStream? = null
                try {
                    input = FileInputStream(dev)
                    curIn = input
                    while (true) {
                        var got = 0
                        while (got < size) {
                            val n = input.read(buf, got, size - got)
                            if (n < 0) return@Thread
                            got += n
                        }
                        val type = bb.getShort(size - 8).toInt() and 0xffff
                        val code = bb.getShort(size - 6).toInt() and 0xffff
                        val value = bb.getInt(size - 4)
                        if (type == EV_ABS) {
                            when (code) {
                                ABS_MT_SLOT -> slot = value.coerceIn(0, SLOTS - 1)
                                ABS_MT_TRACKING_ID -> {
                                    synchronized(lock) {
                                        val old = trackId[slot]
                                        trackId[slot] = value
                                        if (value >= 0 && old < 0) assignId(slot)
                                        else if (value < 0 && old >= 0) pointerId[slot] = -1
                                    }
                                    if (value < 0 && takeActive) {
                                        var anyReal = false
                                        synchronized(lock) { for (q in 0 until SLOTS) if (pointerId[q] >= 0) anyReal = true }
                                        if (!anyReal || slot == takeSlot) takeEnd("палец ушёл")
                                    }
                                    dirty[slot] = true
                                }
                                ABS_MT_POSITION_X -> { posX[slot] = value; dirty[slot] = true }
                                ABS_MT_POSITION_Y -> { posY[slot] = value; dirty[slot] = true }
                            }
                        } else if (type == EV_SYN && code == 0) {
                            val nowNs = System.nanoTime()
                            val prev = lastSynNs
                            if (prev != 0L) {
                                val dd = nowNs - prev
                                if (dd in 2_000_000L..30_000_000L) periodNs = (periodNs * 8 + dd * 2) / 10
                            }
                            lastSynNs = nowNs
                            synCount++
                            // 1) while the bridge owns the screen, what the game sees comes first
                            if (proxyOn) {
                                for (s in 0 until SLOTS) {
                                    if (!dirty[s]) continue
                                    val sp = toScreen(posX[s].toFloat(), posY[s].toFloat())
                                    proxy.setFinger(s, trackId[s] >= 0, sp[0], sp[1])
                                }
                                proxy.flush(nowNs / 1_000_000L)
                                if (proxy.failures >= 4) stopProxy("события не доходят до системы", true)
                            }
                            // 2) tell the app where the fingers are
                            var count = 0
                            val now = System.currentTimeMillis()
                            for (s in 0 until SLOTS) {
                                if (s != injSlot && trackId[s] >= 0) count++
                                if (!dirty[s]) continue
                                dirty[s] = false
                                afUpdate(s, nowNs)
                                if (s == injSlot && mode == "evdev") continue
                                synchronized(stdout) {
                                    if (trackId[s] < 0) {
                                        if (lastEmit[s] != 0L) {
                                            stdout.println("U $s")
                                            lastEmit[s] = 0
                                        }
                                    } else if (lastEmit[s] == 0L) {
                                        stdout.println("D $s ${posX[s]} ${posY[s]}")
                                        lastEmit[s] = now
                                    } else {
                                        stdout.println("M $s ${posX[s]} ${posY[s]}")
                                        lastEmit[s] = now
                                    }
                                    stdout.flush()
                                }
                            }
                            userFingers = count
                            // 2b) the aim line may just have met an enemy: shoot now, before anything else happens
                            if (proxyOn) assistTick(nowNs)
                            // 3) the moment the last finger is up is the safe moment to take the screen over
                            if (count == 0 && mode == "im" && wantProxy && !proxyOn && !proxyDisabled) tryGrab()
                        }
                    }
                } catch (e: Throwable) {
                    if (!reopenRequested) say("ERR read $dev: $e")
                } finally {
                    try { input?.close() } catch (ignored: Throwable) { }
                }
                if (reopenRequested) {
                    // the grab was let go: start reading again from a clean state
                    reopenRequested = false
                    again = true
                    for (s in 0 until SLOTS) {
                        if (lastEmit[s] != 0L) synchronized(stdout) { stdout.println("U $s"); stdout.flush() }
                        lastEmit[s] = 0
                        trackId[s] = -1
                        pointerId[s] = -1
                        dirty[s] = false
                    }
                    synchronized(assistLock) { for (q in 0 until SLOTS) afOn[q] = false }
                    userFingers = 0
                }
            }
        }
        reader.isDaemon = true
        reader.start()

        fun frame(events: List<IntArray>) {
            val o = out ?: return
            val bb = ByteBuffer.allocate(events.size * size).order(ByteOrder.LITTLE_ENDIAN)
            for (e in events) {
                bb.position(bb.position() + (size - 8))
                bb.putShort(e[0].toShort())
                bb.putShort(e[1].toShort())
                bb.putInt(e[2])
            }
            o.write(bb.array())
            o.flush()
        }

        say("READY $mode")
        lastBeatMs = System.nanoTime() / 1_000_000L
        if (mode == "im") {
            val wd = Thread {
                while (true) {
                    try { Thread.sleep(100) } catch (e: InterruptedException) { return@Thread }
                    val nowMs = System.nanoTime() / 1_000_000L
                    if (takeActive && nowMs - takeLastMs > 700L) takeEnd("тишина от приложения")
                    if (proxyOn && proxy.isTaken() && nowMs - takeLastMs > 700L) {
                        appTake = false
                        mirrorOwns = false
                        proxy.takeEnd(nowMs)
                        say("INF стик возвращён (тишина от приложения)")
                    }
                    if (proxyOn && nowMs - lastStatMs > 10000L && proxy.sent != lastStatSent) {
                        lastStatMs = nowMs
                        lastStatSent = proxy.sent
                        say("INF прокси: событий ${proxy.sent}, сбоев подряд ${proxy.failures}, выстрелов $shotCount, картинок от приложения $eCount")
                    }
                    // the app tells us every second that it is alive and wants the screen; without that the screen goes back to the system
                    if (proxyOn && nowMs - lastBeatMs > 4000L) stopProxy("нет связи с приложением", false)
                }
            }
            wd.isDaemon = true
            wd.start()
        }

        val cmds = BufferedReader(InputStreamReader(System.`in`))
        try {
            while (true) {
                val line = cmds.readLine() ?: break
                val p = line.trim().split(' ')
                try {
                    when (p[0]) {
                        "T" -> if (p.size >= 6) {
                            rot = p[1].toInt(); sw = p[2].toInt(); sh = p[3].toInt(); pw = p[4].toInt(); ph = p[5].toInt()
                            proxy.leftLimit = sw * 0.5f
                            geometryKnown = true
                        }
                        "P" -> {
                            val nowMs = System.nanoTime() / 1_000_000L
                            lastBeatMs = nowMs
                            val w = p.size >= 2 && p[1] == "1"
                            if (w != wantProxy) {
                                wantProxy = w
                                if (!w) stopProxy("игра не впереди", false)
                            }
                            // idle phone: nothing is touching the glass, so the screen can be taken over right away
                            if (w && mode == "im" && !proxyOn && !proxyDisabled && userFingers == 0 && System.nanoTime() - lastSynNs > 400_000_000L) tryGrab()
                        }
                        "C" -> if (p.size >= 15) {
                            // C bx by radius minDim rangePx lobbed on projPx latencyMs mirror jx jy jr moveSpeed  (screen px)
                            synchronized(assistLock) {
                                acfg.bx = p[1].toFloat(); acfg.by = p[2].toFloat(); acfg.radius = p[3].toFloat()
                                acfg.minDim = p[4].toFloat(); acfg.rangePx = p[5].toFloat()
                                acfg.lobbed = p[6] == "1"; acfg.on = p[7] == "1"
                                acfg.projPx = p[8].toFloat(); acfg.latencyMs = p[9].toFloat(); acfg.mirror = p[10] == "1"
                                acfg.jx = p[11].toFloat(); acfg.jy = p[12].toFloat(); acfg.jr = p[13].toFloat(); acfg.moveSpeed = p[14].toFloat()
                                acfgOk = true
                            }
                        }
                        "E" -> if (p.size >= 7) {
                            // E ageMs ox oy pvx pvy n  then n*STRIDE numbers: the enemies of the newest picture
                            val nowNs = System.nanoTime()
                            val cnt = p[6].toInt().coerceIn(0, 12)
                            if (p.size >= 7 + cnt * AssistCore.STRIDE) {
                                val arr = FloatArray(cnt * AssistCore.STRIDE) { p[7 + it].toFloat() }
                                synchronized(assistLock) {
                                    aD = arr; aN = cnt
                                    aOx = p[2].toFloat(); aOy = p[3].toFloat()
                                    aPvx = p[4].toFloat(); aPvy = p[5].toFloat()
                                    aPicMs = nowNs / 1_000_000L - p[1].toFloat().toLong() - 2L
                                    eCount++
                                }
                                if (proxyOn) assistTick(nowNs)
                            }
                        }
                        "D" -> if (p.size >= 3) {
                            if (mode == "im") virtual(MotionEvent.ACTION_DOWN, p[1].toInt(), p[2].toInt())
                            else if (mode == "evdev") {
                                val ev = ArrayList<IntArray>()
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, nextTid))
                                nextTid = if (nextTid > 60000) 52000 else nextTid + 1
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[1].toInt()))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[2].toInt()))
                                for (x in extras) ev.add(intArrayOf(EV_ABS, x[0], x[1]))
                                if (userFingers == 0) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 1))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                frame(ev)
                                injecting = true
                            }
                        }
                        "M" -> if (p.size >= 3) {
                            if (mode == "im") virtual(MotionEvent.ACTION_MOVE, p[1].toInt(), p[2].toInt())
                            else if (mode == "evdev" && injecting) {
                                frame(listOf(
                                    intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot),
                                    intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[1].toInt()),
                                    intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[2].toInt()),
                                    intArrayOf(EV_SYN, 0, 0),
                                ))
                            }
                        }
                        "U" -> {
                            if (mode == "im") virtual(MotionEvent.ACTION_UP, 0, 0)
                            else if (mode == "evdev" && injecting) {
                                val ev = ArrayList<IntArray>()
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1))
                                if (userFingers == 0) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 0))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                frame(ev)
                                injecting = false
                            }
                        }
                        "F" -> if (p.size >= 4) {
                            val slot = p[1].toInt().coerceIn(0, SLOTS - 1)
                            if (mode == "im" && proxyOn) {
                                val sp = toScreen(p[2].toFloat(), p[3].toFloat())
                                val t0 = System.nanoTime()
                                val ok = startShot(slot, sp[0], sp[1], t0 / 1_000_000L)
                                if (proxyFireLog++ < 14) say("INF выстрел через захват: ${if (ok) "ок" else "палец не найден"} за %.2f мс, экран=(${sp[0].toInt()},${sp[1].toInt()})".format(java.util.Locale.US, (System.nanoTime() - t0) / 1_000_000f))
                            } else if (mode == "im") fireInjected(slot, p[2].toInt(), p[3].toInt())
                            else if (mode == "evdev") {
                                // fire: move the player's finger to a new spot and let go of it, in one write,
                                // so the game sees the last move and the release at the new position
                                val ev = ArrayList<IntArray>()
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, slot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[2].toInt()))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[3].toInt()))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, slot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1))
                                if (userFingers <= 1 && !injecting) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 0))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                frame(ev)
                            }
                        }
                        "G" -> if (p.size >= 3 && mode == "im") {
                            appTake = true
                            if (mirrorOwns) endMirror("стик взял уклон", false)
                            if (proxyOn) {
                                val sp = toScreen(p[1].toFloat(), p[2].toFloat())
                                val nowMs = System.nanoTime() / 1_000_000L
                                val was = proxy.isTaken()
                                proxy.takeStart(sp[0], sp[1], nowMs)
                                takeLastMs = nowMs
                                if (!was) say("INF перехват стика через захват")
                            } else takeStart(p[1].toInt(), p[2].toInt())
                        }
                        "S" -> if (p.size >= 3 && mode == "im") {
                            if (proxyOn) {
                                val sp = toScreen(p[1].toFloat(), p[2].toFloat())
                                val nowMs = System.nanoTime() / 1_000_000L
                                proxy.takeSteer(sp[0], sp[1], nowMs)
                                takeLastMs = nowMs
                            } else takeSteer(p[1].toInt(), p[2].toInt())
                        }
                        "H" -> if (mode == "im") {
                            appTake = false
                            if (proxyOn) { proxy.takeEnd(System.nanoTime() / 1_000_000L); say("INF стик возвращён (команда)") }
                            else takeEnd("команда")
                        }
                        "Q" -> break
                    }
                } catch (e: java.io.IOException) {
                    err("запись", e)
                } catch (e: NumberFormatException) {
                }
            }
        } catch (ignored: Throwable) {
        }
        if (mode == "evdev" && injecting) {
            try {
                frame(listOf(
                    intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot),
                    intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1),
                    intArrayOf(EV_SYN, 0, 0),
                ))
            } catch (ignored: Throwable) { }
        }
        if (mode == "im" && proxyOn) { try { proxy.releaseAll(System.nanoTime() / 1_000_000L) } catch (ignored: Throwable) { } }
        if (mode == "im" && takeActive) takeEnd("выход")
        if (mode == "im" && virtActive) {
            try { virtual(MotionEvent.ACTION_UP, 0, 0) } catch (ignored: Throwable) { }
        }
        System.exit(0)
    }
}
