package com.automans.mobile

import kotlin.math.abs
import kotlin.math.hypot

/**
 * The shot decision, as pure arithmetic (no Android classes). The same code runs inside the Shizuku bridge, which judges
 * every touchscreen report the moment it arrives, and in the app as a fallback.
 *
 * The player aims with his own finger on the attack stick. The moment the white aim line passes an enemy (touching him or
 * just near him) the answer is "shoot now": the aim is moved onto the spot where that enemy will be when the shot arrives.
 *
 * Enemy list layout, [STRIDE] numbers per enemy, all in screen pixels:
 *   0 x, 1 y (his ground point where he was seen: the centre of the red disc under him), 2 predX, 3 predY (the app's own guess
 *   of where a shot should go), 4 vx, 5 vy (steady speed px/s), 6 behind a wall (0/1), 7 frames seen,
 *   8 fvx, 9 fvy (quick speed from the last few frames), 10 radius of the red floor disc under him (0 = not measured).
 * The camera follows the fighter, so an enemy's speed on screen is his real speed minus the fighter's own speed.
 */
object AssistCore {
    const val STRIDE = 11
    const val X = 0
    const val Y = 1
    const val PX = 2
    const val PY = 3
    const val VX = 4
    const val VY = 5
    const val BLK = 6
    const val SEEN = 7
    const val FVX = 8
    const val FVY = 9
    const val RAD = 10

    const val R_OK = 0
    const val R_NO_ENEMIES = 1
    const val R_STALE = 2
    const val R_CENTER = 3
    const val R_MISS = 4
    const val R_WALL = 5

    class Cfg {
        @JvmField var bx = 0f
        @JvmField var by = 0f
        @JvmField var radius = 1f
        @JvmField var minDim = 1000f
        @JvmField var rangePx = 700f
        @JvmField var lobbed = false
        @JvmField var on = false
        /** Speed of the shot in px/s (the flight time is distance / this). */
        @JvmField var projPx = 1000f
        /** Delay between the decision and the game really firing (hold of the aim + one game frame + the input path), in ms. */
        @JvmField var latencyMs = 70f
        /** Copy the enemy's step for the length of a burst, so that every bullet of it meets him. */
        @JvmField var mirror = false
        /** Move stick: its resting place when nobody touches it, its reach, and the fighter's own speed in px/s. */
        @JvmField var jx = 0f
        @JvmField var jy = 0f
        @JvmField var jr = 100f
        @JvmField var moveSpeed = 200f
        fun set(o: Cfg) {
            bx = o.bx; by = o.by; radius = o.radius; minDim = o.minDim; rangePx = o.rangePx; lobbed = o.lobbed; on = o.on
            projPx = o.projPx; latencyMs = o.latencyMs; mirror = o.mirror; jx = o.jx; jy = o.jy; jr = o.jr; moveSpeed = o.moveSpeed
        }
    }

    class Out {
        @JvmField var reason = R_NO_ENEMIES
        @JvmField var tx = 0f
        @JvmField var ty = 0f
        @JvmField var enemy = -1
        @JvmField var perp = 0f
        @JvmField var tol = 0f
        @JvmField var along = 0f
        @JvmField var dist = 0f
        @JvmField var lead = 0f
        @JvmField var speed = 0f
        @JvmField var nearest = Float.MAX_VALUE
        @JvmField var lineLen = 0f
        @JvmField var enemies = 0
        /** The target's real (world) speed in px/s: his speed on screen plus the fighter's own. */
        @JvmField var wvx = 0f
        @JvmField var wvy = 0f
        /** Time from the decision to the hit that the aim point was worked out for, in ms. */
        @JvmField var flightMs = 0f
    }

    /** How far (px) from the aim line an enemy still counts as "touched": his own size plus some slack that grows with distance. */
    fun tolerance(minDim: Float, along: Float, lineLen: Float, rad: Float = 0f): Float {
        val base = if (rad > 0f) rad.coerceIn(minDim * 0.04f, minDim * 0.12f) else minDim * 0.058f
        return base + minDim * (0.03f + 0.035f * (along / lineLen.coerceAtLeast(1f)).coerceIn(0f, 1f))
    }

    // scratch for the per-enemy working
    private val tmp = FloatArray(8)

    /**
     * Fills tmp with: [0..1] where the enemy is now (relative to the fighter), [2..3] where the shot has to go,
     * [4..5] his steady speed on screen, [6..7] his real speed. Everything relative to the fighter, in px.
     */
    private fun work(c: Cfg, d: FloatArray, i: Int, ox: Float, oy: Float, pvx: Float, pvy: Float, dt: Float) {
        val o = i * STRIDE
        var vx = d[o + VX]
        var vy = d[o + VY]
        val seen = d[o + SEEN]
        if (seen < 3f) { vx = 0f; vy = 0f } else {
            // the quick estimate follows a turn sooner, the steady one is calmer: use both
            val fvx = d[o + FVX]
            val fvy = d[o + FVY]
            if (seen >= 5f) { vx = vx * 0.65f + fvx * 0.35f; vy = vy * 0.65f + fvy * 0.35f }
        }
        val cx = d[o + X] + vx * dt - ox
        val cy = d[o + Y] + vy * dt - oy
        var wx = vx + pvx
        var wy = vy + pvy
        tmp[6] = wx; tmp[7] = wy
        // not a real movement of the enemy (measurement noise or the fighter's own run seen from the camera): stand still
        if (hypot(wx, wy) < c.minDim * 0.05f) { wx = 0f; wy = 0f }
        val proj = if (c.projPx > 100f) c.projPx else 1000f
        var t = c.latencyMs / 1000f + hypot(cx, cy) / proj
        var px = cx
        var py = cy
        for (k in 0 until 3) {
            px = cx + wx * t
            py = cy + wy * t
            t = c.latencyMs / 1000f + hypot(px, py) / proj
        }
        // never run away with a far-fetched guess
        val mx = px - cx
        val my = py - cy
        val mm = hypot(mx, my)
        val cap = c.minDim * 0.45f
        if (mm > cap) { px = cx + mx * cap / mm; py = cy + my * cap / mm }
        tmp[0] = cx; tmp[1] = cy; tmp[2] = px; tmp[3] = py; tmp[4] = vx; tmp[5] = vy
        flight = t * 1000f
    }
    private var flight = 0f

    /**
     * [n]/[d]/[ox]/[oy]: enemies and the fighter's screen position; [picAgeMs]: how old the picture they come from is;
     * [pvx]/[pvy]: the fighter's own speed px/s; [fx]/[fy]: the attack finger (screen px) and [fvx]/[fvy] its speed px/s;
     * [fingerAgeMs]: age of its last report. Returns true (and fills [out]) when a shot should go out now.
     */
    @Synchronized fun evaluate(
        c: Cfg, n: Int, d: FloatArray, ox: Float, oy: Float, picAgeMs: Long, pvx: Float, pvy: Float,
        fx: Float, fy: Float, fvx: Float, fvy: Float, fingerAgeMs: Float, out: Out,
    ): Boolean {
        out.enemy = -1
        out.nearest = Float.MAX_VALUE
        out.enemies = n
        out.tol = tolerance(c.minDim, c.rangePx * 0.5f, c.rangePx)
        if (n <= 0) { out.reason = R_NO_ENEMIES; return false }
        if (picAgeMs > 700L || picAgeMs < -1000L) { out.reason = R_STALE; return false }
        // the finger report is a few ms old and our shot takes a few ms more: judge the line where the finger will be by then
        val ahead = (fingerAgeMs + 6f).coerceIn(0f, 25f) / 1000f
        var lx = fvx * ahead
        var ly = fvy * ahead
        val lm = hypot(lx, ly)
        val cap = c.radius * 0.35f
        if (lm > cap) { lx *= cap / lm; ly *= cap / lm }
        val vx = fx - c.bx + lx
        val vy = fy - c.by + ly
        val mag = hypot(vx, vy)
        if (mag < c.radius * 0.30f) { out.reason = R_CENTER; return false } // still in the dead centre: not aiming yet
        val ux = vx / mag
        val uy = vy / mag
        val reach = if (c.lobbed) c.rangePx * (mag / c.radius).coerceAtMost(1f) else c.rangePx * 1.08f
        val lineLen = reach.coerceAtLeast(c.minDim * 0.25f)
        out.lineLen = lineLen
        // the enemies have moved on since the picture was taken
        val dt = picAgeMs.coerceIn(0L, 150L) / 1000f
        var bestScore = Float.MAX_VALUE
        var best = -1
        var bestPerp = 0f
        var bestTol = 0f
        var bestAlong = 0f
        var wall = false
        for (i in 0 until n) {
            val o = i * STRIDE
            work(c, d, i, ox, oy, pvx, pvy, dt)
            val cx = tmp[0]
            val cy = tmp[1]
            val px = tmp[2]
            val py = tmp[3]
            val aC = cx * ux + cy * uy
            val aP = px * ux + py * uy
            val pC = abs(cx * uy - cy * ux)
            val pP = abs(px * uy - py * ux)
            // two places count as "on the line": where he is now, and where the shot will meet him
            var perp = Float.MAX_VALUE
            var along = 0f
            if (aC >= 0f && pC < perp) { perp = pC; along = aC }
            if (aP >= 0f && pP < perp) { perp = pP; along = aP }
            if (perp == Float.MAX_VALUE) continue
            val tol = tolerance(c.minDim, along, lineLen, d[o + RAD])
            if (along > lineLen + c.minDim * 0.04f) continue // beyond the reach of the shot (only the enemy's own size counts)
            if (perp < out.nearest) out.nearest = perp
            if (perp > tol) continue
            if (d[o + BLK] > 0.5f && !c.lobbed) { wall = true; continue }
            val score = perp / tol
            if (score < bestScore) { bestScore = score; best = i; bestPerp = perp; bestTol = tol; bestAlong = along }
        }
        if (best < 0) { out.reason = if (wall) R_WALL else R_MISS; return false }
        work(c, d, best, ox, oy, pvx, pvy, dt)
        val cx = tmp[0]
        val cy = tmp[1]
        val px = tmp[2]
        val py = tmp[3]
        val dist = hypot(px, py).coerceAtLeast(1f)
        val dx = px / dist
        val dy = py / dist
        val use = if (c.lobbed && c.rangePx > 1f) c.radius * (dist / c.rangePx).coerceIn(0.12f, 1f) else c.radius * 0.95f
        out.tx = c.bx + dx * use
        out.ty = c.by + dy * use
        out.enemy = best
        out.perp = bestPerp
        out.tol = bestTol
        out.along = bestAlong
        out.dist = hypot(cx, cy)
        out.lead = hypot(px - cx, py - cy)
        out.speed = hypot(tmp[6], tmp[7])
        out.wvx = tmp[6]
        out.wvy = tmp[7]
        out.flightMs = flight
        out.reason = R_OK
        return true
    }

    fun reasonText(out: Out, picAgeMs: Long): String = when (out.reason) {
        R_NO_ENEMIES -> "врагов не вижу"
        R_STALE -> "картинка старая (%d мс)".format(java.util.Locale.US, picAgeMs)
        R_CENTER -> "палец ещё в центре кнопки"
        R_WALL -> "враг на линии, но между вами стена"
        R_MISS -> "врагов %d, ближе всего к линии %s (надо ≤ %.0f px), длина линии %.0f px, кадр %d мс".format(
            java.util.Locale.US, out.enemies,
            if (out.nearest == Float.MAX_VALUE) "—" else "%.0f px".format(java.util.Locale.US, out.nearest),
            out.tol, out.lineLen, picAgeMs,
        )
        else -> "ок"
    }
}
