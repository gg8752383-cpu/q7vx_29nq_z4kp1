package com.automans.mobile

import kotlin.math.hypot
import kotlin.math.min

/**
 * Max is the fastest brawler and can move while he shoots, so the helper keeps him moving sideways to the
 * nearest enemy (a straight bullet is aimed where he WAS), with a step back when the enemy is close or rushing in.
 * It never fights the player: it only moves when the player has not touched the move stick for a moment, uses
 * the extra ADB finger, and lets go the instant the player puts his own finger on the left half.
 */
class AutoDodge {
    private var holding = false
    private var holdStartMs = 0L
    private var segEndMs = 0L
    private var lastReleaseMs = 0L
    private var lastMoveMs = 0L
    private var lastX = 0f
    private var lastY = 0f
    private var sign = 1
    private var baseX = 0f
    private var baseY = 0f
    private val rnd = java.util.Random()

    /** Unit direction of what the helper is doing on the stick now (0,0 when idle); used to keep aim prediction right. */
    @Volatile var vx = 0f
        private set
    @Volatile var vy = 0f
        private set
    @Volatile var isHolding = false
        private set

    @Synchronized fun frame(d: AimDecision?, w: Int, h: Int, s: DodgeSettings, now: Long, originX: Float, originY: Float, otherInjectBusy: Boolean) {
        if (!s.autoDodge || !ShellTouch.ready || d == null || w < 100 || h < 100) { release(now, "нет угрозы"); return }
        val minDim = min(w, h).toFloat()
        val ex = d.targetX - originX
        val ey = d.targetY - originY
        val dist = hypot(ex, ey)
        if (dist < 1f || dist > minDim * 0.80f) { release(now, "враг далеко"); return }
        // the player took the move stick: he always wins
        if (holding && ShellTouch.leftTouchedSince(holdStartMs)) { release(now, "ты взялся за стик движения"); lastReleaseMs = now + 400L; return }
        // short bursts with a rest between them: a touch of the player that lands while the helper holds the stick would be ignored by the game
        if (holding && now - holdStartMs > 800L) { release(now); return }
        if (!holding) {
            if (otherInjectBusy) return
            if (now - lastReleaseMs < 300L) return
            if (ShellTouch.leftIdleMs(now) < 450L) return
            val radius = minDim * s.joystickRadiusPct.coerceIn(0.04f, 0.14f)
            baseX = w * s.joystickX.coerceIn(0.03f, 0.25f)
            baseY = h * s.joystickY.coerceIn(0.55f, 0.95f)
            if (!ShellTouch.down(baseX, baseY)) return
            holding = true
            isHolding = true
            holdStartMs = now
            segEndMs = now + 300L + rnd.nextInt(240)
            sign = if (rnd.nextBoolean()) 1 else -1
            lastX = baseX
            lastY = baseY
            lastMoveMs = 0L
            AimLog.add("УКЛОНЕНИЕ: пошёл боком к врагу (расстояние %.2f экрана)".format(java.util.Locale.US, dist / minDim))
        }
        if (now >= segEndMs) {
            sign = -sign
            segEndMs = now + 320L + rnd.nextInt(260)
        }
        val ux = ex / dist
        val uy = ey / dist
        var dx = -uy * sign
        var dy = ux * sign
        // close, or rushing at us: also step back
        val closing = -(d.targetVx * ux + d.targetVy * uy)
        var back = 0f
        if (dist < minDim * 0.30f) back += 0.45f
        if (closing > minDim * 0.5f) back += 0.50f
        dx -= ux * back
        dy -= uy * back
        val len = hypot(dx, dy).coerceAtLeast(0.001f)
        dx /= len
        dy /= len
        vx = dx
        vy = dy
        val radius = minDim * s.joystickRadiusPct.coerceIn(0.04f, 0.14f)
        val tx = baseX + dx * radius * 0.85f
        val ty = baseY + dy * radius * 0.85f
        if (now - lastMoveMs >= 40L && hypot(tx - lastX, ty - lastY) > 3f) {
            ShellTouch.move(tx, ty)
            lastX = tx
            lastY = ty
            lastMoveMs = now
        }
    }

    @Synchronized fun release(now: Long, why: String = "") {
        vx = 0f
        vy = 0f
        if (!holding) return
        ShellTouch.move(baseX, baseY)
        ShellTouch.up()
        holding = false
        isHolding = false
        lastReleaseMs = now
        if (why.isNotEmpty()) AimLog.add("УКЛОНЕНИЕ: отпустил ($why)")
    }

    fun cancel() = release(android.os.SystemClock.elapsedRealtime())
}
