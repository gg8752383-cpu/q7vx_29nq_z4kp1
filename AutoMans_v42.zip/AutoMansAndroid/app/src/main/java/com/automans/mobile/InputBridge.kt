package com.automans.mobile

import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.BufferedReader
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Runs in a separate process with ADB (shell) rights, started through Shizuku with app_process.
 *  - It always READS the real touchscreen (/dev/input/eventN) and tells the app where the player's fingers are.
 *  - To touch the screen it first tries to WRITE into the same device (an unused slot, "evdev" mode).
 *    Many phones (Samsung) forbid that for the shell; then it injects Android touch events instead ("im" mode):
 *      * "F": the player's own attack finger is moved to the predicted spot and lifted, as part of the SAME touch device
 *        stream, so the game sees exactly one release there and the other fingers are untouched;
 *      * "D/M/U": one extra finger on a virtual touch device (used for the move stick).
 *
 * Arguments: <device> <injectSlot> <eventSize 24|16> <extras "code=value,..."> [writePath or -] [touch device name]
 * Commands on stdin (panel coordinates): "T rot sw sh pw ph" geometry, "D x y", "M x y", "U", "F slot x y", "Q".
 * Lines on stdout: "READY evdev|im|ro", then "D slot x y", "M slot x y", "U slot" for the player's fingers,
 * and "ERR ..." / "INF ..." diagnostics.
 */
object InputBridge {
    private const val EV_SYN = 0
    private const val EV_KEY = 1
    private const val EV_ABS = 3
    private const val ABS_MT_SLOT = 0x2f
    private const val ABS_MT_POSITION_X = 0x35
    private const val ABS_MT_POSITION_Y = 0x36
    private const val ABS_MT_TRACKING_ID = 0x39
    private const val BTN_TOUCH = 0x14a
    private const val SLOTS = 32
    private const val POINTER_SHIFT = 8

    private val trackId = IntArray(SLOTS) { -1 }
    private val posX = IntArray(SLOTS)
    private val posY = IntArray(SLOTS)
    private val lastEmit = LongArray(SLOTS)
    private val pointerId = IntArray(SLOTS) { -1 }
    private val lock = Any()
    private var gestureDownMs = 0L

    @Volatile private var userFingers = 0
    private var injecting = false
    private var nextTid = 52000

    // geometry for the injected mode
    private var rot = 1
    private var sw = 2340
    private var sh = 1080
    private var pw = 1080
    private var ph = 2340

    // injected mode
    private var injTarget: Any? = null
    private var injMethod: Method? = null
    private var injArgs = 2
    private var touchDeviceId = -1
    private var virtDownMs = 0L
    private var virtActive = false
    private var errCount = 0
    private var fireInfoCount = 0

    private fun toScreen(x: Float, y: Float): FloatArray {
        val fx = x / pw
        val fy = y / ph
        return when (rot) {
            1 -> floatArrayOf(fy * sw, (1f - fx) * sh)
            3 -> floatArrayOf((1f - fy) * sw, fx * sh)
            2 -> floatArrayOf((1f - fx) * sw, (1f - fy) * sh)
            else -> floatArrayOf(fx * sw, fy * sh)
        }
    }

    private fun say(line: String) {
        synchronized(System.out) { System.out.println(line); System.out.flush() }
    }

    private fun err(what: String, e: Throwable?) {
        if (errCount++ < 12) say("ERR $what" + (if (e != null) ": " + (e.cause ?: e) else ""))
    }

    /** Finds a way to inject touch events as the shell user. Returns null when it worked, else a reason. */
    private fun initInjection(deviceName: String): String? {
        val reasons = StringBuilder()
        // 1) the input service directly
        try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "input") as android.os.IBinder
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            val iim = stub.getMethod("asInterface", android.os.IBinder::class.java).invoke(null, binder)!!
            val m = iim.javaClass.methods.filter { it.name == "injectInputEvent" }.minByOrNull { it.parameterTypes.size }
            if (m != null && m.parameterTypes.size in 2..3) {
                injTarget = iim; injMethod = m; injArgs = m.parameterTypes.size
            } else reasons.append("IInputManager: нет injectInputEvent; ")
        } catch (e: Throwable) {
            reasons.append("IInputManager: ${e.cause ?: e}; ")
        }
        // 2) the InputManager object
        if (injMethod == null) {
            try {
                val c = Class.forName("android.hardware.input.InputManager")
                val inst = c.getDeclaredMethod("getInstance").also { it.isAccessible = true }.invoke(null)!!
                val m = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
                injTarget = inst; injMethod = m; injArgs = 2
            } catch (e: Throwable) {
                reasons.append("InputManager: ${e.cause ?: e}; ")
            }
        }
        if (injMethod == null) return reasons.toString()
        // the real touchscreen as Android knows it: events carrying its id join the player's own touch stream
        try {
            var any = -1
            for (id in InputDevice.getDeviceIds()) {
                val d = InputDevice.getDevice(id) ?: continue
                if ((d.sources and InputDevice.SOURCE_TOUCHSCREEN) != InputDevice.SOURCE_TOUCHSCREEN) continue
                if (any < 0) any = id
                if (deviceName.isNotEmpty() && d.name == deviceName) { touchDeviceId = id; break }
            }
            if (touchDeviceId < 0) touchDeviceId = any
        } catch (e: Throwable) {
            say("INF не получил список устройств ввода: ${e.cause ?: e}")
        }
        say("INF внедрение событий готово, touch-устройство id=$touchDeviceId")
        return null
    }

    private fun inject(ev: MotionEvent) {
        try {
            val t = injTarget ?: return
            val m = injMethod ?: return
            val ok = if (injArgs == 2) m.invoke(t, ev, 0) else m.invoke(t, ev, 0, -1)
            if (ok == false && errCount < 6) err("событие отклонено", null)
        } catch (e: Throwable) {
            err("внедрение", e)
        } finally {
            try { ev.recycle() } catch (ignored: Throwable) { }
        }
    }

    private fun motion(down: Long, action: Int, ids: IntArray, xs: FloatArray, ys: FloatArray, deviceId: Int): MotionEvent {
        val n = ids.size
        val props = Array(n) { i -> MotionEvent.PointerProperties().also { it.id = ids[i]; it.toolType = MotionEvent.TOOL_TYPE_FINGER } }
        val coords = Array(n) { i -> MotionEvent.PointerCoords().also { it.x = xs[i]; it.y = ys[i]; it.pressure = 1f; it.size = 0.1f } }
        return MotionEvent.obtain(down, (System.nanoTime() / 1_000_000L), action, n, props, coords, 0, 0, 1f, 1f, deviceId, 0, InputDevice.SOURCE_TOUCHSCREEN, 0)
    }

    private fun assignId(slot: Int) {
        val used = BooleanArray(SLOTS)
        var active = 0
        for (s in 0 until SLOTS) if (s != slot && pointerId[s] >= 0) { used[pointerId[s]] = true; active++ }
        var id = 0
        while (id < SLOTS - 1 && used[id]) id++
        pointerId[slot] = id
        if (active == 0) gestureDownMs = (System.nanoTime() / 1_000_000L)
    }

    /** The player's attack finger is moved to (px,py) and lifted there, inside the real touch stream. */
    private fun fireInjected(slot: Int, px: Int, py: Int) {
        val ids: IntArray
        val xs: FloatArray
        val ys: FloatArray
        val idx: Int
        val down: Long
        synchronized(lock) {
            if (slot !in 0 until SLOTS || pointerId[slot] < 0) { err("выстрел: палец не найден (слот $slot)", null); return }
            val act = (0 until SLOTS).filter { pointerId[it] >= 0 }.sortedBy { pointerId[it] }
            ids = IntArray(act.size) { pointerId[act[it]] }
            xs = FloatArray(act.size)
            ys = FloatArray(act.size)
            for (i in act.indices) {
                val s = act[i]
                val p = if (s == slot) toScreen(px.toFloat(), py.toFloat()) else toScreen(posX[s].toFloat(), posY[s].toFloat())
                xs[i] = p[0]; ys[i] = p[1]
            }
            idx = act.indexOf(slot)
            down = gestureDownMs
        }
        val n = ids.size
        val dev = touchDeviceId
        inject(motion(down, MotionEvent.ACTION_MOVE, ids, xs, ys, dev))
        val upAction = if (n == 1) MotionEvent.ACTION_UP else (MotionEvent.ACTION_POINTER_UP or (idx shl POINTER_SHIFT))
        inject(motion(down, upAction, ids, xs, ys, dev))
        if (fireInfoCount++ < 6) say("INF выстрел: пальцев=$n цель индекс=$idx id=${ids[idx]} экран=(${xs[idx].toInt()},${ys[idx].toInt()}) устройство=$dev")
    }

    private fun virtual(action: Int, px: Int, py: Int) {
        val p = toScreen(px.toFloat(), py.toFloat())
        if (action == MotionEvent.ACTION_DOWN) { virtDownMs = (System.nanoTime() / 1_000_000L); virtActive = true }
        if (!virtActive) return
        inject(motion(virtDownMs, action, intArrayOf(12), floatArrayOf(p[0]), floatArrayOf(p[1]), -1))
        if (action == MotionEvent.ACTION_UP) virtActive = false
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val dev = args[0]
        val injSlot = args[1].toInt()
        val size = args[2].toInt()
        val extras = ArrayList<IntArray>()
        if (args.size > 3 && args[3].isNotEmpty()) {
            for (part in args[3].split(',')) {
                val kv = part.split('=')
                if (kv.size == 2) extras.add(intArrayOf(kv[0].toInt(), kv[1].toInt()))
            }
        }
        val writePath = if (args.size > 4 && args[4] != "-") args[4] else dev
        val deviceName = if (args.size > 5) args[5] else ""
        val stdout = System.out

        // ---- how to touch: write into the device, or inject Android events ----
        var out: FileOutputStream? = null
        var mode = "evdev"
        try {
            out = FileOutputStream(writePath)
        } catch (e: Throwable) {
            say("INF запись в $writePath закрыта (${e.message}), пробую внедрение событий")
            val why = initInjection(deviceName)
            if (why == null) mode = "im" else { say("ERR внедрение не готово: $why"); mode = "ro" }
        }

        val reader = Thread {
            try {
                val input = FileInputStream(dev)
                val buf = ByteArray(size)
                val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
                var slot = 0
                val dirty = BooleanArray(SLOTS)
                while (true) {
                    var got = 0
                    while (got < size) {
                        val n = input.read(buf, got, size - got)
                        if (n < 0) return@Thread
                        got += n
                    }
                    val type = bb.getShort(size - 8).toInt() and 0xffff
                    val code = bb.getShort(size - 6).toInt() and 0xffff
                    val value = bb.getInt(size - 4)
                    if (type == EV_ABS) {
                        when (code) {
                            ABS_MT_SLOT -> slot = value.coerceIn(0, SLOTS - 1)
                            ABS_MT_TRACKING_ID -> {
                                synchronized(lock) {
                                    val old = trackId[slot]
                                    trackId[slot] = value
                                    if (value >= 0 && old < 0) assignId(slot)
                                    else if (value < 0 && old >= 0) pointerId[slot] = -1
                                }
                                dirty[slot] = true
                            }
                            ABS_MT_POSITION_X -> { posX[slot] = value; dirty[slot] = true }
                            ABS_MT_POSITION_Y -> { posY[slot] = value; dirty[slot] = true }
                        }
                    } else if (type == EV_SYN && code == 0) {
                        var count = 0
                        val now = System.currentTimeMillis()
                        for (s in 0 until SLOTS) {
                            if (s != injSlot && trackId[s] >= 0) count++
                            if (!dirty[s]) continue
                            dirty[s] = false
                            if (s == injSlot && mode == "evdev") continue
                            synchronized(stdout) {
                                if (trackId[s] < 0) {
                                    if (lastEmit[s] != 0L) {
                                        stdout.println("U $s")
                                        lastEmit[s] = 0
                                    }
                                } else if (lastEmit[s] == 0L) {
                                    stdout.println("D $s ${posX[s]} ${posY[s]}")
                                    lastEmit[s] = now
                                } else if (now - lastEmit[s] >= 30L) {
                                    stdout.println("M $s ${posX[s]} ${posY[s]}")
                                    lastEmit[s] = now
                                }
                                stdout.flush()
                            }
                        }
                        userFingers = count
                    }
                }
            } catch (e: Throwable) {
                say("ERR read $dev: $e")
            }
        }
        reader.isDaemon = true
        reader.start()

        fun frame(events: List<IntArray>) {
            val o = out ?: return
            val bb = ByteBuffer.allocate(events.size * size).order(ByteOrder.LITTLE_ENDIAN)
            for (e in events) {
                bb.position(bb.position() + (size - 8))
                bb.putShort(e[0].toShort())
                bb.putShort(e[1].toShort())
                bb.putInt(e[2])
            }
            o.write(bb.array())
            o.flush()
        }

        say("READY $mode")

        val cmds = BufferedReader(InputStreamReader(System.`in`))
        try {
            while (true) {
                val line = cmds.readLine() ?: break
                val p = line.trim().split(' ')
                try {
                    when (p[0]) {
                        "T" -> if (p.size >= 6) {
                            rot = p[1].toInt(); sw = p[2].toInt(); sh = p[3].toInt(); pw = p[4].toInt(); ph = p[5].toInt()
                        }
                        "D" -> if (p.size >= 3) {
                            if (mode == "im") virtual(MotionEvent.ACTION_DOWN, p[1].toInt(), p[2].toInt())
                            else if (mode == "evdev") {
                                val ev = ArrayList<IntArray>()
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, nextTid))
                                nextTid = if (nextTid > 60000) 52000 else nextTid + 1
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[1].toInt()))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[2].toInt()))
                                for (x in extras) ev.add(intArrayOf(EV_ABS, x[0], x[1]))
                                if (userFingers == 0) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 1))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                frame(ev)
                                injecting = true
                            }
                        }
                        "M" -> if (p.size >= 3) {
                            if (mode == "im") virtual(MotionEvent.ACTION_MOVE, p[1].toInt(), p[2].toInt())
                            else if (mode == "evdev" && injecting) {
                                frame(listOf(
                                    intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot),
                                    intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[1].toInt()),
                                    intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[2].toInt()),
                                    intArrayOf(EV_SYN, 0, 0),
                                ))
                            }
                        }
                        "U" -> {
                            if (mode == "im") virtual(MotionEvent.ACTION_UP, 0, 0)
                            else if (mode == "evdev" && injecting) {
                                val ev = ArrayList<IntArray>()
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1))
                                if (userFingers == 0) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 0))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                frame(ev)
                                injecting = false
                            }
                        }
                        "F" -> if (p.size >= 4) {
                            val slot = p[1].toInt().coerceIn(0, SLOTS - 1)
                            if (mode == "im") fireInjected(slot, p[2].toInt(), p[3].toInt())
                            else if (mode == "evdev") {
                                // fire: move the player's finger to a new spot and let go of it, in one write,
                                // so the game sees the last move and the release at the new position
                                val ev = ArrayList<IntArray>()
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, slot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[2].toInt()))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[3].toInt()))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, slot))
                                ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1))
                                if (userFingers <= 1 && !injecting) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 0))
                                ev.add(intArrayOf(EV_SYN, 0, 0))
                                frame(ev)
                            }
                        }
                        "Q" -> break
                    }
                } catch (e: java.io.IOException) {
                    err("запись", e)
                } catch (e: NumberFormatException) {
                }
            }
        } catch (ignored: Throwable) {
        }
        if (mode == "evdev" && injecting) {
            try {
                frame(listOf(
                    intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot),
                    intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1),
                    intArrayOf(EV_SYN, 0, 0),
                ))
            } catch (ignored: Throwable) { }
        }
        if (mode == "im" && virtActive) {
            try { virtual(MotionEvent.ACTION_UP, 0, 0) } catch (ignored: Throwable) { }
        }
        System.exit(0)
    }
}
