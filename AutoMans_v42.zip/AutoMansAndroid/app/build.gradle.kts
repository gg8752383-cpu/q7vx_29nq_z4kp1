plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.automans.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.automans.mobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 42
        versionName = "4.2-max"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("automans.keystore")
            storePassword = "automans123"
            keyAlias = "automans"
            keyPassword = "automans123"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
