package com.automans.mobile

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import kotlin.math.min

class MansAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var current: MansAccessibilityService? = null
            private set
        /** Set by the touch-watcher overlay when the player touches the screen. */
        @Volatile var lastUserTouchMs: Long = 0L
        /** Time of the helper's own last gesture, so it does not mistake itself for the player. */
        @Volatile var lastInjectMs: Long = 0L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var lastNonSelfPackage: String? = null
    private var gestureBusy = false
    private var lastGestureAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString()?.lowercase() ?: return
        // The overlay/activity belongs to this app; do not let it overwrite the game target.
        if (!packageName.contains("automans")) lastNonSelfPackage = packageName
    }

    fun isLikelyBrawlForeground(): Boolean {
        val pkg = lastNonSelfPackage ?: return false
        return isBrawlPackage(pkg)
    }

    private fun isBrawlPackage(pkg: String): Boolean =
        pkg.contains("brawl", ignoreCase = true) || pkg.contains("nulls", ignoreCase = true)


    /**
     * Sends a short drag from the configured attack-stick center toward a target.
     * In Brawl-style controls, releasing that drag may also fire an attack.
     */
    fun dispatchAim(
        directionX: Float,
        directionY: Float,
        screenWidth: Int,
        screenHeight: Int,
        settings: DodgeSettings,
    ) {
        if (!directionX.isFinite() || !directionY.isFinite()) return
        if (directionX * directionX + directionY * directionY < 0.80f) return
        if (screenWidth < 100 || screenHeight < 100) return

        val rememberedPkg = lastNonSelfPackage
        mainHandler.post {
            val pkg = lastNonSelfPackage ?: rememberedPkg ?: return@post
            if (pkg.isBlank() || !isBrawlPackage(pkg)) return@post
            val now = SystemClock.elapsedRealtime()
            if (gestureBusy || now - lastGestureAt < 650L) return@post
            if (now - lastUserTouchMs < settings.userPauseTenths * 100L) return@post
            val radius = min(screenWidth, screenHeight) * settings.attackRadiusPct.coerceIn(0.04f, 0.14f)
            val startX = screenWidth * settings.attackX.coerceIn(0.65f, 0.97f)
            val startY = screenHeight * settings.attackY.coerceIn(0.55f, 0.95f)
            // drag past the stick edge = full shot range (a short drag makes the shot fall short)
            val reach = radius * 1.6f
            val targetX = (startX + directionX.coerceIn(-1f, 1f) * reach).coerceIn(1f, screenWidth - 2f)
            val targetY = (startY + directionY.coerceIn(-1f, 1f) * reach).coerceIn(1f, screenHeight - 2f)
            val path = Path().apply { moveTo(startX, startY); lineTo(targetX, targetY) }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 320L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            gestureBusy = true
            lastGestureAt = now
            lastInjectMs = now
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    gestureBusy = false
                    lastInjectMs = SystemClock.elapsedRealtime()
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    gestureBusy = false
                    lastInjectMs = SystemClock.elapsedRealtime()
                }
            }, mainHandler)
            if (!accepted) gestureBusy = false
        }
    }

    override fun onInterrupt() {
        gestureBusy = false
    }

    fun dispatchDodge(
        directionX: Float,
        directionY: Float,
        screenWidth: Int,
        screenHeight: Int,
        settings: DodgeSettings,
    ) {
        if (!directionX.isFinite() || !directionY.isFinite()) return
        if (directionX * directionX + directionY * directionY < 0.20f) return
        if (screenWidth < 100 || screenHeight < 100) return

        // Only inject into a window whose package resembles Null's Brawl/Brawl Stars.
        // This avoids swiping another app if AUTO is left enabled after the game closes.
        val rememberedPkg = lastNonSelfPackage
        mainHandler.post {
            // Re-read the most recent window event on the main thread. This avoids requesting
            // accessibility window-content access just to identify the foreground package.
            val pkg = lastNonSelfPackage ?: rememberedPkg ?: return@post
            if (pkg.isBlank()) return@post
            if (!isBrawlPackage(pkg)) return@post
            val now = SystemClock.elapsedRealtime()
            if (gestureBusy || now - lastGestureAt < 380L) return@post
            if (now - lastUserTouchMs < settings.userPauseTenths * 100L) return@post
            val radius = min(screenWidth, screenHeight) * settings.joystickRadiusPct.coerceIn(0.04f, 0.14f)
            val startX = screenWidth * settings.joystickX.coerceIn(0.03f, 0.25f)
            val startY = screenHeight * settings.joystickY.coerceIn(0.55f, 0.95f)
            val targetX = (startX + directionX.coerceIn(-1f, 1f) * radius).coerceIn(1f, screenWidth - 2f)
            val targetY = (startY + directionY.coerceIn(-1f, 1f) * radius).coerceIn(1f, screenHeight - 2f)

            val path = Path().apply {
                moveTo(startX, startY)
                lineTo(targetX, targetY)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 320L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            gestureBusy = true
            lastGestureAt = now
            lastInjectMs = now
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    gestureBusy = false
                    lastInjectMs = SystemClock.elapsedRealtime()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    gestureBusy = false
                    lastInjectMs = SystemClock.elapsedRealtime()
                }
            }, mainHandler)
            if (!accepted) gestureBusy = false
        }
    }

    override fun onDestroy() {
        gestureBusy = false
        if (current === this) current = null
        super.onDestroy()
    }
}
