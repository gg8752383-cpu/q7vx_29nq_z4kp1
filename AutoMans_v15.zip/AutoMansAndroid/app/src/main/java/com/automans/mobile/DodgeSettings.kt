package com.automans.mobile

import android.content.Context

data class DodgeSettings(
    val playerX: Float = 0.50f,
    val playerY: Float = 0.50f,
    val joystickX: Float = 0.105f,
    val joystickY: Float = 0.805f,
    val joystickRadiusPct: Float = 0.075f,
    val attackX: Float = 0.86f,
    val attackY: Float = 0.805f,
    val attackRadiusPct: Float = 0.085f,
    /** 1 = reacts only to very clear threats, 10 = reacts to almost anything. */
    val sensitivity: Int = 4,
    /** false = Aim only draws a marker; true = Aim also presses the attack stick. */
    val aimInject: Boolean = true,
    /** Helper stays silent this many tenths of a second after the player touches the screen. */
    val userPauseTenths: Int = 12,
    /** false = MANS only draws a green arrow; true = it also moves the joystick itself. */
    val dodgeInject: Boolean = true,
    /** Brightness of the on-screen hints, 30..100 percent. */
    val hudAlphaPct: Int = 85,
) {
    companion object {
        private const val PREFS = "automans_settings"

        /** One-time reset of the stick positions to the real layout measured on the player's screen. */
        fun migrate(context: Context) {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (p.getInt("layout_v", 0) >= 2) return
            p.edit()
                .putInt("joystick_x_pct", 15).putInt("joystick_y_pct", 76).putInt("joystick_radius_pct", 11)
                .putInt("attack_x_pct", 83).putInt("attack_y_pct", 63).putInt("attack_radius_pct", 11)
                .putInt("layout_v", 2).apply()
        }

        fun load(context: Context): DodgeSettings {
            migrate(context)
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return DodgeSettings(
                playerX = p.getInt("player_x_pct", 50).coerceIn(25, 75) / 100f,
                playerY = p.getInt("player_y_pct", 50).coerceIn(20, 80) / 100f,
                joystickX = p.getInt("joystick_x_pct", 11).coerceIn(3, 25) / 100f,
                joystickY = p.getInt("joystick_y_pct", 81).coerceIn(55, 95) / 100f,
                joystickRadiusPct = p.getInt("joystick_radius_pct", 8).coerceIn(4, 14) / 100f,
                attackX = p.getInt("attack_x_pct", 86).coerceIn(65, 97) / 100f,
                attackY = p.getInt("attack_y_pct", 81).coerceIn(55, 95) / 100f,
                attackRadiusPct = p.getInt("attack_radius_pct", 8).coerceIn(4, 14) / 100f,
                sensitivity = p.getInt("sensitivity", 4).coerceIn(1, 10),
                aimInject = true,
                userPauseTenths = p.getInt("user_pause_tenths", 12).coerceIn(0, 30),
                dodgeInject = true,
                hudAlphaPct = p.getInt("hud_alpha_pct", 85).coerceIn(30, 100),
            )
        }

        fun save(
            context: Context,
            playerX: Int,
            playerY: Int,
            joystickX: Int,
            joystickY: Int,
            joystickRadiusPct: Int,
            attackX: Int = 86,
            attackY: Int = 81,
            attackRadiusPct: Int = 8,
            sensitivity: Int = 4,
            aimInject: Boolean = false,
            userPauseTenths: Int = 12,
            dodgeInject: Boolean = false,
            hudAlphaPct: Int = 85,
        ) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putInt("player_x_pct", playerX.coerceIn(25, 75))
                .putInt("player_y_pct", playerY.coerceIn(20, 80))
                .putInt("joystick_x_pct", joystickX.coerceIn(3, 25))
                .putInt("joystick_y_pct", joystickY.coerceIn(55, 95))
                .putInt("joystick_radius_pct", joystickRadiusPct.coerceIn(4, 14))
                .putInt("attack_x_pct", attackX.coerceIn(65, 97))
                .putInt("attack_y_pct", attackY.coerceIn(55, 95))
                .putInt("attack_radius_pct", attackRadiusPct.coerceIn(4, 14))
                .putInt("sensitivity", sensitivity.coerceIn(1, 10))
                .putBoolean("aim_inject", aimInject)
                .putInt("user_pause_tenths", userPauseTenths.coerceIn(0, 30))
                .putBoolean("dodge_inject", dodgeInject)
                .putInt("hud_alpha_pct", hudAlphaPct.coerceIn(30, 100))
                .apply()
        }

        /** One-tap switch from the floating AUTO button: both "press for me" modes together. */
        fun saveInject(context: Context, dodge: Boolean, aim: Boolean) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("dodge_inject", dodge)
                .putBoolean("aim_inject", aim)
                .apply()
        }

        /** Used by the draggable calibration rings: only the two stick positions change. */
        fun saveSticks(context: Context, joystickX: Int, joystickY: Int, attackX: Int, attackY: Int) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putInt("joystick_x_pct", joystickX.coerceIn(3, 25))
                .putInt("joystick_y_pct", joystickY.coerceIn(55, 95))
                .putInt("attack_x_pct", attackX.coerceIn(65, 97))
                .putInt("attack_y_pct", attackY.coerceIn(55, 95))
                .apply()
        }
    }
}
