package com.automans.mobile

import java.io.BufferedReader
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Runs in a separate process with ADB (shell) rights, started through Shizuku with app_process.
 * It reads the real touchscreen (/dev/input/eventN), tells the app where the player's fingers are,
 * and writes one extra finger (an unused touch slot) into the same device, so the helper's touch
 * never cancels the player's own touches.
 *
 * Arguments: <device> <injectSlot> <eventSize 24|16> <extras "code=value,..."> [writePath for tests]
 * Commands on stdin: "D x y" down, "M x y" move, "U" up, "Q" quit (panel coordinates).
 * Lines on stdout: "READY", then "D slot x y", "M slot x y", "U slot" for the player's fingers.
 */
object InputBridge {
    private const val EV_SYN = 0
    private const val EV_KEY = 1
    private const val EV_ABS = 3
    private const val ABS_MT_SLOT = 0x2f
    private const val ABS_MT_POSITION_X = 0x35
    private const val ABS_MT_POSITION_Y = 0x36
    private const val ABS_MT_TRACKING_ID = 0x39
    private const val BTN_TOUCH = 0x14a
    private const val SLOTS = 32

    private val trackId = IntArray(SLOTS) { -1 }
    private val posX = IntArray(SLOTS)
    private val posY = IntArray(SLOTS)
    private val lastEmit = LongArray(SLOTS)

    @Volatile private var userFingers = 0
    private var injecting = false
    private var nextTid = 52000

    @JvmStatic
    fun main(args: Array<String>) {
        val dev = args[0]
        val injSlot = args[1].toInt()
        val size = args[2].toInt()
        val extras = ArrayList<IntArray>()
        if (args.size > 3 && args[3].isNotEmpty()) {
            for (part in args[3].split(',')) {
                val kv = part.split('=')
                if (kv.size == 2) extras.add(intArrayOf(kv[0].toInt(), kv[1].toInt()))
            }
        }
        val writePath = if (args.size > 4) args[4] else dev
        val out = FileOutputStream(writePath)
        val stdout = System.out

        val reader = Thread {
            try {
                val input = FileInputStream(dev)
                val buf = ByteArray(size)
                val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
                var slot = 0
                val dirty = BooleanArray(SLOTS)
                while (true) {
                    var got = 0
                    while (got < size) {
                        val n = input.read(buf, got, size - got)
                        if (n < 0) return@Thread
                        got += n
                    }
                    val type = bb.getShort(size - 8).toInt() and 0xffff
                    val code = bb.getShort(size - 6).toInt() and 0xffff
                    val value = bb.getInt(size - 4)
                    if (type == EV_ABS) {
                        when (code) {
                            ABS_MT_SLOT -> slot = value.coerceIn(0, SLOTS - 1)
                            ABS_MT_TRACKING_ID -> { trackId[slot] = value; dirty[slot] = true }
                            ABS_MT_POSITION_X -> { posX[slot] = value; dirty[slot] = true }
                            ABS_MT_POSITION_Y -> { posY[slot] = value; dirty[slot] = true }
                        }
                    } else if (type == EV_SYN && code == 0) {
                        var count = 0
                        val now = System.currentTimeMillis()
                        for (s in 0 until SLOTS) {
                            if (s != injSlot && trackId[s] >= 0) count++
                            if (!dirty[s]) continue
                            dirty[s] = false
                            if (s == injSlot) continue
                            synchronized(stdout) {
                                if (trackId[s] < 0) {
                                    stdout.println("U $s")
                                    lastEmit[s] = 0
                                } else if (lastEmit[s] == 0L) {
                                    stdout.println("D $s ${posX[s]} ${posY[s]}")
                                    lastEmit[s] = now
                                } else if (now - lastEmit[s] >= 30L) {
                                    stdout.println("M $s ${posX[s]} ${posY[s]}")
                                    lastEmit[s] = now
                                }
                                stdout.flush()
                            }
                        }
                        userFingers = count
                    }
                }
            } catch (ignored: Throwable) {
            }
        }
        reader.isDaemon = true
        reader.start()

        fun frame(events: List<IntArray>) {
            val bb = ByteBuffer.allocate(events.size * size).order(ByteOrder.LITTLE_ENDIAN)
            for (e in events) {
                bb.position(bb.position() + (size - 8))
                bb.putShort(e[0].toShort())
                bb.putShort(e[1].toShort())
                bb.putInt(e[2])
            }
            out.write(bb.array())
            out.flush()
        }

        synchronized(stdout) { stdout.println("READY"); stdout.flush() }

        val cmds = BufferedReader(InputStreamReader(System.`in`))
        try {
            while (true) {
                val line = cmds.readLine() ?: break
                val p = line.trim().split(' ')
                when (p[0]) {
                    "D" -> if (p.size >= 3) {
                        val ev = ArrayList<IntArray>()
                        ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot))
                        ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, nextTid))
                        nextTid = if (nextTid > 60000) 52000 else nextTid + 1
                        ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[1].toInt()))
                        ev.add(intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[2].toInt()))
                        for (x in extras) ev.add(intArrayOf(EV_ABS, x[0], x[1]))
                        if (userFingers == 0) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 1))
                        ev.add(intArrayOf(EV_SYN, 0, 0))
                        frame(ev)
                        injecting = true
                    }
                    "M" -> if (p.size >= 3 && injecting) {
                        frame(listOf(
                            intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot),
                            intArrayOf(EV_ABS, ABS_MT_POSITION_X, p[1].toInt()),
                            intArrayOf(EV_ABS, ABS_MT_POSITION_Y, p[2].toInt()),
                            intArrayOf(EV_SYN, 0, 0),
                        ))
                    }
                    "U" -> if (injecting) {
                        val ev = ArrayList<IntArray>()
                        ev.add(intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot))
                        ev.add(intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1))
                        if (userFingers == 0) ev.add(intArrayOf(EV_KEY, BTN_TOUCH, 0))
                        ev.add(intArrayOf(EV_SYN, 0, 0))
                        frame(ev)
                        injecting = false
                    }
                    "Q" -> break
                }
            }
        } catch (ignored: Throwable) {
        }
        if (injecting) {
            try {
                frame(listOf(
                    intArrayOf(EV_ABS, ABS_MT_SLOT, injSlot),
                    intArrayOf(EV_ABS, ABS_MT_TRACKING_ID, -1),
                    intArrayOf(EV_SYN, 0, 0),
                ))
            } catch (ignored: Throwable) { }
        }
        System.exit(0)
    }
}
