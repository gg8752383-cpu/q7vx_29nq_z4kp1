package com.automans.mobile

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequest = 701
    private var playerX = 50
    private var playerY = 50
    private var joystickX = 11
    private var joystickY = 81
    private var joystickRadius = 8
    private var attackX = 86
    private var attackY = 81
    private var attackRadius = 8
    private var sensitivity = 4
    private var aimInject = false
    private var dodgeInject = false
    private var pauseTenths = 12

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = getSharedPreferences("automans_settings", MODE_PRIVATE)
        playerX = saved.getInt("player_x_pct", 50).coerceIn(25, 75)
        playerY = saved.getInt("player_y_pct", 50).coerceIn(20, 80)
        joystickX = saved.getInt("joystick_x_pct", 11).coerceIn(3, 25)
        joystickY = saved.getInt("joystick_y_pct", 81).coerceIn(55, 95)
        joystickRadius = saved.getInt("joystick_radius_pct", 8).coerceIn(4, 14)
        attackX = saved.getInt("attack_x_pct", 86).coerceIn(65, 97)
        attackY = saved.getInt("attack_y_pct", 81).coerceIn(55, 95)
        attackRadius = saved.getInt("attack_radius_pct", 8).coerceIn(4, 14)
        sensitivity = saved.getInt("sensitivity", 4).coerceIn(1, 10)
        aimInject = saved.getBoolean("aim_inject", false)
        dodgeInject = saved.getBoolean("dodge_inject", false)
        pauseTenths = saved.getInt("user_pause_tenths", 12).coerceIn(0, 30)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            gravity = Gravity.TOP
        }
        layout.addView(TextView(this).apply {
            text = "AUTO-MANS • Null’s Brawl"
            textSize = 23f
        })
        layout.addView(TextView(this).apply {
            text = "Помощник-подсказчик. MANS рисует зелёную стрелку, куда двигаться. AIM сам находит врагов по полоскам здоровья и рисует жёлтый прицел на ближайшем. Сам он ничего не нажимает, пока не включишь галочки ниже. Кнопка DOTS нужна только для режима, когда он нажимает сам: перетащи кольца на свои стики."
            textSize = 14f
            setPadding(0, dp(10), 0, dp(12))
        })

        addSlider(layout, "Чувствительность уклонения (1 = редко, 10 = часто)", 1, 10, sensitivity, "") { sensitivity = it; saveSettings() }
        addSlider(layout, "Пауза после твоего касания (в 0.1 с)", 0, 30, pauseTenths, "") { pauseTenths = it; saveSettings() }
        layout.addView(CheckBox(this).apply {
            text = "Уклонение само двигает джойстик (выкл = только зелёная стрелка)"
            isChecked = dodgeInject
            setOnCheckedChangeListener { _, checked -> dodgeInject = checked; saveSettings() }
        })
        layout.addView(CheckBox(this).apply {
            text = "Aim сам нажимает стик атаки (выкл = только жёлтый прицел)"
            isChecked = aimInject
            setOnCheckedChangeListener { _, checked -> aimInject = checked; saveSettings() }
        })
        addSlider(layout, "Центр бойца по X", 25, 75, playerX) { playerX = it; saveSettings() }
        addSlider(layout, "Центр бойца по Y", 20, 80, playerY) { playerY = it; saveSettings() }
        addSlider(layout, "Джойстик X", 3, 25, joystickX) { joystickX = it; saveSettings() }
        addSlider(layout, "Джойстик Y", 55, 95, joystickY) { joystickY = it; saveSettings() }
        addSlider(layout, "Радиус джойстика", 4, 14, joystickRadius) { joystickRadius = it; saveSettings() }
        addSlider(layout, "Стик атаки X", 65, 97, attackX) { attackX = it; saveSettings() }
        addSlider(layout, "Стик атаки Y", 55, 95, attackY) { attackY = it; saveSettings() }
        addSlider(layout, "Радиус стика атаки", 4, 14, attackRadius) { attackRadius = it; saveSettings() }

        layout.addView(Button(this).apply {
            text = "1. Разрешить плавающую кнопку"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Включить управление касаниями"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "3. Запустить захват экрана"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    appendMessage(layout, "Сначала разреши отображение поверх других приложений.")
                    return@setOnClickListener
                }
                saveSettings()
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
            }
        })
        layout.addView(TextView(this).apply {
            text = "После запуска открой игру в альбомной ориентации. MANS показывает стрелку движения, AIM сам находит ближайшего врага и показывает на нём жёлтый прицел. Долгое нажатие MANS останавливает сервис."
            textSize = 13f
            setPadding(0, dp(12), 0, 0)
        })
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(layout, android.view.ViewGroup.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ))
        })

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 702)
        }
    }

    private fun addSlider(
        layout: LinearLayout,
        title: String,
        minValue: Int,
        maxValue: Int,
        initial: Int,
        unit: String = "%",
        onChanged: (Int) -> Unit,
    ) {
        val label = TextView(this).apply { textSize = 14f }
        fun update(value: Int) { label.text = "$title: $value$unit" }
        update(initial)
        layout.addView(label)
        layout.addView(SeekBar(this).apply {
            max = maxValue - minValue
            progress = initial - minValue
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = (progress + minValue).coerceIn(minValue, maxValue)
                    update(value)
                    onChanged(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        })
    }

    private fun saveSettings() {
        DodgeSettings.save(this, playerX, playerY, joystickX, joystickY, joystickRadius, attackX, attackY, attackRadius, sensitivity, aimInject, pauseTenths, dodgeInject)
    }

    private fun appendMessage(layout: LinearLayout, message: String) {
        layout.addView(TextView(this).apply { text = message })
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated by Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service)
            else startService(service)
            finish()
        }
    }
}
