package com.automans.mobile

import android.content.Context
import android.os.SystemClock
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.Writer
import kotlin.math.hypot

/**
 * Touch control through Shizuku (ADB rights): sees the player's fingers on the real touchscreen and adds
 * one more finger of its own in a spare slot. The player's own touches are never cancelled by it.
 */
object ShellTouch {
    @Volatile var ready = false
        private set
    @Volatile var rotation = 1
    @Volatile var screenW = 2340
    @Volatile var screenH = 1080

    private var panelW = 1080
    private var panelH = 2340
    private var proc: Process? = null
    private var writer: Writer? = null
    private val lock = Any()
    @Volatile private var starting = false

    /** Player's fingers in panel coordinates: slot -> [x, y, downAtMs, downX, downY]. */
    private val fingers = HashMap<Int, DoubleArray>()
    @Volatile var onTap: ((Float, Float) -> Unit)? = null

    fun stop() {
        synchronized(lock) {
            try { writer?.write("Q\n"); writer?.flush() } catch (ignored: Exception) { }
            try { proc?.destroy() } catch (ignored: Exception) { }
            writer = null
            proc = null
            ready = false
            fingers.clear()
        }
    }

    /** Call off the main thread. Returns a short human-readable status that is also written to the journal. */
    fun start(context: Context): String {
        if (ready || starting) return "уже запущено"
        starting = true
        try {
            if (!ShizukuBridge.hasPermission()) return log("Shizuku: нет разрешения")
            val info = ShizukuBridge.run("getevent -lp", 60000)
            val dev = parseDevice(info) ?: return log("тачскрин не найден в getevent")
            panelW = dev.maxX + 1
            panelH = dev.maxY + 1
            val is64 = android.os.Process.is64Bit()
            val apk = context.packageCodePath
            val extras = dev.extras.joinToString(",") { "${it[0]}=${it[1]}" }
            val cmd = "CLASSPATH=$apk exec app_process /system/bin com.automans.mobile.InputBridge " +
                "${dev.path} ${dev.maxSlot} ${if (is64) 24 else 16} \"$extras\" 2>&1"
            val p = ShizukuBridge.start(arrayOf("sh", "-c", cmd)) ?: return log("не удалось запустить мост")
            val rd = BufferedReader(InputStreamReader(p.inputStream))
            var ok = false
            val deadline = SystemClock.elapsedRealtime() + 6000L
            val firstLines = StringBuilder()
            while (SystemClock.elapsedRealtime() < deadline) {
                if (!rd.ready()) { Thread.sleep(40); continue }
                val line = rd.readLine() ?: break
                if (line.trim() == "READY") { ok = true; break }
                if (firstLines.length < 400) firstLines.append(line).append(' ')
            }
            if (!ok) {
                try { p.destroy() } catch (ignored: Exception) { }
                return log("мост не стартовал: $firstLines")
            }
            synchronized(lock) {
                proc = p
                writer = OutputStreamWriter(p.outputStream)
                ready = true
            }
            Thread { readLoop(rd) }.also { it.isDaemon = true }.start()
            return log("ADB-касания готовы: ${dev.path} ${panelW}x$panelH слотов ${dev.maxSlot + 1} оси ${extras}")
        } catch (e: Throwable) {
            return log("ошибка запуска: ${e.message}")
        } finally {
            starting = false
        }
    }

    private fun log(s: String): String { AimLog.add("ADB: $s"); return s }

    private class Dev(val path: String, val maxX: Int, val maxY: Int, val maxSlot: Int, val extras: List<IntArray>)

    private fun parseDevice(text: String): Dev? {
        val blocks = text.split("add device ")
        for (b in blocks) {
            if (!b.contains("INPUT_PROP_DIRECT") || !b.contains("ABS_MT_POSITION_X")) continue
            val path = Regex("(/dev/input/event\\d+)").find(b)?.value ?: continue
            fun maxOf(axis: String): Int? =
                Regex("$axis\\s*:.*?max\\s+(\\d+)").find(b)?.groupValues?.get(1)?.toIntOrNull()
            val mx = maxOf("ABS_MT_POSITION_X") ?: continue
            val my = maxOf("ABS_MT_POSITION_Y") ?: continue
            val slot = (maxOf("ABS_MT_SLOT") ?: 9).coerceIn(2, 31)
            val extras = ArrayList<IntArray>()
            maxOf("ABS_MT_PRESSURE")?.let { extras.add(intArrayOf(0x3a, (it / 3).coerceAtLeast(1))) }
            maxOf("ABS_MT_TOUCH_MAJOR")?.let { extras.add(intArrayOf(0x30, (it / 4).coerceAtLeast(1))) }
            maxOf("ABS_MT_TOUCH_MINOR")?.let { extras.add(intArrayOf(0x31, (it / 4).coerceAtLeast(1))) }
            maxOf("ABS_MT_WIDTH_MAJOR")?.let { extras.add(intArrayOf(0x32, (it / 4).coerceAtLeast(1))) }
            return Dev(path, mx, my, slot, extras)
        }
        return null
    }

    private fun readLoop(rd: BufferedReader) {
        try {
            while (true) {
                val line = rd.readLine() ?: break
                val t = line.trim().split(' ')
                if (t.isEmpty()) continue
                val now = SystemClock.elapsedRealtime().toDouble()
                synchronized(fingers) {
                    when (t[0]) {
                        "D" -> if (t.size >= 4) {
                            val x = t[2].toDouble(); val y = t[3].toDouble()
                            fingers[t[1].toInt()] = doubleArrayOf(x, y, now, x, y)
                        }
                        "M" -> if (t.size >= 4) {
                            fingers[t[1].toInt()]?.let { it[0] = t[2].toDouble(); it[1] = t[3].toDouble() }
                        }
                        "U" -> if (t.size >= 2) {
                            val f = fingers.remove(t[1].toInt())
                            if (f != null && now - f[2] < 350.0 && hypot(f[0] - f[3], f[1] - f[4]) < panelW * 0.04) {
                                val s = toScreen(f[3].toFloat(), f[4].toFloat())
                                try { onTap?.invoke(s[0], s[1]) } catch (ignored: Throwable) { }
                            }
                        }
                    }
                }
            }
        } catch (ignored: Throwable) {
        }
        ready = false
        AimLog.add("ADB: мост остановился")
    }

    /**
     * The move joystick as a vector (screen direction x strength 0..1): the finger that went down on the left half,
     * measured from where it first touched. Zero when the player is standing still.
     */
    fun moveVector(minDim: Float): FloatArray {
        var best: DoubleArray? = null
        synchronized(fingers) {
            for (f in fingers.values) {
                val d = toScreen(f[3].toFloat(), f[4].toFloat())
                if (d[0] >= screenW * 0.5f) continue
                if (best == null || f[2] < best!![2]) best = f
            }
            val f = best ?: return floatArrayOf(0f, 0f)
            val a = toScreen(f[3].toFloat(), f[4].toFloat())
            val b = toScreen(f[0].toFloat(), f[1].toFloat())
            val dx = b[0] - a[0]
            val dy = b[1] - a[1]
            val len = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (len < minDim * 0.012f) return floatArrayOf(0f, 0f)
            val strength = (len / (minDim * 0.07f)).coerceAtMost(1f)
            return floatArrayOf(dx / len * strength, dy / len * strength)
        }
    }

    /** True when one of the player's fingers is within radiusPx of the screen point (x, y). */
    fun fingerNear(x: Float, y: Float, radiusPx: Float): Boolean {
        synchronized(fingers) {
            for (f in fingers.values) {
                val s = toScreen(f[0].toFloat(), f[1].toFloat())
                if (hypot((s[0] - x).toDouble(), (s[1] - y).toDouble()) <= radiusPx) return true
            }
        }
        return false
    }

    private fun toScreen(px: Float, py: Float): FloatArray {
        val w = screenW.toFloat(); val h = screenH.toFloat()
        val fx = px / panelW; val fy = py / panelH
        return when (rotation) {
            1 -> floatArrayOf(fy * w, (1f - fx) * h)
            3 -> floatArrayOf((1f - fy) * w, fx * h)
            2 -> floatArrayOf((1f - fx) * w, (1f - fy) * h)
            else -> floatArrayOf(fx * w, fy * h)
        }
    }

    private fun toPanel(sx: Float, sy: Float): IntArray {
        val fx = (sx / screenW).coerceIn(0f, 1f); val fy = (sy / screenH).coerceIn(0f, 1f)
        val (u, v) = when (rotation) {
            1 -> Pair(1f - fy, fx)
            3 -> Pair(fy, 1f - fx)
            2 -> Pair(1f - fx, 1f - fy)
            else -> Pair(fx, fy)
        }
        return intArrayOf((u * (panelW - 1)).toInt(), (v * (panelH - 1)).toInt())
    }

    private fun send(line: String): Boolean {
        synchronized(lock) {
            val w = writer ?: return false
            return try { w.write(line); w.write("\n"); w.flush(); true } catch (e: Exception) { ready = false; false }
        }
    }

    /**
     * The player's finger that went down on the attack stick: [slot, x, y, downAtMs] in screen pixels, or null.
     */
    fun attackFinger(baseX: Float, baseY: Float, radius: Float): DoubleArray? {
        synchronized(fingers) {
            var best: DoubleArray? = null
            var bestSlot = -1
            for ((slot, f) in fingers) {
                val d = toScreen(f[3].toFloat(), f[4].toFloat())
                if (hypot((d[0] - baseX).toDouble(), (d[1] - baseY).toDouble()) > radius * 2.4) continue
                if (best == null || f[2] < best!![2]) { best = f; bestSlot = slot }
            }
            val f = best ?: return null
            val now = toScreen(f[0].toFloat(), f[1].toFloat())
            return doubleArrayOf(bestSlot.toDouble(), now[0].toDouble(), now[1].toDouble(), f[2])
        }
    }

    /** Moves the player's own finger to (sx, sy) and lifts it there: one shot at the new aim. */
    fun fire(slot: Int, sx: Float, sy: Float): Boolean {
        val p = toPanel(sx, sy)
        synchronized(fingers) { fingers.remove(slot) }
        return send("F $slot ${p[0]} ${p[1]}")
    }

    fun down(sx: Float, sy: Float): Boolean { val p = toPanel(sx, sy); return send("D ${p[0]} ${p[1]}") }
    fun move(sx: Float, sy: Float): Boolean { val p = toPanel(sx, sy); return send("M ${p[0]} ${p[1]}") }
    fun up(): Boolean = send("U")
}
