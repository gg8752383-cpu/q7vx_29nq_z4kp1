package com.automans.mobile

import android.media.Image
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Automatic target finder. No taps needed:
 *  - an enemy is recognised by the RED health bar above it,
 *  - the player's own fighter by the GREEN health bar (nearest to the screen centre),
 *  - allies (blue bars) are ignored.
 * Enemies are tracked from frame to frame, so the helper also knows where each one is heading and
 * where it will be in a moment. The nearest enemy becomes the aim target.
 */
class EnemyAutoAim {
    private class Bar(val x: Float, val y: Float)

    private class Track(var x: Float, var y: Float, var lastMs: Long) {
        val bornMs = lastMs
        var vx = 0f
        var vy = 0f
        var hits = 1
        var picked = false
        /** Recent observed positions (ms, x, y) for a steadier speed estimate than frame-to-frame differences. */
        val hist = ArrayList<DoubleArray>()
    }

    private var gridW = 0
    private var gridH = 0
    private var stride = 3
    private var sourceW = 0
    private var sourceH = 0
    private var mask = ByteArray(0)
    private var visited = ByteArray(0)
    private var queue = IntArray(0)
    private var lastProcessedMs = 0L
    private var lastTargetMs = 0L
    private var lastTx = 0f
    private var lastTy = 0f
    private var hasTarget = false
    private var lastDecision: AimDecision? = null
    private var lastSelfMs = 0L
    private var selfBadStreak = 0
    private var curNowMs = 0L
    private var projPx = 900f
    /** Set by the service: look for walls between the fighter and the target. */
    @Volatile var checkWalls = false
    /** Shots left (the orange pieces under the fighter's health bar), or -1 when unknown. */
    @Volatile var ammo = -1
        private set
    private var floorR = 0
    private var floorG = 0
    private var floorB = 0
    private var floorAtMs = -10000L
    /** The fighter's own velocity on screen (px/s). The camera follows him, so enemies seem to move the opposite way. */
    @Volatile var playerVx = 0f
    @Volatile var playerVy = 0f
    private val tracks = ArrayList<Track>()
    /** Average time one frame takes to analyse, in milliseconds (shown in the journal). */
    @Volatile var procMs = 0f
        private set

    /** true when the last call returned nothing only because the frame came too soon. */
    @Volatile var skipped: Boolean = false
        private set
    @Volatile var isLocked: Boolean = false
        private set
    @Volatile var enemyCount: Int = 0
        private set
    @Volatile var hasSelf: Boolean = false
        private set
    @Volatile var selfFx: Float = 0.5f
        private set
    @Volatile var selfFy: Float = 0.5f
        private set

    /** Kept for compatibility with the old tap-to-pick flow; targets are now found automatically. */
    fun selectTarget(screenX: Float, screenY: Float, width: Int, height: Int) = Unit

    /**
     * The player tapped the screen at (x,y): the enemy under the finger becomes the only target.
     * Tapping the same enemy again, or empty ground, goes back to automatic choice.
     * Returns 1 when an enemy was picked, 0 otherwise.
     */
    @Synchronized fun hasPick(): Boolean = tracks.any { it.picked }

    @Synchronized fun clearPick() {
        for (t in tracks) t.picked = false
    }

    @Synchronized fun pickAt(x: Float, y: Float): Int {
        val minDim = min(sourceW, sourceH).toFloat().coerceAtLeast(1f)
        var bi = -1
        var bd = minDim * 0.15f
        for (i in tracks.indices) {
            val d = hypot(tracks[i].x - x, tracks[i].y - y)
            if (d < bd) {
                bd = d
                bi = i
            }
        }
        val was = bi >= 0 && tracks[bi].picked
        for (t in tracks) t.picked = false
        if (bi >= 0 && !was) {
            tracks[bi].picked = true
            return 1
        }
        return 0
    }

    @Synchronized fun clear() {
        hasTarget = false
        lastDecision = null
        lastProcessedMs = 0L
        lastTargetMs = 0L
        lastSelfMs = 0L
        selfBadStreak = 0
        tracks.clear()
        isLocked = false
        enemyCount = 0
        hasSelf = false
    }

    @Synchronized fun process(image: Image, nowMs: Long, settings: DodgeSettings): AimDecision? {
        val plane = image.planes.firstOrNull() ?: return null
        return processBuffer(plane.buffer, plane.rowStride, plane.pixelStride, image.width, image.height, nowMs, settings)
    }

    /** Pure pixel logic, separated from android.media.Image so it can be tested on a normal JVM. */
    @Synchronized fun processBuffer(
        buffer: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        w: Int,
        h: Int,
        nowMs: Long,
        settings: DodgeSettings,
    ): AimDecision? {
        if (nowMs - lastProcessedMs < MIN_INTERVAL_MS) {
            skipped = true
            return null
        }
        skipped = false
        lastProcessedMs = nowMs
        val t0 = System.nanoTime()
        try {
            return analyse(buffer, rowStride, pixelStride, w, h, nowMs, settings)
        } finally {
            val ms = (System.nanoTime() - t0) / 1_000_000f
            procMs = if (procMs == 0f) ms else procMs * 0.9f + ms * 0.1f
        }
    }

    private fun analyse(
        buffer: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        w: Int,
        h: Int,
        nowMs: Long,
        settings: DodgeSettings,
    ): AimDecision? {
        curNowMs = nowMs
        projPx = BrawlerData.speedPx(settings.brawler, min(w, h).toFloat())
        if (w < 100 || h < 100) return null
        ensureGrid(w, h)
        val minDim = min(w, h).toFloat()

        val enemies = ArrayList<Bar>()
        val selves = ArrayList<Bar>()
        scan(buffer, rowStride, pixelStride, w, h, minDim, enemies, selves)
        enemyCount = enemies.size

        // ---- the player's own fighter (green bar nearest to the screen centre) ----
        var originX = settings.playerX.coerceIn(0.05f, 0.95f) * w
        var originY = settings.playerY.coerceIn(0.05f, 0.95f) * h
        var bestSelf: Bar? = null
        var bestSelfD = Float.MAX_VALUE
        // The camera follows the fighter, so his bar stays almost where it was. Take the green bar nearest
        // to the last good place and ignore far-away green things (other bars, decorations).
        val refX = if (hasSelf) selfFx * w else 0.50f * w
        val refBarY = if (hasSelf) selfFy * h - 0.11f * minDim else 0.41f * h
        for (s in selves) {
            val d = hypot(s.x - refX, s.y - refBarY)
            if (d < bestSelfD) {
                bestSelfD = d
                bestSelf = s
            }
        }
        val selfGate = if (hasSelf) minDim * 0.12f else minDim * 0.22f
        if (bestSelf != null && bestSelfD > selfGate) {
            selfBadStreak++
            // the camera may really have moved: re-lock only after many frames in a row
            if (selfBadStreak < 15) bestSelf = null
        }
        if (bestSelf != null) {
            selfBadStreak = 0
            ammo = countAmmo(buffer, rowStride, pixelStride, w, h, bestSelf.x, bestSelf.y, minDim)
        }
        if (bestSelf != null) {
            val fx = (bestSelf.x / w).coerceIn(0.05f, 0.95f)
            val fy = ((bestSelf.y + 0.11f * minDim) / h).coerceIn(0.05f, 0.95f)
            if (hasSelf) {
                // light smoothing only: heavy smoothing makes the helper trail behind the fighter
                selfFx = selfFx * 0.2f + fx * 0.8f
                selfFy = selfFy * 0.2f + fy * 0.8f
            } else {
                selfFx = fx
                selfFy = fy
            }
            hasSelf = true
            lastSelfMs = nowMs
        } else if (hasSelf && nowMs - lastSelfMs > 8000L) {
            hasSelf = false
        }
        if (hasSelf) {
            originX = selfFx * w
            originY = selfFy * h
        }

        // ---- enemy bodies sit a little below their health bars; follow them between frames ----
        val bodyDy = 0.10f * minDim
        updateTracks(enemies, bodyDy, nowMs, minDim)
        if (tracks.isEmpty()) {
            if (hasTarget && nowMs - lastTargetMs < 350L) return lastDecision
            hasTarget = false
            isLocked = false
            lastDecision = null
            return null
        }

        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in tracks.indices) {
            val d = hypot(tracks[i].x - originX, tracks[i].y - originY)
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        // Stick to the previous target unless another enemy is clearly closer (stops flicker).
        if (hasTarget) {
            var keep = -1
            var keepGap = Float.MAX_VALUE
            for (i in tracks.indices) {
                val gap = hypot(tracks[i].x - lastTx, tracks[i].y - lastTy)
                if (gap < keepGap) {
                    keepGap = gap
                    keep = i
                }
            }
            if (keep >= 0 && keepGap < minDim * 0.12f) {
                val dKeep = hypot(tracks[keep].x - originX, tracks[keep].y - originY)
                if (dKeep <= bestD * 1.35f) best = keep
            }
        }

        val pickedIdx = tracks.indexOfFirst { it.picked }
        if (pickedIdx >= 0) best = pickedIdx
        val target = tracks[best]
        if (target.hits < 3 || nowMs - target.bornMs < FRESH_MS) {
            // too fresh to trust: wait a couple of frames so a flicker never makes the helper press
            isLocked = false
            return null
        }
        val tx = target.x.coerceIn(0f, w - 1f)
        val ty = target.y.coerceIn(0f, h - 1f)
        lastTx = tx
        lastTy = ty
        hasTarget = true
        lastTargetMs = nowMs
        isLocked = true

        // where the target will be shortly (roughly the flight time of a shot)
        val pred = predict(target, minDim, w, h, originX, originY)
        val dx = pred[0] - originX
        val dy = pred[1] - originY
        val length = hypot(dx, dy)
        if (length < 1f) return null

        val others = ArrayList<Int>()
        for (i in tracks.indices) {
            if (i == best) continue
            val p = predict(tracks[i], minDim, w, h, originX, originY)
            others.add(tracks[i].x.toInt().coerceIn(0, w - 1))
            others.add(tracks[i].y.toInt().coerceIn(0, h - 1))
            others.add(p[0].toInt())
            others.add(p[1].toInt())
        }
        val blocked = checkWalls && wallBetween(buffer, rowStride, pixelStride, w, h, originX, originY, pred[0], pred[1], minDim, nowMs)
        val decision = AimDecision(
            dx = dx / length,
            dy = dy / length,
            targetX = tx.toInt(),
            targetY = ty.toInt(),
            confidence = 0.9f,
            reason = "враг найден по полоске здоровья",
            playerFx = originX / w,
            playerFy = originY / h,
            others = others.toIntArray(),
            targetVx = if (target.hits >= 3) target.vx else 0f,
            targetVy = if (target.hits >= 3) target.vy else 0f,
            predX = pred[0].toInt(),
            predY = pred[1].toInt(),
            blocked = blocked,
        )
        lastDecision = decision
        return decision
    }

    /** Four small orange pieces sit right under the player's green bar; empty ones are dark. */
    private fun countAmmo(buffer: ByteBuffer, rowStride: Int, pixelStride: Int, w: Int, h: Int, bx: Float, by: Float, minDim: Float): Int {
        val y0 = (by + minDim * 0.019f).toInt()
        var filled = 0
        for (i in 0 until 4) {
            val x0 = (bx + (i - 1.5f) * minDim * 0.026f).toInt()
            var orange = 0
            for (dy in -2..2) for (dx in -3..3) {
                val x = x0 + dx
                val y = y0 + dy
                if (x < 0 || y < 0 || x >= w || y >= h) continue
                val c = pix(buffer, rowStride, pixelStride, x, y)
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                if (r > 200 && g in 70..150 && b < 80) orange++
            }
            if (orange >= 6) filled++
        }
        return filled
    }

    private fun pix(buffer: ByteBuffer, rowStride: Int, pixelStride: Int, x: Int, y: Int): Int {
        val o = y * rowStride + x * pixelStride
        return ((buffer.get(o).toInt() and 255) shl 16) or ((buffer.get(o + 1).toInt() and 255) shl 8) or (buffer.get(o + 2).toInt() and 255)
    }

    /** The commonest colour of the picture is the floor; refreshed twice a second. */
    private fun learnFloor(buffer: ByteBuffer, rowStride: Int, pixelStride: Int, w: Int, h: Int, nowMs: Long) {
        if (nowMs - floorAtMs < 500L) return
        floorAtMs = nowMs
        val counts = IntArray(4096)
        var y = 6
        while (y < h - 6) {
            var x = 6
            while (x < w - 6) {
                val c = pix(buffer, rowStride, pixelStride, x, y)
                counts[((c shr 20) and 15) shl 8 or (((c shr 12) and 15) shl 4) or ((c shr 4) and 15)]++
                x += 14
            }
            y += 14
        }
        var best = 0
        for (i in counts.indices) if (counts[i] > counts[best]) best = i
        floorR = ((best shr 8) and 15) * 16 + 8
        floorG = ((best shr 4) and 15) * 16 + 8
        floorB = (best and 15) * 16 + 8
    }

    /**
     * Walks along the shot line and looks for a solid run of pixels that are neither floor, bush nor water.
     * Fighters and the target's own ring are skipped. Only a rough guess, but it stops the shots into walls.
     */
    private fun wallBetween(
        buffer: ByteBuffer, rowStride: Int, pixelStride: Int, w: Int, h: Int,
        ox: Float, oy: Float, tx: Float, ty: Float, minDim: Float, nowMs: Long,
    ): Boolean {
        learnFloor(buffer, rowStride, pixelStride, w, h, nowMs)
        val len = hypot(tx - ox, ty - oy)
        val skipStart = minDim * 0.04f
        val skipEnd = minDim * 0.04f
        if (len < skipStart + skipEnd + 20f) return false
        val ux = (tx - ox) / len
        val uy = (ty - oy) / len
        val floorGreen = floorG > floorR + 35 && floorG > floorB + 35
        val floorBlue = floorB > floorR + 60
        var run = 0
        var gap = 0
        var d = skipStart
        val step = 5f
        val stopAt = len - skipEnd
        val halfW = minDim * 0.10f
        val above = minDim * 0.17f
        val below = minDim * 0.09f
        while (d < stopAt) {
            val x = (ox + ux * d).toInt().coerceIn(0, w - 1)
            val y = (oy + uy * d).toInt().coerceIn(0, h - 1)
            d += step
            var masked = false
            // a fighter is a tall picture standing on his ring: skip the ring, the body and the head above it
            if (Math.abs(x - ox) < halfW && y > oy - above && y < oy + below) masked = true
            if (!masked) for (t in tracks) if (Math.abs(x - t.x) < halfW && y > t.y - above && y < t.y + below) { masked = true; break }
            if (masked) { run = 0; gap = 0; continue }
            val c = pix(buffer, rowStride, pixelStride, x, y)
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val bushy = !floorGreen && g > r + 35 && g > b + 35
            val watery = !floorBlue && b > r + 60
            val far = Math.abs(r - floorR) + Math.abs(g - floorG) + Math.abs(b - floorB) > 85
            if (far && !bushy && !watery) {
                run++
                gap = 0
                if (run >= 8) return true
            } else if (++gap > 2) {
                run = 0
            }
        }
        return false
    }

    /** Predicted screen position a moment from now; equals the current position if the enemy stands still. */
    private fun predict(t: Track, minDim: Float, w: Int, h: Int, ox: Float, oy: Float): FloatArray {
        var px = t.x
        var py = t.y
        if (t.hits >= 3) {
            // bar hidden for a moment (damage numbers, effects): keep following at the measured speed
            val unseen = ((curNowMs - t.lastMs) / 1000f).coerceIn(0f, 0.5f)
            if (unseen > 0.04f) {
                px += t.vx * unseen
                py += t.vy * unseen
            }
            // real movement of the enemy in the world = his motion on screen + the camera (fighter) motion
            val wvx = t.vx + playerVx
            val wvy = t.vy + playerVy
            val speed = hypot(wvx, wvy)
            if (speed > minDim * 0.06f) {
                // lead = reaction delay + flight time of the shot (farther enemy -> longer lead)
                val dist = hypot(t.x - ox, t.y - oy)
                val lead = (0.10f + dist / projPx).coerceIn(0.12f, 0.90f)
                var mx = wvx * lead
                var my = wvy * lead
                val mag = hypot(mx, my)
                val cap = minDim * 0.30f
                if (mag > cap) {
                    mx *= cap / mag
                    my *= cap / mag
                }
                px += mx
                py += my
            }
        }
        return floatArrayOf(px.coerceIn(0f, w - 1f), py.coerceIn(0f, h - 1f))
    }

    private fun updateTracks(enemies: List<Bar>, bodyDy: Float, nowMs: Long, minDim: Float) {
        val existing = tracks.size
        val used = BooleanArray(existing)
        val gate = minDim * 0.15f
        for (e in enemies) {
            val ex = e.x
            val ey = e.y + bodyDy
            var bestI = -1
            var bestD = gate
            for (i in 0 until existing) {
                if (used[i]) continue
                val d = hypot(tracks[i].x - ex, tracks[i].y - ey)
                if (d < bestD) {
                    bestD = d
                    bestI = i
                }
            }
            if (bestI >= 0) {
                used[bestI] = true
                val t = tracks[bestI]
                val dt = ((nowMs - t.lastMs) / 1000f).coerceIn(0.001f, 0.5f)
                val cap = minDim * 1.4f
                // a single frame difference is only used when the frames are far enough apart to mean something
                if (dt >= 0.008f) {
                    val mvx = (ex - t.x) / dt
                    val mvy = (ey - t.y) / dt
                    t.vx = (t.vx * 0.5f + mvx * 0.5f).coerceIn(-cap, cap)
                    t.vy = (t.vy * 0.5f + mvy * 0.5f).coerceIn(-cap, cap)
                }
                // least-squares line through the last ~0.3 s: far less jitter than one frame difference
                t.hist.add(doubleArrayOf(nowMs.toDouble(), ex.toDouble(), ey.toDouble()))
                while (t.hist.size > 0 && nowMs - t.hist[0][0] > 300.0) t.hist.removeAt(0)
                if (t.hist.size >= 4 && nowMs - t.hist[0][0] >= 90.0) {
                    var tm = 0.0; var xm = 0.0; var ym = 0.0
                    for (s in t.hist) { tm += s[0]; xm += s[1]; ym += s[2] }
                    val n = t.hist.size
                    tm /= n; xm /= n; ym /= n
                    var stt = 0.0; var stx = 0.0; var sty = 0.0
                    for (s in t.hist) {
                        val dtS = (s[0] - tm) / 1000.0
                        stt += dtS * dtS
                        stx += dtS * (s[1] - xm)
                        sty += dtS * (s[2] - ym)
                    }
                    if (stt > 1e-6) {
                        val lvx = (stx / stt).toFloat().coerceIn(-cap, cap)
                        val lvy = (sty / stt).toFloat().coerceIn(-cap, cap)
                        val wgt = if (n >= 8) 0.85f else 0.6f
                        t.vx = t.vx * (1f - wgt) + lvx * wgt
                        t.vy = t.vy * (1f - wgt) + lvy * wgt
                    }
                }
                t.x = ex
                t.y = ey
                t.lastMs = nowMs
                t.hits++
            } else {
                tracks.add(Track(ex, ey, nowMs))
            }
        }
        // drop enemies that were not seen for a moment (bars hidden by bushes etc.)
        var i = tracks.size - 1
        while (i >= 0) {
            if (nowMs - tracks[i].lastMs > 650L) tracks.removeAt(i)
            i--
        }
    }

    private fun ensureGrid(w: Int, h: Int) {
        if (w == sourceW && h == sourceH && gridW > 0) return
        sourceW = w
        sourceH = h
        stride = max(2, Math.round(max(w, h) / 780f))
        gridW = max(1, w / stride)
        gridH = max(1, h / stride)
        val n = gridW * gridH
        mask = ByteArray(n)
        visited = ByteArray(n)
        queue = IntArray(n)
        hasTarget = false
        lastDecision = null
        tracks.clear()
    }

    /** Marks exact health-bar colours, groups them, keeps only bar-shaped groups. */
    private fun scan(
        buffer: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        w: Int,
        h: Int,
        minDim: Float,
        enemies: MutableList<Bar>,
        selves: MutableList<Bar>,
    ) {
        val base = buffer.position()
        val limit = buffer.limit()
        // RGBA bytes read as one little-endian int: a single memory access per sample instead of three
        val fast = pixelStride == 4 && rowStride % 4 == 0 && base % 4 == 0
        val ints = if (fast) buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN).asIntBuffer() else null
        if (ints != null) {
            val rs = rowStride / 4
            val cap = ints.limit()
            for (gy in 0 until gridH) {
                val y = min(h - 1, gy * stride + stride / 2)
                val rowI = y * rs
                val out = gy * gridW
                for (gx in 0 until gridW) {
                    val x = min(w - 1, gx * stride + stride / 2)
                    val i = rowI + x
                    var t = 0
                    if (i < cap) {
                        val v = ints.get(i)
                        val r = v and 0xFF
                        if (r in 222..246) {
                            val g = (v ushr 8) and 0xFF
                            val b = (v ushr 16) and 0xFF
                            if (g in 12..62 && b in 36..62) t = 1
                        } else if (r in 55..82) {
                            val g = (v ushr 8) and 0xFF
                            val b = (v ushr 16) and 0xFF
                            if (g in 195..235 && b in 42..66) t = 2
                        }
                    }
                    mask[out + gx] = t.toByte()
                }
            }
        } else for (gy in 0 until gridH) {
            val y = min(h - 1, gy * stride + stride / 2)
            val row = base + y * rowStride
            val out = gy * gridW
            for (gx in 0 until gridW) {
                val x = min(w - 1, gx * stride + stride / 2)
                val idx = row + x * pixelStride
                var t = 0
                if (idx + 2 < limit) {
                    val r = buffer.get(idx).toInt() and 0xFF
                    val g = buffer.get(idx + 1).toInt() and 0xFF
                    val b = buffer.get(idx + 2).toInt() and 0xFF
                    if (r in 222..246 && g in 12..62 && b in 36..62) t = 1
                    else if (r in 55..82 && g in 195..235 && b in 42..66) t = 2
                }
                mask[out + gx] = t.toByte()
            }
        }
        java.util.Arrays.fill(visited, 0.toByte())

        val minW = minDim * 0.028f
        val minH = minDim * 0.0055f
        val maxH = minDim * 0.030f
        for (start in 0 until gridW * gridH) {
            val type = mask[start].toInt()
            if (type == 0 || visited[start].toInt() != 0) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = 1
            var count = 0
            var minX = gridW
            var maxX = 0
            var minY = gridH
            var maxY = 0
            while (head < tail) {
                val cur = queue[head++]
                val cx = cur % gridW
                val cy = cur / gridW
                count++
                if (cx < minX) minX = cx
                if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy
                if (cy > maxY) maxY = cy
                if (cx > 0) tail = push(cur - 1, type, tail)
                if (cx < gridW - 1) tail = push(cur + 1, type, tail)
                if (cy > 0) tail = push(cur - gridW, type, tail)
                if (cy < gridH - 1) tail = push(cur + gridW, type, tail)
            }
            val boxW = maxX - minX + 1
            val boxH = maxY - minY + 1
            val realW = boxW * stride
            val realH = boxH * stride
            if (realW < minW || realH < minH || realH > maxH) continue
            if (realW.toFloat() / realH.toFloat() < 2.5f) continue
            if (count.toFloat() / (boxW * boxH).toFloat() < 0.40f) continue
            val bar = Bar((minX + maxX + 1) / 2f * stride, (minY + maxY + 1) / 2f * stride)
            if (type == 1) enemies.add(bar) else selves.add(bar)
            if (enemies.size + selves.size >= 24) return
        }
    }

    private fun push(index: Int, type: Int, tail: Int): Int {
        if (mask[index].toInt() == type && visited[index].toInt() == 0 && tail < queue.size) {
            visited[index] = 1
            queue[tail] = index
            return tail + 1
        }
        return tail
    }

    private companion object {
        /** Every frame the screen recorder delivers is analysed (it already drops stale ones itself). */
        const val MIN_INTERVAL_MS = 4L
        /** A fresh bar must stay for this long before it counts as a target. */
        const val FRESH_MS = 60L
        const val LEAD_SECONDS = 0.35f
    }
}
