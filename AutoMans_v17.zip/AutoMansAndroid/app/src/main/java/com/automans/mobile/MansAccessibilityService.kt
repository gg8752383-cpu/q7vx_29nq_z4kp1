package com.automans.mobile

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import kotlin.math.min

class MansAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var current: MansAccessibilityService? = null
            private set
        /** Set by the touch-watcher overlay when the player touches the screen. */
        @Volatile var lastUserTouchMs: Long = 0L
        /** Time of the helper's own last gesture, so it does not mistake itself for the player. */
        @Volatile var lastInjectMs: Long = 0L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var lastNonSelfPackage: String? = null
    private var gestureBusy = false
    private var lastGestureAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString()?.lowercase() ?: return
        // The overlay/activity belongs to this app; do not let it overwrite the game target.
        if (!packageName.contains("automans")) lastNonSelfPackage = packageName
    }

    fun isLikelyBrawlForeground(): Boolean {
        val pkg = lastNonSelfPackage ?: return false
        return isBrawlPackage(pkg)
    }

    private fun isBrawlPackage(pkg: String): Boolean =
        pkg.contains("brawl", ignoreCase = true) || pkg.contains("nulls", ignoreCase = true)


    /**
     * Sends a short drag from the configured attack-stick center toward a target.
     * In Brawl-style controls, releasing that drag may also fire an attack.
     */
    fun dispatchAim(
        directionX: Float,
        directionY: Float,
        screenWidth: Int,
        screenHeight: Int,
        settings: DodgeSettings,
    ) {
        if (!directionX.isFinite() || !directionY.isFinite()) return
        if (directionX * directionX + directionY * directionY < 0.80f) return
        if (screenWidth < 100 || screenHeight < 100) return

        val rememberedPkg = lastNonSelfPackage
        mainHandler.post {
            val pkg = lastNonSelfPackage ?: rememberedPkg ?: return@post
            if (pkg.isBlank() || !isBrawlPackage(pkg)) return@post
            val now = SystemClock.elapsedRealtime()
            if (gestureBusy || now - lastGestureAt < 400L) return@post
            if (now - lastUserTouchMs < settings.userPauseTenths * 100L) return@post
            val radius = min(screenWidth, screenHeight) * settings.attackRadiusPct.coerceIn(0.04f, 0.14f)
            val startX = screenWidth * settings.attackX.coerceIn(0.65f, 0.97f)
            val startY = screenHeight * settings.attackY.coerceIn(0.55f, 0.95f)
            // drag past the stick edge = full shot range (a short drag makes the shot fall short)
            val reach = radius * 1.6f
            val targetX = (startX + directionX.coerceIn(-1f, 1f) * reach).coerceIn(1f, screenWidth - 2f)
            val targetY = (startY + directionY.coerceIn(-1f, 1f) * reach).coerceIn(1f, screenHeight - 2f)
            val path = Path().apply { moveTo(startX, startY); lineTo(targetX, targetY) }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 140L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            gestureBusy = true
            lastGestureAt = now
            lastInjectMs = now
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    gestureBusy = false
                    lastInjectMs = SystemClock.elapsedRealtime()
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    gestureBusy = false
                    lastInjectMs = SystemClock.elapsedRealtime()
                }
            }, mainHandler)
            if (!accepted) gestureBusy = false
        }
    }


    // ---------- held aim: press the attack stick, follow the enemy, release once when lined up ----------
    private var aimStroke: GestureDescription.StrokeDescription? = null
    private var aimHolding = false
    private var aimStartMs = 0L
    private var aimCurX = 0f
    private var aimCurY = 0f
    private var aimWantX = 0f
    private var aimWantY = 0f
    private var aimBaseX = 0f
    private var aimBaseY = 0f
    private var aimReach = 0f
    private var aimScreenW = 0
    private var aimScreenH = 0
    private var aimRelease = 0 // 0 = keep holding, 1 = release (shoot), 2 = release back at centre (cancel)
    private var lastAimEndMs = 0L
    private var aimLastDirMs = 0L

    /** Called every frame. dx,dy = unit direction to the predicted enemy centre; null = no target in range. */
    fun aimFrame(dirX: Float?, dirY: Float?, screenWidth: Int, screenHeight: Int, settings: DodgeSettings) {
        val hasDir = dirX != null && dirY != null && dirX.isFinite() && dirY.isFinite() &&
            dirX * dirX + dirY * dirY > 0.5f
        mainHandler.post {
            try {
                handleAimFrame(if (hasDir) dirX!! else 0f, if (hasDir) dirY!! else 0f, hasDir, screenWidth, screenHeight, settings)
            } catch (ignored: Exception) {
                aimHolding = false
                aimStroke = null
            }
        }
    }

    private fun handleAimFrame(dx: Float, dy: Float, hasDir: Boolean, w: Int, h: Int, settings: DodgeSettings) {
        if (w < 100 || h < 100) return
        val now = SystemClock.elapsedRealtime()
        if (aimHolding) {
            if (now - lastUserTouchMs < settings.userPauseTenths * 100L && now - lastInjectMs > 400L) {
                aimRelease = 2
            } else if (!hasDir) {
                if (now - aimLastDirMs > 300L) aimRelease = 2
            } else {
                aimLastDirMs = now
                aimWantX = dx
                aimWantY = dy
                val held = now - aimStartMs
                if (held > 1400L) {
                    aimRelease = 2
                } else if (held >= 240L && aimRelease == 0) {
                    // current stick direction vs wanted direction
                    val cx = aimCurX - aimBaseX
                    val cy = aimCurY - aimBaseY
                    val len = Math.hypot(cx.toDouble(), cy.toDouble()).toFloat()
                    if (len > 1f) {
                        val dot = (cx / len) * dx + (cy / len) * dy
                        if (dot >= 0.985f) aimRelease = 1
                    }
                }
            }
            return
        }
        if (!hasDir || gestureBusy) return
        if (now - lastAimEndMs < 700L) return
        if (now - lastUserTouchMs < settings.userPauseTenths * 100L) return
        val pkg = lastNonSelfPackage ?: return
        if (!isBrawlPackage(pkg)) return
        val radius = min(w, h) * settings.attackRadiusPct.coerceIn(0.04f, 0.14f)
        aimBaseX = w * settings.attackX.coerceIn(0.65f, 0.97f)
        aimBaseY = h * settings.attackY.coerceIn(0.55f, 0.95f)
        aimReach = radius * 1.6f
        aimScreenW = w
        aimScreenH = h
        aimWantX = dx
        aimWantY = dy
        aimCurX = aimBaseX
        aimCurY = aimBaseY
        aimRelease = 0
        aimLastDirMs = now
        aimStartMs = now
        aimStroke = null
        aimHolding = true
        sendAimSegment(first = true)
    }

    private fun aimPoint(dx: Float, dy: Float): FloatArray = floatArrayOf(
        (aimBaseX + dx * aimReach).coerceIn(1f, aimScreenW - 2f),
        (aimBaseY + dy * aimReach).coerceIn(1f, aimScreenH - 2f),
    )

    private fun sendAimSegment(first: Boolean) {
        val release = aimRelease
        val target = if (release == 2) floatArrayOf(aimBaseX, aimBaseY) else aimPoint(aimWantX, aimWantY)
        val path = Path().apply { moveTo(aimCurX, aimCurY); lineTo(target[0], target[1]) }
        val last = release != 0
        val duration = if (first) 60L else 50L
        val stroke = if (first || aimStroke == null) {
            GestureDescription.StrokeDescription(path, 0L, duration, !last)
        } else {
            aimStroke!!.continueStroke(path, 0L, duration, !last)
        }
        aimStroke = stroke
        aimCurX = target[0]
        aimCurY = target[1]
        gestureBusy = true
        lastInjectMs = SystemClock.elapsedRealtime()
        val accepted = dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) = afterAimSegment(last)
            override fun onCancelled(gestureDescription: GestureDescription?) = afterAimSegment(true)
        }, mainHandler)
        if (!accepted) {
            gestureBusy = false
            aimHolding = false
            aimStroke = null
            lastAimEndMs = SystemClock.elapsedRealtime()
        }
    }

    private fun afterAimSegment(finished: Boolean) {
        lastInjectMs = SystemClock.elapsedRealtime()
        gestureBusy = false
        if (finished || !aimHolding) {
            aimHolding = false
            aimStroke = null
            lastAimEndMs = SystemClock.elapsedRealtime()
            return
        }
        try { sendAimSegment(first = false) } catch (ignored: Exception) {
            aimHolding = false
            aimStroke = null
            lastAimEndMs = SystemClock.elapsedRealtime()
        }
    }

    override fun onInterrupt() {
        aimHolding = false
        aimStroke = null
        gestureBusy = false
    }

    fun dispatchDodge(
        directionX: Float,
        directionY: Float,
        screenWidth: Int,
        screenHeight: Int,
        settings: DodgeSettings,
    ) {
        if (!directionX.isFinite() || !directionY.isFinite()) return
        if (directionX * directionX + directionY * directionY < 0.20f) return
        if (screenWidth < 100 || screenHeight < 100) return

        // Only inject into a window whose package resembles Null's Brawl/Brawl Stars.
        // This avoids swiping another app if AUTO is left enabled after the game closes.
        val rememberedPkg = lastNonSelfPackage
        mainHandler.post {
            // Re-read the most recent window event on the main thread. This avoids requesting
            // accessibility window-content access just to identify the foreground package.
            val pkg = lastNonSelfPackage ?: rememberedPkg ?: return@post
            if (pkg.isBlank()) return@post
            if (!isBrawlPackage(pkg)) return@post
            val now = SystemClock.elapsedRealtime()
            if (gestureBusy || now - lastGestureAt < 380L) return@post
            if (now - lastUserTouchMs < settings.userPauseTenths * 100L) return@post
            val radius = min(screenWidth, screenHeight) * settings.joystickRadiusPct.coerceIn(0.04f, 0.14f)
            val startX = screenWidth * settings.joystickX.coerceIn(0.03f, 0.25f)
            val startY = screenHeight * settings.joystickY.coerceIn(0.55f, 0.95f)
            val targetX = (startX + directionX.coerceIn(-1f, 1f) * radius).coerceIn(1f, screenWidth - 2f)
            val targetY = (startY + directionY.coerceIn(-1f, 1f) * radius).coerceIn(1f, screenHeight - 2f)

            val path = Path().apply {
                moveTo(startX, startY)
                lineTo(targetX, targetY)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 320L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            gestureBusy = true
            lastGestureAt = now
            lastInjectMs = now
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    gestureBusy = false
                    lastInjectMs = SystemClock.elapsedRealtime()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    gestureBusy = false
                    lastInjectMs = SystemClock.elapsedRealtime()
                }
            }, mainHandler)
            if (!accepted) gestureBusy = false
        }
    }

    override fun onDestroy() {
        gestureBusy = false
        if (current === this) current = null
        super.onDestroy()
    }
}
