package com.automans.mobile

/** Projectile speed (game units/s) and shot range per fighter, taken from the game tables. 0 = unknown. */
object BrawlerData {
    class Entry(val id: String, val title: String, val speed: Int, val range: Int, val move: Int = 0)
    val all: List<Entry> = listOf(
        Entry("Arcade", "8-Bit (Arcade)", 4500, 30, 600),
        Entry("FireDude", "Amber (FireDude)", 3500, 25, 750),
        Entry("Barkeep", "Barley (Barkeep)", 1750, 22, 750),
        Entry("BeeSniper", "Bea (BeeSniper)", 3255, 30, 750),
        Entry("Baseball", "Bibi (Baseball)", 0, 11, 855),
        Entry("BowDude", "Bo (BowDude)", 2800, 26, 750),
        Entry("RocketGirl", "Brock (RocketGirl)", 2700, 27, 750),
        Entry("BullDude", "Bull (BullDude)", 2853, 16, 800),
        Entry("SnakeOil", "Byron (SnakeOil)", 4000, 30, 750),
        Entry("Whirlwind", "Carl (Whirlwind)", 3000, 25, 750),
        Entry("Percenter", "Colette (Percenter)", 4000, 26, 750),
        Entry("Ruffs", "Colonel Ruffs (Ruffs)", 3800, 27, 750),
        Entry("Gunslinger", "Colt (Gunslinger)", 4000, 27, 750),
        Entry("Crow", "Crow (Crow)", 3261, 26, 855),
        Entry("BarrelBot", "Darryl (BarrelBot)", 4000, 18, 800),
        Entry("TntDude", "Dynamike (TntDude)", 1900, 22, 800),
        Entry("Enrager", "Edgar (Enrager)", 3500, 6, 855),
        Entry("Luchador", "El Primo (Luchador)", 3261, 9, 800),
        Entry("Mummy", "Emz (Mummy)", 1500, 20, 750),
        Entry("HammerDude", "Frank (HammerDude)", 5000, 18, 800),
        Entry("Blower", "Gale (Blower)", 3000, 25, 750),
        Entry("HookDude", "Gene (HookDude)", 3200, 17, 750),
        Entry("Driller", "Jacky (Driller)", 0, 10, 800),
        Entry("Mechanic", "Jessie (Mechanic)", 3050, 27, 750),
        Entry("Ninja", "Leon (Ninja)", 3500, 29, 855),
        Entry("IceDude", "Lou (IceDude)", 4000, 28, 750),
        Entry("Speedy", "Max (Speedy)", 4000, 25, 855),
        Entry("Undertaker", "Mortis (Undertaker)", 0, 8, 855),
        Entry("SpawnerDude", "Mr. P (SpawnerDude)", 3000, 21, 750),
        Entry("Controller", "Nani (Controller)", 4000, 26, 750),
        Entry("Shaman", "Nita (Shaman)", 2718, 18, 750),
        Entry("MinigunDude", "Pam (MinigunDude)", 4130, 27, 750),
        Entry("ArtilleryDude", "Penny (ArtilleryDude)", 3400, 26, 750),
        Entry("Sniper", "Piper (Sniper)", 4000, 30, 750),
        Entry("DeadMariachi", "Poco (DeadMariachi)", 2500, 21, 750),
        Entry("TrickshotDude", "Rico (TrickshotDude)", 3478, 29, 750),
        Entry("Rosa", "Rosa (Rosa)", 5000, 11, 800),
        Entry("Sandstorm", "Sandy (Sandstorm)", 3500, 18, 800),
        Entry("Cactus", "Spike (Cactus)", 2174, 23, 750),
        Entry("PowerLeveler", "Surge (PowerLeveler)", 3500, 20, 705),
        Entry("BlackHole", "Tara (BlackHole)", 3152, 24, 750),
        Entry("ClusterBombDude", "Tick (ClusterBombDude)", 450, 26, 750),
        Entry("Alternator", "Alternator", 3700, 25, 800),
        Entry("Ambusher", "Ambusher", 3500, 6, 855),
        Entry("AssaultShotgun", "AssaultShotgun", 3100, 25, 750),
        Entry("Attractor", "Attractor", 1600, 27, 750),
        Entry("AxeJuggler", "AxeJuggler", 4500, 24, 750),
        Entry("Beamer", "Beamer", 3800, 27, 750),
        Entry("Bulletstorm", "Bulletstorm", 4000, 30, 750),
        Entry("CannonGirl", "CannonGirl", 3800, 27, 630),
        Entry("CannonGirlSmall", "CannonGirlSmall", 3000, 15, 855),
        Entry("Chronomancer", "Chronomancer", 3000, 25, 800),
        Entry("Cocooner", "Cocooner", 4200, 27, 750),
        Entry("Conductor", "Conductor", 2700, 18, 800),
        Entry("Cooker", "Cooker", 4000, 27, 750),
        Entry("Crab", "Crab", 3500, 23, 750),
        Entry("CrossBomber", "CrossBomber", 840, 23, 750),
        Entry("Dancer", "Dancer", 3000, 24, 800),
        Entry("Digger", "Digger", 2800, 15, 800),
        Entry("DiggerDrill", "DiggerDrill", 3500, 5, 920),
        Entry("DoorMan", "DoorMan", 3804, 27, 750),
        Entry("DragonRider", "DragonRider", 3800, 12, 750),
        Entry("Duelist", "Duelist", 3800, 16, 855),
        Entry("Duplicator", "Duplicator", 4500, 27, 750),
        Entry("ElectroSniper", "ElectroSniper", 4000, 30, 750),
        Entry("Flea", "Flea", 3500, 28, 750),
        Entry("Fury", "Fury", 29000, 22, 800),
        Entry("FutureGirl", "FutureGirl", 3500, 24, 800),
        Entry("GeishaTransformed", "GeishaTransformed", 3500, 20, 750),
        Entry("Gladiator", "Gladiator", 5000, 8, 800),
        Entry("InsectMan", "InsectMan", 4000, 30, 855),
        Entry("Jester", "Jester", 3300, 25, 800),
        Entry("JetpackGirl", "JetpackGirl", 3650, 12, 750),
        Entry("KickerDude", "KickerDude", 3200, 8, 800),
        Entry("Knight", "Knight", 5000, 14, 750),
        Entry("MagicalGirl", "MagicalGirl", 15000, 17, 855),
        Entry("Maisie", "Maisie", 3200, 26, 750),
        Entry("MechaDude", "MechaDude", 4000, 27, 855),
        Entry("MechaDudeBig", "MechaDudeBig", 4500, 22, 750),
        Entry("Meeple", "Meeple", 3000, 23, 750),
        Entry("Mender", "Mender", 5000, 22, 800),
        Entry("Morningstar", "Morningstar", 3500, 24, 750),
        Entry("Painter", "Painter", 2200, 19, 750),
        Entry("Puppeteer", "Puppeteer", 1750, 22, 750),
        Entry("Redirecter", "Redirecter", 1700, 18, 800),
        Entry("Roller", "Roller", 3300, 23, 750),
        Entry("RopeDude", "RopeDude", 4000, 8, 800),
        Entry("Shadowdemon", "Shadowdemon", 2500, 22, 750),
        Entry("ShieldTank", "ShieldTank", 4200, 16, 800),
        Entry("Silencer", "Silencer", 3600, 27, 750),
        Entry("Skater", "Skater", 3000, 19, 800),
        Entry("SoulCollector", "SoulCollector", 4000, 28, 750),
        Entry("Splitter", "Splitter", 4500, 30, 750),
        Entry("Stacker", "Stacker", 4000, 25, 750),
        Entry("StickyBomb", "StickyBomb", 4000, 23, 750),
        Entry("SuperNovaBeeSniper", "SuperNovaBeeSniper", 2800, 28, 855),
        Entry("SuperNovaCactus", "SuperNovaCactus", 2174, 11, 750),
        Entry("SuperNovaFireDude", "SuperNovaFireDude", 2800, 17, 855),
        Entry("SuperNovaVoodoo", "SuperNovaVoodoo", 1750, 10, 750),
        Entry("Twins", "Twins", 2000, 22, 800),
        Entry("Voodoo", "Voodoo", 1750, 19, 750),
        Entry("Wally", "Wally", 1700, 15, 750),
        Entry("WeaponThrower", "WeaponThrower", 5000, 9, 800),
    )

    fun find(id: String): Entry? = all.firstOrNull { it.id == id }

    /** Units of speed per second -> screen pixels per second (one tile = 300 units = about 0.074 of the screen height). */
    fun speedPx(id: String, minDim: Float): Float {
        val s = find(id)?.speed ?: 0
        val units = if (s <= 0) 3500 else s.coerceIn(1500, 12000)
        return units * (0.074f * minDim / 300f)
    }

    /** The fighter's own walking speed in screen pixels per second (one tile = 300 units). */
    fun movePx(id: String, minDim: Float): Float {
        val m = find(id)?.move ?: 0
        return (if (m <= 0) 750 else m) * (0.074f * minDim / 300f)
    }

    /** Shot range as a share of the screen height (range units / 2.7 = tiles). */
    fun rangeFrac(id: String): Float {
        val r = find(id)?.range ?: 0
        return if (r <= 0) 0.70f else (r / 2.7f * 0.074f).coerceIn(0.25f, 0.85f)
    }
}
