package com.automans.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import android.content.res.ColorStateList
import android.content.pm.ServiceInfo
import kotlin.math.hypot

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_STOP = "com.automans.mobile.STOP_CAPTURE"
        const val ACTION_TOGGLE_ALL = "com.automans.mobile.TOGGLE_ALL"
        const val ACTION_TOGGLE_DODGE = "com.automans.mobile.TOGGLE_DODGE"
        private const val CHANNEL = "automans_capture"
        private const val NOTIFICATION_ID = 31
        @Volatile var autoEnabled: Boolean = false
    }

    private var projection: MediaProjection? = null
    @Volatile private var reader: ImageReader? = null
    private val autoDodge = AutoDodge()
    // frame-rate statistics for the journal
    private var statFrames = 0
    private var lastFrameAgeMs = 0f
    private var statAnalysed = 0
    private var statStartMs = 0L
    private var statAgeSum = 0f
    private var statAgeMax = 0f
    private var statAgeN = 0
    private var display: VirtualDisplay? = null
    private var windowManager: WindowManager? = null
    private var displayManager: DisplayManager? = null
    private var floatingButton: Button? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var aimButton: Button? = null
    private var aimButtonParams: WindowManager.LayoutParams? = null
    private var aimPickerView: View? = null
    @Volatile private var aimEnabled = false
    @Volatile private var aimPicking = false
    private val aimEngine = EnemyAutoAim()
    private var lastAimGestureMs = 0L
    private var aimTouchDownX = 0f
    private var aimTouchDownY = 0f
    private var aimTouchDownWindowX = 0
    private var aimTouchDownWindowY = 0
    private var aimDraggingButton = false
    private var visionThread: HandlerThread? = null
    private var visionHandler: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val visionEngine = VisionDodgeEngine()
    private var settings = DodgeSettings()
    @Volatile private var captureWidth = 0
    @Volatile private var captureHeight = 0
    private var lastUiUpdateMs = 0L
    private var lastLogMs = 0L
    private val shellAim = ShellAim()
    private val manualAssist = ManualAssist()
    init { ShellTouch.onFinger = { manualAssist.onFinger() } }
    private var lastShellTryMs = 0L
    private var lastShotCounter = 0
    private var lastWallLogMs = 0L
    @Volatile private var targetWasForeground = false
    private var touchDownRawX = 0f
    private var touchDownRawY = 0f
    private var touchDownWindowX = 0
    private var touchDownWindowY = 0
    private var draggingButton = false
    private var buttonPressed = false
    private var longPressTriggered = false
    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    private val longPressStop = Runnable {
        if (buttonPressed && !draggingButton) {
            longPressTriggered = true
            autoEnabled = false
            Toast.makeText(this, "Auto-Mans остановлен", Toast.LENGTH_SHORT).show()
            stopSelf()
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) scheduleCaptureReconfigure()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            autoEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_TOGGLE_ALL) {
            // Button in the notification shade: switch everything off / on.
            if (projection != null) mainHandler.post { toggleAll() }
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_TOGGLE_DODGE) {
            mainHandler.post {
                val on = !settings.autoDodge
                settings = settings.copy(autoDodge = on)
                DodgeSettings.saveAutoDodge(this, on)
                if (!on) autoDodge.cancel()
                Toast.makeText(this, if (on) "Уклонение включено" else "Уклонение выключено", Toast.LENGTH_SHORT).show()
                try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification()) } catch (ignored: Exception) { }
            }
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION,
            )
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null || resultCode == 0) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            settings = DodgeSettings.load(this)
            visionThread = HandlerThread("AutoMansVision", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY).also { it.start() }
            visionHandler = Handler(visionThread!!.looper)
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    mainHandler.post { stopSelf() }
                }
            }, mainHandler)
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            displayManager = getSystemService(DISPLAY_SERVICE) as DisplayManager
            displayManager?.registerDisplayListener(displayListener, mainHandler)
            configureCapture(force = true)
            showFloatingButton()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить захват: ${e.message ?: "ошибка Android"}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun scheduleCaptureReconfigure() {
        mainHandler.postDelayed({
            try {
                configureCapture(force = false)
            } catch (ignored: Exception) {
                // Rotation can briefly report stale display metrics. Retry once after layout settles.
                mainHandler.postDelayed({
                    try { configureCapture(force = false) } catch (ignored: Exception) { /* next display event may retry */ }
                }, 420L)
            }
        }, 260L)
    }

    private fun configureCapture(force: Boolean) {
        val metrics = currentDisplayMetrics()
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        if (!force && width == captureWidth && height == captureHeight) return
        val handler = visionHandler ?: return
        val newReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 4)
        newReader.setOnImageAvailableListener({ source -> onImageAvailable(source) }, handler)
        val oldReader = reader

        try {
            val densityDpi = metrics.densityDpi.coerceAtLeast(1)
            val currentDisplay = display
            if (currentDisplay == null) {
                val currentProjection = projection ?: throw IllegalStateException("MediaProjection не запущен")
                val created = currentProjection.createVirtualDisplay(
                    "AutoMansScreen",
                    width,
                    height,
                    densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    newReader.surface,
                    null,
                    mainHandler,
                ) ?: throw IllegalStateException("Android не создал виртуальный экран")
                display = created
            } else {
                currentDisplay.resize(width, height, densityDpi)
                currentDisplay.surface = newReader.surface
            }
        } catch (e: Exception) {
            newReader.setOnImageAvailableListener(null, null)
            try { newReader.close() } catch (ignored: Exception) { }
            throw e
        }

        // Publish the new reader only after the VirtualDisplay accepts its surface.
        reader = newReader
        oldReader?.setOnImageAvailableListener(null, null)
        try { oldReader?.close() } catch (ignored: Exception) { }
        visionEngine.reset()
        captureWidth = width
        captureHeight = height
        clampOverlayToScreen()
    }

    private fun currentDisplayMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        val wm = windowManager ?: (getSystemService(WINDOW_SERVICE) as WindowManager)
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        if (metrics.widthPixels <= 0 || metrics.heightPixels <= 0) {
            val fallback = resources.displayMetrics
            metrics.setTo(fallback)
        }
        return metrics
    }

    private fun onImageAvailable(source: ImageReader) {
        if (source !== reader) {
            try { source.acquireLatestImage()?.close() } catch (ignored: Exception) { }
            return
        }
        var image: Image? = null
        try {
            image = source.acquireLatestImage() ?: return
            statFrames++
            run {
                // how old the picture already is when we get it (the recorder stamps it with one of two clocks)
                val ts = image.timestamp
                val a = (System.nanoTime() - ts) / 1_000_000f
                val b = (SystemClock.elapsedRealtimeNanos() - ts) / 1_000_000f
                val age = listOf(a, b).filter { it in 0f..3000f }.minOrNull()
                if (age != null) { lastFrameAgeMs = age; statAgeSum += age; statAgeN++; if (age > statAgeMax) statAgeMax = age }
            }
            val controls = MansAccessibilityService.current
            val gameForeground = (autoEnabled || aimEnabled) && controls?.isLikelyBrawlForeground() == true
            if (gameForeground) {
                if (!targetWasForeground) visionEngine.reset()
                targetWasForeground = true
                val nowMs = SystemClock.elapsedRealtime()
                // Enemies and the player are found by their health bars; this also gives the true fighter position.
                if (ShellTouch.ready) {
                    val mdim = minOf(captureWidth, captureHeight).toFloat()
                    val mv = ShellTouch.moveVector(mdim)
                    val sp = BrawlerData.movePx(settings.brawler, mdim)
                    aimEngine.playerVx = mv[0] * sp + autoDodge.vx * sp
                    aimEngine.playerVy = mv[1] * sp + autoDodge.vy * sp
                } else {
                    aimEngine.playerVx = 0f
                    aimEngine.playerVy = 0f
                }
                // frame time from the screen recorder itself: steadier than the moment we got round to processing it
                val frameMs = image.timestamp / 1_000_000L
                aimEngine.checkWalls = settings.wallCheck && ShellTouch.ready && !shellAim.isHolding && !BrawlerData.overWalls(settings.brawler)
                val scanned = if (autoEnabled || aimEnabled) aimEngine.process(image, if (frameMs > 0L) frameMs else nowMs, settings) else null
                if (!aimEngine.skipped) statAnalysed++
                val live = if (aimEngine.hasSelf) settings.copy(playerX = aimEngine.selfFx, playerY = aimEngine.selfFy) else settings
                val dodgeDecision = if (autoEnabled && settings.dodgeInject) visionEngine.process(image, nowMs, live) else null
                val aimDecision = if (aimEnabled) scanned else null

                // Aim marker: always shown while the target is tracked, even if Aim does not press.
                if (aimDecision != null) {
                    val markerX = aimDecision.targetX
                    val markerY = aimDecision.targetY
                    val fx = live.playerX
                    val fy = live.playerY
                    val extra = aimDecision.others
                    val vx = aimDecision.targetVx
                    val vy = aimDecision.targetVy
                    val nextX = aimDecision.predX.toFloat()
                    val nextY = aimDecision.predY.toFloat()
                    hud?.let { h -> mainHandler.post { h.setAim(markerX.toFloat(), markerY.toFloat(), vx, vy, nextX, nextY, fx, fy, extra) } }
                }

                if (ShellTouch.ready && settings.assistAim && !aimEngine.skipped) {
                    manualAssist.update(
                        aimEngine.snapshot, captureWidth, captureHeight, settings,
                        BrawlerData.overWalls(settings.brawler),
                        BrawlerData.rangeFrac(settings.brawler) * minOf(captureWidth, captureHeight),
                        aimEngine.ammo, lastFrameAgeMs, nowMs,
                    )
                }

                // Keep the fighter moving sideways to the nearest enemy while the player's move stick is free.
                if (ShellTouch.ready && !(scanned == null && aimEngine.skipped)) {
                    autoDodge.frame(scanned, captureWidth, captureHeight, settings, nowMs, live.playerX * captureWidth, live.playerY * captureHeight, shellAim.isHolding)
                }

                // Survival has priority. Do not inject an attack swipe while a dodge is required.
                if (dodgeDecision != null && dodgeDecision.shouldDodge) {
                    val arrowX = dodgeDecision.dx
                    val arrowY = dodgeDecision.dy
                    val fx = live.playerX
                    val fy = live.playerY
                    hud?.let { h -> mainHandler.post { h.setDodge(arrowX, arrowY, fx, fy) } }
                    if (settings.dodgeInject) {
                        controls?.dispatchDodge(
                            dodgeDecision.dx,
                            dodgeDecision.dy,
                            captureWidth,
                            captureHeight,
                            settings,
                        )
                    }
                } else if (settings.aimInject && !(scanned == null && aimEngine.skipped)) {
                    val sc = MansAccessibilityService.shotCounter
                    if (sc != lastShotCounter) {
                        lastShotCounter = sc
                        if (!settings.autoFire) aimEngine.clearPick()
                    }
                    val wallBlocked = aimDecision != null && aimDecision.blocked && ShellTouch.ready && !shellAim.isHolding
                    if (wallBlocked && nowMs - lastWallLogMs > 2000L) {
                        lastWallLogMs = nowMs
                        AimLog.add("стена на линии выстрела: не стреляю")
                    }
                    val wanted = !wallBlocked && (settings.autoFire || aimEngine.hasPick())
                    val brawlerRange = BrawlerData.rangeFrac(settings.brawler).toDouble()
                    val rangeFrac = if (aimEngine.hasPick()) brawlerRange else minOf(brawlerRange, 0.45)
                    val inRange = wanted && aimDecision != null && aimEngine.isLocked && hypot(
                        (aimDecision.targetX - live.playerX * captureWidth).toDouble(),
                        (aimDecision.targetY - live.playerY * captureHeight).toDouble(),
                    ) <= minOf(captureWidth, captureHeight) * rangeFrac
                    if (inRange) {
                        val dist = hypot(
                            (aimDecision!!.predX - live.playerX * captureWidth).toDouble(),
                            (aimDecision.predY - live.playerY * captureHeight).toDouble(),
                        ).toFloat()
                        if (ShellTouch.ready) shellAim.frame(aimDecision.dx, aimDecision.dy, true, dist, captureWidth, captureHeight, settings, nowMs,
                            BrawlerData.overWalls(settings.brawler), BrawlerData.rangeFrac(settings.brawler) * minOf(captureWidth, captureHeight))
                        else controls?.aimFrame(aimDecision.dx, aimDecision.dy, dist, captureWidth, captureHeight, settings)
                    } else if (ShellTouch.ready) shellAim.frame(0f, 0f, false, 0f, captureWidth, captureHeight, settings, nowMs)
                    else controls?.aimFrame(null, null, 0f, captureWidth, captureHeight, settings)
                }
            } else {
                if (targetWasForeground) { visionEngine.reset(); shellAim.cancel(); autoDodge.cancel() }
                targetWasForeground = false
                statStartMs = 0L; statFrames = 0; statAnalysed = 0; statAgeSum = 0f; statAgeMax = 0f; statAgeN = 0
            }
            val now = SystemClock.elapsedRealtime()
            if (now - lastLogMs >= 2000L && gameForeground) {
                lastLogMs = now
                val secs = ((now - statStartMs) / 1000f).coerceAtLeast(0.1f)
                val ageAvg = if (statAgeN > 0) statAgeSum / statAgeN else -1f
                val haveStats = statStartMs != 0L
                AimLog.add("кадр ${captureWidth}x${captureHeight}: патронов=${aimEngine.ammo} врагов=${aimEngine.enemyCount} боец=${if (aimEngine.hasSelf) "найден %.2f,%.2f".format(java.util.Locale.US, aimEngine.selfFx, aimEngine.selfFy) else "НЕ найден"} цель=${aimEngine.isLocked}")
                if (haveStats) AimLog.add("скорость: кадров %.0f/с, разобрано %.0f/с, разбор %.1f мс, возраст кадра %.0f мс (макс %.0f)".format(java.util.Locale.US, statFrames / secs, statAnalysed / secs, aimEngine.procMs, ageAvg, statAgeMax))
                statFrames = 0; statAnalysed = 0; statStartMs = now; statAgeSum = 0f; statAgeMax = 0f; statAgeN = 0
            }
            if (now - lastUiUpdateMs >= 500L) {
                lastUiUpdateMs = now
                mainHandler.post {
                    updateFloatingButton()
                    updateAimButton()
                    try {
                        ShellTouch.screenW = captureWidth
                        ShellTouch.screenH = captureHeight
                        @Suppress("DEPRECATION")
                        ShellTouch.rotation = windowManager?.defaultDisplay?.rotation ?: 1
                        if (ShellTouch.ready) ShellTouch.syncGeometry()
                    } catch (ignored: Exception) { }
                    startShellTouchIfPossible()
                }
            }
        } catch (ignored: IllegalStateException) {
            // ImageReader may be closing during a display rotation.
        } catch (ignored: Exception) {
            // Keep a single damaged frame from stopping the screen pipeline.
        } finally {
            try { image?.close() } catch (ignored: Exception) { }
        }
    }

    private fun showFloatingButton() {
        val wm = windowManager ?: return
        @Suppress("UNUSED_VARIABLE") val button = Button(this).apply {
            text = "MANS OFF"
            textSize = 12f
            isAllCaps = false
            setPadding(dp(8), dp(2), dp(8), dp(2))
            backgroundTintList = ColorStateList.valueOf(Color.rgb(55, 58, 65))
            setOnTouchListener { view, event -> handleOverlayTouch(view as Button, event) }
        }
        floatingButton = button
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            dp(138), dp(50), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(86)
        }
        overlayParams = params
        // No visible buttons or hints: the helper works by itself. Switch it with the notification.
        try {
            showTouchWatcher()
        } catch (ignored: Exception) {
            // the watcher is optional; the helper still works without it
        }
        autoEnabled = true
        aimEnabled = captureWidth >= 100 && captureHeight >= 100
        updateFloatingButton()
    }


    private fun showAimButton() {
        val wm = windowManager ?: return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val button = Button(this).apply {
            text = "AIM OFF"
            textSize = 11f
            isAllCaps = false
            setPadding(dp(6), dp(1), dp(6), dp(1))
            backgroundTintList = ColorStateList.valueOf(Color.rgb(64, 75, 115))
            setOnTouchListener { view, event -> handleAimButtonTouch(view as Button, event) }
        }
        aimButton = button
        val params = WindowManager.LayoutParams(
            dp(112), dp(44), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(142)
        }
        aimButtonParams = params
        try {
            wm.addView(button, params)
            updateAimButton()
        } catch (ignored: Exception) {
            aimButton = null
            aimButtonParams = null
        }
    }

    private fun handleAimButtonTouch(button: Button, event: MotionEvent): Boolean {
        val params = aimButtonParams ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                aimTouchDownX = event.rawX
                aimTouchDownY = event.rawY
                aimTouchDownWindowX = params.x
                aimTouchDownWindowY = params.y
                aimDraggingButton = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - aimTouchDownX
                val dy = event.rawY - aimTouchDownY
                if (!aimDraggingButton && hypot(dx.toDouble(), dy.toDouble()) > touchSlop) aimDraggingButton = true
                if (aimDraggingButton) {
                    params.x = aimTouchDownWindowX + dx.toInt()
                    params.y = aimTouchDownWindowY + dy.toInt()
                    clampOverlayParams(params)
                    try { windowManager?.updateViewLayout(button, params) } catch (ignored: Exception) { }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!aimDraggingButton) toggleAimAssist()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    private fun toggleAimAssist() {
        settings = DodgeSettings.load(this)
        if (aimPicking) {
            aimPicking = false
            aimEnabled = false
            removeAimPicker()
            hideAimMarker()
            aimEngine.clear()
            Toast.makeText(this, "Aim Assist отменён", Toast.LENGTH_SHORT).show()
        } else if (aimEnabled) {
            aimEnabled = false
            hideAimMarker()
            aimEngine.clear()
            Toast.makeText(this, "Aim Assist OFF", Toast.LENGTH_SHORT).show()
        } else {
            if (captureWidth < 100 || captureHeight < 100) {
                Toast.makeText(this, "Сначала запусти захват экрана", Toast.LENGTH_SHORT).show()
                return
            }
            aimEngine.clear()
            aimEnabled = true
            aimPicking = false
            Toast.makeText(this, "Aim включён: враги находятся сами", Toast.LENGTH_SHORT).show()
        }
        updateAimButton()
    }

    /** Transparent full-screen touch layer used only to select one enemy by tapping it. */
    private fun showAimPicker() {
        removeAimPicker()
        val wm = windowManager ?: return
        val metrics = currentDisplayMetrics()
        val overlay = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN && aimPicking) {
                    val x = event.rawX
                    val y = event.rawY
                    aimEngine.selectTarget(x, y, captureWidth, captureHeight)
                    aimPicking = false
                    aimEnabled = true
                    removeAimPicker()
                    Toast.makeText(this@CaptureService, "Цель выбрана: сопровождаю и упреждаю движение", Toast.LENGTH_SHORT).show()
                    updateAimButton()
                }
                true
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            metrics.widthPixels.coerceAtLeast(1), metrics.heightPixels.coerceAtLeast(1), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
        try {
            wm.addView(overlay, params)
            aimPickerView = overlay
            Toast.makeText(this, "Коснись центра врага на экране", Toast.LENGTH_LONG).show()
        } catch (ignored: Exception) {
            aimEnabled = false
            aimPicking = false
            aimEngine.clear()
            Toast.makeText(this, "Не удалось открыть выбор цели", Toast.LENGTH_SHORT).show()
            updateAimButton()
        }
    }

    private fun removeAimPicker() {
        val picker = aimPickerView ?: return
        try { windowManager?.removeView(picker) } catch (ignored: Exception) { }
        aimPickerView = null
    }

    private fun updateAimButton() {
        updateAllButton()
        val button = aimButton ?: return
        when {
            aimPicking -> {
                button.text = "TAP ENEMY"
                button.backgroundTintList = ColorStateList.valueOf(Color.rgb(165, 100, 35))
                button.contentDescription = "Коснись врага для фиксации цели"
            }
            aimEnabled -> {
                button.text = if (aimEngine.isLocked) "AIM LOCK" else "AIM ON"
                button.backgroundTintList = ColorStateList.valueOf(Color.rgb(42, 93, 145))
                button.contentDescription = if (aimEngine.isLocked) "Aim Assist отслеживает цель" else "Aim Assist включён; цель ещё не захвачена"
            }
            else -> {
                button.text = "AIM OFF"
                button.backgroundTintList = ColorStateList.valueOf(Color.rgb(64, 75, 115))
                button.contentDescription = "Включить автоприцел"
            }
        }
    }

    private fun handleOverlayTouch(button: Button, event: MotionEvent): Boolean {
        val params = overlayParams ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                buttonPressed = true
                draggingButton = false
                longPressTriggered = false
                touchDownRawX = event.rawX
                touchDownRawY = event.rawY
                touchDownWindowX = params.x
                touchDownWindowY = params.y
                mainHandler.removeCallbacks(longPressStop)
                mainHandler.postDelayed(longPressStop, 1050L)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - touchDownRawX
                val dy = event.rawY - touchDownRawY
                if (!draggingButton && hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                    draggingButton = true
                    mainHandler.removeCallbacks(longPressStop)
                }
                if (draggingButton) {
                    params.x = touchDownWindowX + dx.toInt()
                    params.y = touchDownWindowY + dy.toInt()
                    clampOverlayParams(params)
                    try { windowManager?.updateViewLayout(button, params) } catch (ignored: Exception) { }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                buttonPressed = false
                mainHandler.removeCallbacks(longPressStop)
                if (!draggingButton && !longPressTriggered) toggleAuto()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                buttonPressed = false
                mainHandler.removeCallbacks(longPressStop)
                return true
            }
        }
        return true
    }

    private fun toggleAuto() {
        settings = DodgeSettings.load(this)
        autoEnabled = !autoEnabled
        targetWasForeground = false
        visionEngine.reset()
        if (autoEnabled) {
            val touchReady = MansAccessibilityService.current != null
            Toast.makeText(
                this,
                if (touchReady) "Auto-Mans ON: анализирую движущиеся угрозы"
                else "ON включён, но сначала включи Auto-Mans в специальных возможностях",
                Toast.LENGTH_SHORT,
            ).show()
        } else {
            Toast.makeText(this, "Auto-Mans OFF", Toast.LENGTH_SHORT).show()
        }
        updateFloatingButton()
    }

    private fun updateFloatingButton() {
        updateAllButton()
        val button = floatingButton ?: return
        if (autoEnabled) {
            button.text = "MANS ON • ${visionEngine.lastThreatCount}"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(32, 120, 76))
            button.contentDescription = "Auto-Mans включён. ${visionEngine.statusLine()}"
        } else {
            button.text = "MANS OFF"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(55, 58, 65))
            button.contentDescription = "Auto-Mans выключен"
        }
    }

    // ---------- v0.4: aim marker, calibration rings, player-touch watcher ----------
    private var hud: HudView? = null
    private var hudParams: WindowManager.LayoutParams? = null
    private var dotsButton: Button? = null
    private var touchWatcher: View? = null
    private val ringViews = ArrayList<View>()
    private var joyRingParams: WindowManager.LayoutParams? = null
    private var atkRingParams: WindowManager.LayoutParams? = null
    private var ringSizeJoy = 0
    private var ringSizeAtk = 0
    private var ringScreenW = 1
    private var ringScreenH = 1

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun ringView(color: Int): View = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), color)
        }
    }

    private fun ringParams(size: Int, x: Int, y: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val params = WindowManager.LayoutParams(size, size, overlayType(), flags, PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.START
        params.x = x
        params.y = y
        return params
    }

    private fun hideAimMarker() {
        hud?.clearAim()
    }

    /** Full-screen, touch-through layer that draws the green move arrow and the red aim marker. */
    private fun showHud() {
        val wm = windowManager ?: return
        if (hud != null) return
        val metrics = currentDisplayMetrics()
        val view = HudView(this)
        val params = WindowManager.LayoutParams(
            metrics.widthPixels.coerceAtLeast(1), metrics.heightPixels.coerceAtLeast(1), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
        try {
            wm.addView(view, params)
            hud = view
            hudParams = params
        } catch (e: Exception) {
            hud = null
            hudParams = null
        }
    }

    private fun resizeHud() {
        val view = hud ?: return
        val params = hudParams ?: return
        val metrics = currentDisplayMetrics()
        params.width = metrics.widthPixels.coerceAtLeast(1)
        params.height = metrics.heightPixels.coerceAtLeast(1)
        try { windowManager?.updateViewLayout(view, params) } catch (e: Exception) { }
    }

    private fun showDotsButton() {
        val wm = windowManager ?: return
        val button = Button(this).apply {
            text = "DOTS"
            textSize = 11f
            isAllCaps = false
            setPadding(dp(6), dp(1), dp(6), dp(1))
            backgroundTintList = ColorStateList.valueOf(Color.rgb(100, 80, 45))
            setOnClickListener { toggleDots() }
        }
        val params = WindowManager.LayoutParams(
            dp(112), dp(44), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(198)
        }
        try {
            wm.addView(button, params)
            dotsButton = button
        } catch (e: Exception) {
            dotsButton = null
        }
    }

    /** Shows two draggable rings: green = move stick, orange = attack stick. Drop them on the real sticks. */
    private fun toggleDots() {
        if (ringViews.isNotEmpty()) {
            removeRings()
            settings = DodgeSettings.load(this)
            Toast.makeText(this, "Позиции стиков сохранены", Toast.LENGTH_SHORT).show()
            return
        }
        val wm = windowManager ?: return
        settings = DodgeSettings.load(this)
        val metrics = currentDisplayMetrics()
        val w = metrics.widthPixels.coerceAtLeast(1)
        val h = metrics.heightPixels.coerceAtLeast(1)
        ringScreenW = w
        ringScreenH = h
        val minDim = minOf(w, h)
        ringSizeJoy = (minDim * settings.joystickRadiusPct * 2f).toInt().coerceAtLeast(dp(40))
        ringSizeAtk = (minDim * settings.attackRadiusPct * 2f).toInt().coerceAtLeast(dp(40))
        val joyView = ringView(Color.rgb(60, 220, 120))
        val atkView = ringView(Color.rgb(255, 150, 40))
        val joyParams = ringParams(
            ringSizeJoy,
            (w * settings.joystickX).toInt() - ringSizeJoy / 2,
            (h * settings.joystickY).toInt() - ringSizeJoy / 2,
            true,
        )
        val atkParams = ringParams(
            ringSizeAtk,
            (w * settings.attackX).toInt() - ringSizeAtk / 2,
            (h * settings.attackY).toInt() - ringSizeAtk / 2,
            true,
        )
        try {
            wm.addView(joyView, joyParams)
            ringViews.add(joyView)
            wm.addView(atkView, atkParams)
            ringViews.add(atkView)
        } catch (e: Exception) {
            removeRings()
            return
        }
        joyRingParams = joyParams
        atkRingParams = atkParams
        makeDraggable(joyView, joyParams)
        makeDraggable(atkView, atkParams)
        Toast.makeText(this, "Перетащи кольца на свои стики, потом нажми DOTS ещё раз", Toast.LENGTH_LONG).show()
    }

    private fun removeRings() {
        for (v in ringViews) {
            try { windowManager?.removeView(v) } catch (e: Exception) { }
        }
        ringViews.clear()
        joyRingParams = null
        atkRingParams = null
    }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams) {
        var downRawX = 0f
        var downRawY = 0f
        var downX = 0
        var downY = 0
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downX = params.x
                    downY = params.y
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = downX + (event.rawX - downRawX).toInt()
                    params.y = downY + (event.rawY - downRawY).toInt()
                    try { windowManager?.updateViewLayout(view, params) } catch (e: Exception) { }
                }
                MotionEvent.ACTION_UP -> saveRingPositions()
            }
            true
        }
    }

    private fun saveRingPositions() {
        val joy = joyRingParams ?: return
        val atk = atkRingParams ?: return
        val w = ringScreenW.coerceAtLeast(1)
        val h = ringScreenH.coerceAtLeast(1)
        val jx = (joy.x + ringSizeJoy / 2) * 100 / w
        val jy = (joy.y + ringSizeJoy / 2) * 100 / h
        val ax = (atk.x + ringSizeAtk / 2) * 100 / w
        val ay = (atk.y + ringSizeAtk / 2) * 100 / h
        DodgeSettings.saveSticks(this, jx, jy, ax, ay)
    }

    /** 1x1 window that is told when the player touches the screen, so the helper can pause. */
    // ---------- tap an enemy to make him the only target ----------
    private val tapLayers = ArrayList<View>()

    /**
     * Two transparent patches over the empty middle of the field (not over the sticks or buttons).
     * A tap there picks the enemy under the finger; the game itself ignores taps on bare ground.
     */
    private fun startShellTouchIfPossible() {
        if (ShellTouch.ready || !autoEnabled) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastShellTryMs < 6000L) return
        if (!ShizukuBridge.hasPermission()) return
        lastShellTryMs = now
        Thread {
            val status = ShellTouch.start(this)
            if (ShellTouch.ready) {
                mainHandler.post {
                    removeTapLayers()
                    buzz(60L)
                }
            } else {
                if (status != "уже запущено") AimLog.add("ADB не заработал: $status")
            }
        }.start()
    }

    private fun onShellTap(x: Float, y: Float) {
        val s = settings
        val minDim = minOf(captureWidth, captureHeight).toFloat()
        val ax = captureWidth * s.attackX
        val ay = captureHeight * s.attackY
        if (kotlin.math.hypot((x - ax).toDouble(), (y - ay).toDouble()) < minDim * s.attackRadiusPct * 1.6f) return
        val got = aimEngine.pickAt(x, y)
        AimLog.add(if (got == 1) "ВЫБРАЛ врага нажатием (%.0f,%.0f)".format(java.util.Locale.US, x, y) else "нажатие: цель сброшена или рядом нет врага")
        if (got == 1) buzz(45L)
    }

    private fun removeTapLayers() {
        for (v in tapLayers) { try { windowManager?.removeView(v) } catch (ignored: Exception) { } }
        tapLayers.clear()
    }

    private fun showTapLayers() {
        val wm = windowManager ?: return
        val m = currentDisplayMetrics()
        val w = m.widthPixels
        val h = m.heightPixels
        // Right half only: the left half belongs to the floating move stick and must never be covered.
        val rects = arrayOf(
            floatArrayOf(0.52f, 0.06f, 0.80f, 0.56f),
        )
        for (r in rects) {
            val view = View(this)
            var downX = 0f
            var downY = 0f
            var downAt = 0L
            view.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; downAt = SystemClock.elapsedRealtime() }
                    MotionEvent.ACTION_UP -> {
                        val quick = SystemClock.elapsedRealtime() - downAt < 450L
                        if (quick && hypot((e.rawX - downX).toDouble(), (e.rawY - downY).toDouble()) < touchSlop * 2) {
                            val got = aimEngine.pickAt(e.rawX, e.rawY)
                            AimLog.add(if (got == 1) "ВЫБРАЛ врага нажатием (%.0f,%.0f)".format(java.util.Locale.US, e.rawX, e.rawY) else "нажатие: цель сброшена, снова автоматический выбор")
                            buzz(if (got == 1) 45L else 15L)
                        }
                        // a tap to choose a target is not a reason for the helper to wait
                        MansAccessibilityService.lastUserTouchMs = 0L
                    }
                }
                true
            }
            val params = WindowManager.LayoutParams(
                ((r[2] - r[0]) * w).toInt(), ((r[3] - r[1]) * h).toInt(), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = (r[0] * w).toInt()
                y = (r[1] * h).toInt()
            }
            try {
                wm.addView(view, params)
                tapLayers.add(view)
            } catch (ignored: Exception) { }
        }
    }

    private fun buzz(ms: Long) {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
            v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (ignored: Exception) { }
    }

    private fun showTouchWatcher() {
        val wm = windowManager ?: return
        val view = View(this).apply {
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - MansAccessibilityService.lastInjectDownMs > 350L) {
                        MansAccessibilityService.lastUserTouchMs = now
                    }
                }
                false
            }
        }
        val params = WindowManager.LayoutParams(
            1, 1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
        try {
            wm.addView(view, params)
            touchWatcher = view
        } catch (e: Exception) {
            touchWatcher = null
        }
    }

    // ---------- master switch: turn everything off / on with one button ----------
    private var allButton: Button? = null

    private fun anythingOn(): Boolean = autoEnabled || aimEnabled || aimPicking

    private fun showAllButton() {
        val wm = windowManager ?: return
        val button = Button(this).apply {
            textSize = 11f
            isAllCaps = false
            setPadding(dp(6), dp(1), dp(6), dp(1))
            setOnClickListener { toggleAll() }
        }
        val params = WindowManager.LayoutParams(
            dp(112), dp(44), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(254)
        }
        try {
            wm.addView(button, params)
            allButton = button
            updateAllButton()
        } catch (e: Exception) {
            allButton = null
        }
    }

    private var lastNotifOn: Boolean? = null

    private fun refreshNotification() {
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification())
        } catch (e: Exception) { }
    }

    private var autoModeButton: Button? = null

    private fun showAutoButton() {
        val wm = windowManager ?: return
        val button = Button(this).apply {
            textSize = 11f
            isAllCaps = false
            setPadding(dp(6), dp(1), dp(6), dp(1))
            setOnClickListener { toggleAutoMode() }
        }
        val params = WindowManager.LayoutParams(
            dp(112), dp(44), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(310)
        }
        try {
            wm.addView(button, params)
            autoModeButton = button
            updateAutoButton()
        } catch (e: Exception) {
            autoModeButton = null
        }
    }

    private fun updateAutoButton() {
        val button = autoModeButton ?: return
        if (settings.dodgeInject && settings.aimInject) {
            button.text = "АВТО: ВКЛ"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(160, 95, 20))
        } else {
            button.text = "АВТО: ВЫКЛ"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(60, 62, 70))
        }
    }

    /** ON: the helper moves the joystick and fires by itself. OFF: only hints on screen. */
    private fun toggleAutoMode() {
        val current = DodgeSettings.load(this)
        val turnOn = !(current.dodgeInject && current.aimInject)
        DodgeSettings.saveInject(this, turnOn, turnOn)
        settings = DodgeSettings.load(this)
        if (turnOn) {
            if (!autoEnabled) toggleAuto()
            if (!aimEnabled) toggleAimAssist()
        }
        updateAutoButton()
        Toast.makeText(
            this,
            if (turnOn) "АВТО включено: помощник сам уклоняется и стреляет" else "АВТО выключено: только подсказки",
            Toast.LENGTH_SHORT,
        ).show()
    }

    private fun updateAllButton() {
        updateAutoButton()
        val nowOn = anythingOn()
        if (lastNotifOn != nowOn) {
            lastNotifOn = nowOn
            refreshNotification()
        }
        val button = allButton ?: return
        if (anythingOn()) {
            button.text = "ВЫКЛ ВСЁ"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(150, 45, 45))
        } else {
            button.text = "ВКЛ ВСЁ"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(35, 110, 70))
        }
    }

    /** One tap: if anything is running, stop everything; otherwise start MANS and Aim target picking. */
    private fun toggleAll() {
        settings = DodgeSettings.load(this)
        visionEngine.reset()
        targetWasForeground = false
        if (anythingOn()) {
            shellAim.cancel()
            autoDodge.cancel()
            autoEnabled = false
            aimEnabled = false
            aimPicking = false
            removeAimPicker()
            hideAimMarker()
            removeRings()
            aimEngine.clear()
            Toast.makeText(this, "Всё выключено", Toast.LENGTH_SHORT).show()
        } else {
            autoEnabled = true
            if (captureWidth >= 100 && captureHeight >= 100) {
                aimEngine.clear()
                aimEnabled = true
                aimPicking = false
            }
            Toast.makeText(this, "Всё включено: враги находятся сами", Toast.LENGTH_SHORT).show()
        }
        updateFloatingButton()
        updateAimButton()
    }

    private fun clampOverlayToScreen() {
        resizeHud()
        overlayParams?.let { params ->
            clampOverlayParams(params)
            try { floatingButton?.let { windowManager?.updateViewLayout(it, params) } } catch (ignored: Exception) { }
        }
    }

    private fun clampOverlayParams(params: WindowManager.LayoutParams) {
        val metrics = currentDisplayMetrics()
        params.x = params.x.coerceIn(0, (metrics.widthPixels - params.width).coerceAtLeast(0))
        params.y = params.y.coerceIn(0, (metrics.heightPixels - params.height).coerceAtLeast(0))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "Auto-Mans screen capture", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, CaptureService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(
            this, 32, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0),
        )
        val toggleIntent = Intent(this, CaptureService::class.java).setAction(ACTION_TOGGLE_ALL)
        val togglePending = PendingIntent.getService(
            this, 33, toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0),
        )
        val dodgeIntent = Intent(this, CaptureService::class.java).setAction(ACTION_TOGGLE_DODGE)
        val dodgePending = PendingIntent.getService(
            this, 34, dodgeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0),
        )
        val toggleTitle = if (anythingOn()) "Выкл всё" else "Вкл всё"
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Auto-Mans")
            .setContentText("Помощник работает сам • кнопки ниже: выкл/вкл и стоп")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), toggleTitle, togglePending).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_directions), if (settings.autoDodge) "Уклон: выкл" else "Уклон: вкл", dodgePending).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Остановить", pending).build())
            .build()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        scheduleCaptureReconfigure()
    }

    override fun onDestroy() {
        autoEnabled = false
        aimEnabled = false
        aimPicking = false
        targetWasForeground = false
        aimEngine.clear()
        removeAimPicker()
        try { hud?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        hud = null
        hudParams = null
        removeRings()
        try { dotsButton?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        try { allButton?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        allButton = null
        try { autoModeButton?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        autoModeButton = null
        removeTapLayers()
        shellAim.cancel()
        autoDodge.cancel()
        ShellTouch.onTap = null
        ShellTouch.onFinger = null
        ShellTouch.stop()
        try { touchWatcher?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        dotsButton = null
        touchWatcher = null
        mainHandler.removeCallbacks(longPressStop)
        try { displayManager?.unregisterDisplayListener(displayListener) } catch (ignored: Exception) { }
        try { floatingButton?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        try { aimButton?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        floatingButton = null
        aimButton = null
        aimButtonParams = null
        try { display?.setSurface(null) } catch (ignored: Exception) { }
        try { display?.release() } catch (ignored: Exception) { }
        display = null
        try { reader?.setOnImageAvailableListener(null, null) } catch (ignored: Exception) { }
        try { reader?.close() } catch (ignored: Exception) { }
        reader = null
        try { projection?.stop() } catch (ignored: Exception) { }
        projection = null
        visionThread?.quitSafely()
        visionThread = null
        visionHandler = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
