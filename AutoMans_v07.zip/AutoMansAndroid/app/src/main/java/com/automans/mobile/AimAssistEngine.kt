package com.automans.mobile

import android.media.Image
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Experimental screen-space target lock. A user taps the center of an enemy once;
 * this engine then searches a local RGB template, smooths observed motion and leads it.
 * It does not know in-game entity IDs and can lose the lock on similar backgrounds/effects.
 */
data class AimDecision(
    val dx: Float,
    val dy: Float,
    val targetX: Int,
    val targetY: Int,
    val confidence: Float,
    val reason: String,
)

class AimAssistEngine {
    private data class PendingPick(val x: Float, val y: Float, val sourceW: Int, val sourceH: Int)

    private val patchRadius = 5
    private val patchSize = patchRadius * 2 + 1
    private var sourceW = 0
    private var sourceH = 0
    private var gridW = 0
    private var gridH = 0
    private var pixels = IntArray(0)
    private var template: IntArray? = null
    private var pendingPick: PendingPick? = null
    private var locked = false
    private var targetX = 0.0
    private var targetY = 0.0
    private var velocityX = 0.0
    private var velocityY = 0.0
    private var lastTrackMs = 0L
    private var lastProcessedMs = 0L
    private var lostFrames = 0
    @Volatile var lastConfidence: Float = 0f
        private set
    @Volatile var isLocked: Boolean = false
        private set

    @Synchronized fun selectTarget(screenX: Float, screenY: Float, width: Int, height: Int) {
        if (width < 100 || height < 100 || !screenX.isFinite() || !screenY.isFinite()) return
        pendingPick = PendingPick(
            x = screenX.coerceIn(0f, width.toFloat() - 1f) / width,
            y = screenY.coerceIn(0f, height.toFloat() - 1f) / height,
            sourceW = width,
            sourceH = height,
        )
        template = null
        locked = false
        isLocked = false
        velocityX = 0.0
        velocityY = 0.0
        lostFrames = 0
        lastConfidence = 0f
    }

    @Synchronized fun clear() {
        pendingPick = null
        template = null
        locked = false
        isLocked = false
        velocityX = 0.0
        velocityY = 0.0
        lastTrackMs = 0L
        lastProcessedMs = 0L
        lostFrames = 0
        lastConfidence = 0f
        sourceW = 0
        sourceH = 0
        gridW = 0
        gridH = 0
        pixels = IntArray(0)
    }

    /** Returns null for a skipped frame, a calibration frame, or an unreliable target match. */
    @Synchronized fun process(image: Image, nowMs: Long, settings: DodgeSettings): AimDecision? {
        if (nowMs - lastProcessedMs < 105L) return null
        lastProcessedMs = nowMs
        val w = image.width
        val h = image.height
        if (w < 100 || h < 100) return null
        ensureGrid(w, h)
        samplePixels(image)

        val pick = pendingPick
        if (pick != null) {
            // Capture the template in the current frame, accounting for any screen resize.
            val gx = (pick.x * gridW).roundToInt().coerceIn(patchRadius, gridW - patchRadius - 1)
            val gy = (pick.y * gridH).roundToInt().coerceIn(patchRadius, gridH - patchRadius - 1)
            template = cropPatch(gx, gy)
            targetX = gx.toDouble()
            targetY = gy.toDouble()
            velocityX = 0.0
            velocityY = 0.0
            lastTrackMs = nowMs
            pendingPick = null
            locked = true
            isLocked = true
            lostFrames = 0
            lastConfidence = 1f
            return null
        }
        if (!locked || template == null) return null
        if (w != sourceW || h != sourceH) {
            // Rotation/geometry changes invalidate the patch; ask for a fresh target tap.
            locked = false
            isLocked = false
            template = null
            lastConfidence = 0f
            return null
        }

        val prevX = targetX
        val prevY = targetY
        val match = findBestMatch(targetX.roundToInt(), targetY.roundToInt())
        if (match == null || match.third > 83.0) {
            lostFrames++
            lastConfidence = 0f
            if (lostFrames >= 4) {
                locked = false
                isLocked = false
                template = null
            }
            return null
        }

        lostFrames = 0
        val newX = match.first.toDouble()
        val newY = match.second.toDouble()
        val dt = ((nowMs - lastTrackMs).coerceIn(60L, 450L)) / 1000.0
        val measuredVx = ((newX - prevX) / dt).coerceIn(-gridW * 1.2, gridW * 1.2)
        val measuredVy = ((newY - prevY) / dt).coerceIn(-gridH * 1.2, gridH * 1.2)
        velocityX = velocityX * 0.48 + measuredVx * 0.52
        velocityY = velocityY * 0.48 + measuredVy * 0.52
        targetX = newX
        targetY = newY
        lastTrackMs = nowMs

        // Moderate lead predicts travel during attack input latency; clamp to avoid wild jumps.
        val leadSeconds = 0.19
        val leadX = (targetX + velocityX * leadSeconds).coerceIn(patchRadius.toDouble(), (gridW - patchRadius - 1).toDouble())
        val leadY = (targetY + velocityY * leadSeconds).coerceIn(patchRadius.toDouble(), (gridH - patchRadius - 1).toDouble())
        val screenTargetX = (leadX * w / gridW).roundToInt().coerceIn(0, w - 1)
        val screenTargetY = (leadY * h / gridH).roundToInt().coerceIn(0, h - 1)
        val playerX = settings.playerX.coerceIn(0.05f, 0.95f) * w
        val playerY = settings.playerY.coerceIn(0.05f, 0.95f) * h
        val diffX = screenTargetX - playerX
        val diffY = screenTargetY - playerY
        val length = hypot(diffX.toDouble(), diffY.toDouble())
        if (!length.isFinite() || length < 1.0) return null
        val confidence = (1.0 - match.third / 110.0).coerceIn(0.0, 1.0).toFloat()
        lastConfidence = confidence
        isLocked = confidence >= 0.20f
        if (!isLocked) return null
        return AimDecision(
            dx = (diffX / length).toFloat(),
            dy = (diffY / length).toFloat(),
            targetX = screenTargetX,
            targetY = screenTargetY,
            confidence = confidence,
            reason = "цель отслеживается; упреждение 190 мс",
        )
    }

    private fun ensureGrid(w: Int, h: Int) {
        if (w == sourceW && h == sourceH && gridW > 0 && gridH > 0) return
        sourceW = w
        sourceH = h
        val scale = max(1.0, max(w, h).toDouble() / 420.0)
        gridW = max(1, (w / scale).toInt())
        gridH = max(1, (h / scale).toInt())
        pixels = IntArray(gridW * gridH)
        template = null
        locked = false
        isLocked = false
        // Keep a queued tap in normalized screen coordinates if this is the first frame
        // or a resize happened immediately before the target-selection tap.
    }

    private fun samplePixels(image: Image) {
        val plane = image.planes.firstOrNull() ?: return
        val buffer: ByteBuffer = plane.buffer
        val base = buffer.position()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        var out = 0
        for (gy in 0 until gridH) {
            val sy = ((gy + 0.5) * sourceH / gridH).toInt().coerceIn(0, sourceH - 1)
            val row = sy * rowStride
            for (gx in 0 until gridW) {
                val sx = ((gx + 0.5) * sourceW / gridW).toInt().coerceIn(0, sourceW - 1)
                val index = base + row + sx * pixelStride
                if (index < base || index + 2 >= buffer.limit()) pixels[out++] = 0
                else {
                    val r = buffer.get(index).toInt() and 0xff
                    val g = buffer.get(index + 1).toInt() and 0xff
                    val b = buffer.get(index + 2).toInt() and 0xff
                    pixels[out++] = (r shl 16) or (g shl 8) or b
                }
            }
        }
    }

    private fun cropPatch(cx: Int, cy: Int): IntArray {
        val result = IntArray(patchSize * patchSize)
        var p = 0
        for (y in cy - patchRadius..cy + patchRadius) {
            for (x in cx - patchRadius..cx + patchRadius) result[p++] = pixels[y * gridW + x]
        }
        return result
    }

    /** Color-normalized patch SAD makes matching less sensitive to small brightness changes. */
    private fun findBestMatch(cx: Int, cy: Int): Triple<Int, Int, Double>? {
        val ref = template ?: return null
        val rx = min(gridW / 4, max(15, (min(gridW, gridH) * 0.22).roundToInt()))
        val ry = min(gridH / 3, max(12, (min(gridW, gridH) * 0.22).roundToInt()))
        val minX = (cx - rx).coerceIn(patchRadius, gridW - patchRadius - 1)
        val maxX = (cx + rx).coerceIn(patchRadius, gridW - patchRadius - 1)
        val minY = (cy - ry).coerceIn(patchRadius, gridH - patchRadius - 1)
        val maxY = (cy + ry).coerceIn(patchRadius, gridH - patchRadius - 1)
        var bestX = -1
        var bestY = -1
        var bestScore = Double.MAX_VALUE
        var y = minY
        while (y <= maxY) {
            var x = minX
            while (x <= maxX) {
                val score = patchScore(ref, x, y)
                if (score < bestScore) {
                    bestScore = score
                    bestX = x
                    bestY = y
                }
                x += 2
            }
            y += 2
        }
        if (bestX < 0) return null
        return Triple(bestX, bestY, bestScore)
    }

    private fun patchScore(ref: IntArray, cx: Int, cy: Int): Double {
        // Compute each patch's mean RGB first so the score tolerates mild lighting/flash changes.
        var rr = 0.0; var rg = 0.0; var rb = 0.0
        var cr = 0.0; var cg = 0.0; var cb = 0.0
        var i = 0
        for (y in cy - patchRadius..cy + patchRadius) for (x in cx - patchRadius..cx + patchRadius) {
            val c = pixels[y * gridW + x]
            val r = ((c shr 16) and 255).toDouble()
            val g = ((c shr 8) and 255).toDouble()
            val b = (c and 255).toDouble()
            cr += r; cg += g; cb += b
            val t = ref[i++]
            rr += ((t shr 16) and 255).toDouble()
            rg += ((t shr 8) and 255).toDouble()
            rb += (t and 255).toDouble()
        }
        val count = ref.size.toDouble()
        val offR = cr / count - rr / count
        val offG = cg / count - rg / count
        val offB = cb / count - rb / count
        i = 0
        var score = 0.0
        for (y in cy - patchRadius..cy + patchRadius) for (x in cx - patchRadius..cx + patchRadius) {
            val c = pixels[y * gridW + x]
            val t = ref[i++]
            score += abs(((c shr 16) and 255) - ((t shr 16) and 255) - offR)
            score += abs(((c shr 8) and 255) - ((t shr 8) and 255) - offG)
            score += abs((c and 255) - (t and 255) - offB)
        }
        return score / (count * 3.0)
    }
}
