package com.automans.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import android.content.res.ColorStateList
import android.content.pm.ServiceInfo
import kotlin.math.hypot

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_STOP = "com.automans.mobile.STOP_CAPTURE"
        const val ACTION_TOGGLE_ALL = "com.automans.mobile.TOGGLE_ALL"
        private const val CHANNEL = "automans_capture"
        private const val NOTIFICATION_ID = 31
        @Volatile var autoEnabled: Boolean = false
    }

    private var projection: MediaProjection? = null
    @Volatile private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var windowManager: WindowManager? = null
    private var displayManager: DisplayManager? = null
    private var floatingButton: Button? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var aimButton: Button? = null
    private var aimButtonParams: WindowManager.LayoutParams? = null
    private var aimPickerView: View? = null
    @Volatile private var aimEnabled = false
    @Volatile private var aimPicking = false
    private val aimEngine = AimAssistEngine()
    private var lastAimGestureMs = 0L
    private var aimTouchDownX = 0f
    private var aimTouchDownY = 0f
    private var aimTouchDownWindowX = 0
    private var aimTouchDownWindowY = 0
    private var aimDraggingButton = false
    private var visionThread: HandlerThread? = null
    private var visionHandler: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val visionEngine = VisionDodgeEngine()
    private var settings = DodgeSettings()
    @Volatile private var captureWidth = 0
    @Volatile private var captureHeight = 0
    private var lastUiUpdateMs = 0L
    @Volatile private var targetWasForeground = false
    private var touchDownRawX = 0f
    private var touchDownRawY = 0f
    private var touchDownWindowX = 0
    private var touchDownWindowY = 0
    private var draggingButton = false
    private var buttonPressed = false
    private var longPressTriggered = false
    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    private val longPressStop = Runnable {
        if (buttonPressed && !draggingButton) {
            longPressTriggered = true
            autoEnabled = false
            Toast.makeText(this, "Auto-Mans остановлен", Toast.LENGTH_SHORT).show()
            stopSelf()
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) scheduleCaptureReconfigure()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            autoEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_TOGGLE_ALL) {
            // Button in the notification shade: switch everything off / on.
            if (projection != null) mainHandler.post { toggleAll() }
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION,
            )
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null || resultCode == 0) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            settings = DodgeSettings.load(this)
            visionThread = HandlerThread("AutoMansVision").also { it.start() }
            visionHandler = Handler(visionThread!!.looper)
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    mainHandler.post { stopSelf() }
                }
            }, mainHandler)
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            displayManager = getSystemService(DISPLAY_SERVICE) as DisplayManager
            displayManager?.registerDisplayListener(displayListener, mainHandler)
            configureCapture(force = true)
            showFloatingButton()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить захват: ${e.message ?: "ошибка Android"}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun scheduleCaptureReconfigure() {
        mainHandler.postDelayed({
            try {
                configureCapture(force = false)
            } catch (ignored: Exception) {
                // Rotation can briefly report stale display metrics. Retry once after layout settles.
                mainHandler.postDelayed({
                    try { configureCapture(force = false) } catch (ignored: Exception) { /* next display event may retry */ }
                }, 420L)
            }
        }, 260L)
    }

    private fun configureCapture(force: Boolean) {
        val metrics = currentDisplayMetrics()
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        if (!force && width == captureWidth && height == captureHeight) return
        val handler = visionHandler ?: return
        val newReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        newReader.setOnImageAvailableListener({ source -> onImageAvailable(source) }, handler)
        val oldReader = reader

        try {
            val densityDpi = metrics.densityDpi.coerceAtLeast(1)
            val currentDisplay = display
            if (currentDisplay == null) {
                val currentProjection = projection ?: throw IllegalStateException("MediaProjection не запущен")
                val created = currentProjection.createVirtualDisplay(
                    "AutoMansScreen",
                    width,
                    height,
                    densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    newReader.surface,
                    null,
                    mainHandler,
                ) ?: throw IllegalStateException("Android не создал виртуальный экран")
                display = created
            } else {
                currentDisplay.resize(width, height, densityDpi)
                currentDisplay.surface = newReader.surface
            }
        } catch (e: Exception) {
            newReader.setOnImageAvailableListener(null, null)
            try { newReader.close() } catch (ignored: Exception) { }
            throw e
        }

        // Publish the new reader only after the VirtualDisplay accepts its surface.
        reader = newReader
        oldReader?.setOnImageAvailableListener(null, null)
        try { oldReader?.close() } catch (ignored: Exception) { }
        visionEngine.reset()
        captureWidth = width
        captureHeight = height
        clampOverlayToScreen()
    }

    private fun currentDisplayMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        val wm = windowManager ?: (getSystemService(WINDOW_SERVICE) as WindowManager)
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        if (metrics.widthPixels <= 0 || metrics.heightPixels <= 0) {
            val fallback = resources.displayMetrics
            metrics.setTo(fallback)
        }
        return metrics
    }

    private fun onImageAvailable(source: ImageReader) {
        if (source !== reader) {
            try { source.acquireLatestImage()?.close() } catch (ignored: Exception) { }
            return
        }
        var image: Image? = null
        try {
            image = source.acquireLatestImage() ?: return
            val controls = MansAccessibilityService.current
            val gameForeground = (autoEnabled || aimEnabled) && controls?.isLikelyBrawlForeground() == true
            if (gameForeground) {
                if (!targetWasForeground) visionEngine.reset()
                targetWasForeground = true
                val nowMs = SystemClock.elapsedRealtime()
                val dodgeDecision = if (autoEnabled) visionEngine.process(image, nowMs, settings) else null
                val aimDecision = if (aimEnabled) aimEngine.process(image, nowMs, settings) else null

                // Aim marker: always shown while the target is tracked, even if Aim does not press.
                if (aimDecision != null) {
                    val markerX = aimDecision.targetX
                    val markerY = aimDecision.targetY
                    val fx = settings.playerX
                    val fy = settings.playerY
                    mainHandler.post { hud?.setAim(markerX.toFloat(), markerY.toFloat(), fx, fy) }
                }

                // Survival has priority. Do not inject an attack swipe while a dodge is required.
                if (dodgeDecision != null && dodgeDecision.shouldDodge) {
                    val arrowX = dodgeDecision.dx
                    val arrowY = dodgeDecision.dy
                    val fx = settings.playerX
                    val fy = settings.playerY
                    mainHandler.post { hud?.setDodge(arrowX, arrowY, fx, fy) }
                    if (settings.dodgeInject) {
                        controls?.dispatchDodge(
                            dodgeDecision.dx,
                            dodgeDecision.dy,
                            captureWidth,
                            captureHeight,
                            settings,
                        )
                    }
                } else if (settings.aimInject && aimDecision != null && aimDecision.confidence >= 0.24f && nowMs - lastAimGestureMs >= 520L) {
                    controls?.dispatchAim(
                        aimDecision.dx,
                        aimDecision.dy,
                        captureWidth,
                        captureHeight,
                        settings,
                    )
                    lastAimGestureMs = nowMs
                }
            } else {
                if (targetWasForeground) visionEngine.reset()
                targetWasForeground = false
            }
            val now = SystemClock.elapsedRealtime()
            if (now - lastUiUpdateMs >= 500L) {
                lastUiUpdateMs = now
                mainHandler.post {
                    updateFloatingButton()
                    updateAimButton()
                }
            }
        } catch (ignored: IllegalStateException) {
            // ImageReader may be closing during a display rotation.
        } catch (ignored: Exception) {
            // Keep a single damaged frame from stopping the screen pipeline.
        } finally {
            try { image?.close() } catch (ignored: Exception) { }
        }
    }

    private fun showFloatingButton() {
        val wm = windowManager ?: return
        val button = Button(this).apply {
            text = "MANS OFF"
            textSize = 12f
            isAllCaps = false
            setPadding(dp(8), dp(2), dp(8), dp(2))
            backgroundTintList = ColorStateList.valueOf(Color.rgb(55, 58, 65))
            setOnTouchListener { view, event -> handleOverlayTouch(view as Button, event) }
        }
        floatingButton = button
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            dp(138), dp(50), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(86)
        }
        overlayParams = params
        showHud()
        try {
            wm.addView(button, params)
            updateFloatingButton()
            showAimButton()
            showDotsButton()
            showAllButton()
            showTouchWatcher()
        } catch (ignored: Exception) {
            stopSelf()
        }
    }


    private fun showAimButton() {
        val wm = windowManager ?: return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val button = Button(this).apply {
            text = "AIM PICK"
            textSize = 11f
            isAllCaps = false
            setPadding(dp(6), dp(1), dp(6), dp(1))
            backgroundTintList = ColorStateList.valueOf(Color.rgb(64, 75, 115))
            setOnTouchListener { view, event -> handleAimButtonTouch(view as Button, event) }
        }
        aimButton = button
        val params = WindowManager.LayoutParams(
            dp(112), dp(44), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(142)
        }
        aimButtonParams = params
        try {
            wm.addView(button, params)
            updateAimButton()
        } catch (ignored: Exception) {
            aimButton = null
            aimButtonParams = null
        }
    }

    private fun handleAimButtonTouch(button: Button, event: MotionEvent): Boolean {
        val params = aimButtonParams ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                aimTouchDownX = event.rawX
                aimTouchDownY = event.rawY
                aimTouchDownWindowX = params.x
                aimTouchDownWindowY = params.y
                aimDraggingButton = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - aimTouchDownX
                val dy = event.rawY - aimTouchDownY
                if (!aimDraggingButton && hypot(dx.toDouble(), dy.toDouble()) > touchSlop) aimDraggingButton = true
                if (aimDraggingButton) {
                    params.x = aimTouchDownWindowX + dx.toInt()
                    params.y = aimTouchDownWindowY + dy.toInt()
                    clampOverlayParams(params)
                    try { windowManager?.updateViewLayout(button, params) } catch (ignored: Exception) { }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!aimDraggingButton) toggleAimAssist()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    private fun toggleAimAssist() {
        settings = DodgeSettings.load(this)
        if (aimPicking) {
            aimPicking = false
            aimEnabled = false
            removeAimPicker()
            hideAimMarker()
            aimEngine.clear()
            Toast.makeText(this, "Aim Assist отменён", Toast.LENGTH_SHORT).show()
        } else if (aimEnabled) {
            aimEnabled = false
            hideAimMarker()
            aimEngine.clear()
            Toast.makeText(this, "Aim Assist OFF", Toast.LENGTH_SHORT).show()
        } else {
            if (captureWidth < 100 || captureHeight < 100) {
                Toast.makeText(this, "Сначала запусти захват экрана", Toast.LENGTH_SHORT).show()
                return
            }
            aimEngine.clear()
            aimEnabled = true
            aimPicking = true
            showAimPicker()
        }
        updateAimButton()
    }

    /** Transparent full-screen touch layer used only to select one enemy by tapping it. */
    private fun showAimPicker() {
        removeAimPicker()
        val wm = windowManager ?: return
        val metrics = currentDisplayMetrics()
        val overlay = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN && aimPicking) {
                    val x = event.rawX
                    val y = event.rawY
                    aimEngine.selectTarget(x, y, captureWidth, captureHeight)
                    aimPicking = false
                    aimEnabled = true
                    removeAimPicker()
                    Toast.makeText(this@CaptureService, "Цель выбрана: сопровождаю и упреждаю движение", Toast.LENGTH_SHORT).show()
                    updateAimButton()
                }
                true
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            metrics.widthPixels.coerceAtLeast(1), metrics.heightPixels.coerceAtLeast(1), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
        try {
            wm.addView(overlay, params)
            aimPickerView = overlay
            Toast.makeText(this, "Коснись центра врага на экране", Toast.LENGTH_LONG).show()
        } catch (ignored: Exception) {
            aimEnabled = false
            aimPicking = false
            aimEngine.clear()
            Toast.makeText(this, "Не удалось открыть выбор цели", Toast.LENGTH_SHORT).show()
            updateAimButton()
        }
    }

    private fun removeAimPicker() {
        val picker = aimPickerView ?: return
        try { windowManager?.removeView(picker) } catch (ignored: Exception) { }
        aimPickerView = null
    }

    private fun updateAimButton() {
        updateAllButton()
        val button = aimButton ?: return
        when {
            aimPicking -> {
                button.text = "TAP ENEMY"
                button.backgroundTintList = ColorStateList.valueOf(Color.rgb(165, 100, 35))
                button.contentDescription = "Коснись врага для фиксации цели"
            }
            aimEnabled -> {
                button.text = if (aimEngine.isLocked) "AIM LOCK" else "AIM ON"
                button.backgroundTintList = ColorStateList.valueOf(Color.rgb(42, 93, 145))
                button.contentDescription = if (aimEngine.isLocked) "Aim Assist отслеживает цель" else "Aim Assist включён; цель ещё не захвачена"
            }
            else -> {
                button.text = "AIM PICK"
                button.backgroundTintList = ColorStateList.valueOf(Color.rgb(64, 75, 115))
                button.contentDescription = "Выбрать цель для Aim Assist"
            }
        }
    }

    private fun handleOverlayTouch(button: Button, event: MotionEvent): Boolean {
        val params = overlayParams ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                buttonPressed = true
                draggingButton = false
                longPressTriggered = false
                touchDownRawX = event.rawX
                touchDownRawY = event.rawY
                touchDownWindowX = params.x
                touchDownWindowY = params.y
                mainHandler.removeCallbacks(longPressStop)
                mainHandler.postDelayed(longPressStop, 1050L)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - touchDownRawX
                val dy = event.rawY - touchDownRawY
                if (!draggingButton && hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                    draggingButton = true
                    mainHandler.removeCallbacks(longPressStop)
                }
                if (draggingButton) {
                    params.x = touchDownWindowX + dx.toInt()
                    params.y = touchDownWindowY + dy.toInt()
                    clampOverlayParams(params)
                    try { windowManager?.updateViewLayout(button, params) } catch (ignored: Exception) { }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                buttonPressed = false
                mainHandler.removeCallbacks(longPressStop)
                if (!draggingButton && !longPressTriggered) toggleAuto()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                buttonPressed = false
                mainHandler.removeCallbacks(longPressStop)
                return true
            }
        }
        return true
    }

    private fun toggleAuto() {
        settings = DodgeSettings.load(this)
        autoEnabled = !autoEnabled
        targetWasForeground = false
        visionEngine.reset()
        if (autoEnabled) {
            val touchReady = MansAccessibilityService.current != null
            Toast.makeText(
                this,
                if (touchReady) "Auto-Mans ON: анализирую движущиеся угрозы"
                else "ON включён, но сначала включи Auto-Mans в специальных возможностях",
                Toast.LENGTH_SHORT,
            ).show()
        } else {
            Toast.makeText(this, "Auto-Mans OFF", Toast.LENGTH_SHORT).show()
        }
        updateFloatingButton()
    }

    private fun updateFloatingButton() {
        updateAllButton()
        val button = floatingButton ?: return
        if (autoEnabled) {
            button.text = "MANS ON • ${visionEngine.lastThreatCount}"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(32, 120, 76))
            button.contentDescription = "Auto-Mans включён. ${visionEngine.statusLine()}"
        } else {
            button.text = "MANS OFF"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(55, 58, 65))
            button.contentDescription = "Auto-Mans выключен"
        }
    }

    // ---------- v0.4: aim marker, calibration rings, player-touch watcher ----------
    private var hud: HudView? = null
    private var hudParams: WindowManager.LayoutParams? = null
    private var dotsButton: Button? = null
    private var touchWatcher: View? = null
    private val ringViews = ArrayList<View>()
    private var joyRingParams: WindowManager.LayoutParams? = null
    private var atkRingParams: WindowManager.LayoutParams? = null
    private var ringSizeJoy = 0
    private var ringSizeAtk = 0
    private var ringScreenW = 1
    private var ringScreenH = 1

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun ringView(color: Int): View = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), color)
        }
    }

    private fun ringParams(size: Int, x: Int, y: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val params = WindowManager.LayoutParams(size, size, overlayType(), flags, PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.START
        params.x = x
        params.y = y
        return params
    }

    private fun hideAimMarker() {
        hud?.clearAim()
    }

    /** Full-screen, touch-through layer that draws the green move arrow and the red aim marker. */
    private fun showHud() {
        val wm = windowManager ?: return
        if (hud != null) return
        val metrics = currentDisplayMetrics()
        val view = HudView(this)
        val params = WindowManager.LayoutParams(
            metrics.widthPixels.coerceAtLeast(1), metrics.heightPixels.coerceAtLeast(1), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
        try {
            wm.addView(view, params)
            hud = view
            hudParams = params
        } catch (e: Exception) {
            hud = null
            hudParams = null
        }
    }

    private fun resizeHud() {
        val view = hud ?: return
        val params = hudParams ?: return
        val metrics = currentDisplayMetrics()
        params.width = metrics.widthPixels.coerceAtLeast(1)
        params.height = metrics.heightPixels.coerceAtLeast(1)
        try { windowManager?.updateViewLayout(view, params) } catch (e: Exception) { }
    }

    private fun showDotsButton() {
        val wm = windowManager ?: return
        val button = Button(this).apply {
            text = "DOTS"
            textSize = 11f
            isAllCaps = false
            setPadding(dp(6), dp(1), dp(6), dp(1))
            backgroundTintList = ColorStateList.valueOf(Color.rgb(100, 80, 45))
            setOnClickListener { toggleDots() }
        }
        val params = WindowManager.LayoutParams(
            dp(112), dp(44), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(198)
        }
        try {
            wm.addView(button, params)
            dotsButton = button
        } catch (e: Exception) {
            dotsButton = null
        }
    }

    /** Shows two draggable rings: green = move stick, orange = attack stick. Drop them on the real sticks. */
    private fun toggleDots() {
        if (ringViews.isNotEmpty()) {
            removeRings()
            settings = DodgeSettings.load(this)
            Toast.makeText(this, "Позиции стиков сохранены", Toast.LENGTH_SHORT).show()
            return
        }
        val wm = windowManager ?: return
        settings = DodgeSettings.load(this)
        val metrics = currentDisplayMetrics()
        val w = metrics.widthPixels.coerceAtLeast(1)
        val h = metrics.heightPixels.coerceAtLeast(1)
        ringScreenW = w
        ringScreenH = h
        val minDim = minOf(w, h)
        ringSizeJoy = (minDim * settings.joystickRadiusPct * 2f).toInt().coerceAtLeast(dp(40))
        ringSizeAtk = (minDim * settings.attackRadiusPct * 2f).toInt().coerceAtLeast(dp(40))
        val joyView = ringView(Color.rgb(60, 220, 120))
        val atkView = ringView(Color.rgb(255, 150, 40))
        val joyParams = ringParams(
            ringSizeJoy,
            (w * settings.joystickX).toInt() - ringSizeJoy / 2,
            (h * settings.joystickY).toInt() - ringSizeJoy / 2,
            true,
        )
        val atkParams = ringParams(
            ringSizeAtk,
            (w * settings.attackX).toInt() - ringSizeAtk / 2,
            (h * settings.attackY).toInt() - ringSizeAtk / 2,
            true,
        )
        try {
            wm.addView(joyView, joyParams)
            ringViews.add(joyView)
            wm.addView(atkView, atkParams)
            ringViews.add(atkView)
        } catch (e: Exception) {
            removeRings()
            return
        }
        joyRingParams = joyParams
        atkRingParams = atkParams
        makeDraggable(joyView, joyParams)
        makeDraggable(atkView, atkParams)
        Toast.makeText(this, "Перетащи кольца на свои стики, потом нажми DOTS ещё раз", Toast.LENGTH_LONG).show()
    }

    private fun removeRings() {
        for (v in ringViews) {
            try { windowManager?.removeView(v) } catch (e: Exception) { }
        }
        ringViews.clear()
        joyRingParams = null
        atkRingParams = null
    }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams) {
        var downRawX = 0f
        var downRawY = 0f
        var downX = 0
        var downY = 0
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downX = params.x
                    downY = params.y
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = downX + (event.rawX - downRawX).toInt()
                    params.y = downY + (event.rawY - downRawY).toInt()
                    try { windowManager?.updateViewLayout(view, params) } catch (e: Exception) { }
                }
                MotionEvent.ACTION_UP -> saveRingPositions()
            }
            true
        }
    }

    private fun saveRingPositions() {
        val joy = joyRingParams ?: return
        val atk = atkRingParams ?: return
        val w = ringScreenW.coerceAtLeast(1)
        val h = ringScreenH.coerceAtLeast(1)
        val jx = (joy.x + ringSizeJoy / 2) * 100 / w
        val jy = (joy.y + ringSizeJoy / 2) * 100 / h
        val ax = (atk.x + ringSizeAtk / 2) * 100 / w
        val ay = (atk.y + ringSizeAtk / 2) * 100 / h
        DodgeSettings.saveSticks(this, jx, jy, ax, ay)
    }

    /** 1x1 window that is told when the player touches the screen, so the helper can pause. */
    private fun showTouchWatcher() {
        val wm = windowManager ?: return
        val view = View(this).apply {
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - MansAccessibilityService.lastInjectMs > 450L) {
                        MansAccessibilityService.lastUserTouchMs = now
                    }
                }
                false
            }
        }
        val params = WindowManager.LayoutParams(
            1, 1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
        try {
            wm.addView(view, params)
            touchWatcher = view
        } catch (e: Exception) {
            touchWatcher = null
        }
    }

    // ---------- master switch: turn everything off / on with one button ----------
    private var allButton: Button? = null

    private fun anythingOn(): Boolean = autoEnabled || aimEnabled || aimPicking

    private fun showAllButton() {
        val wm = windowManager ?: return
        val button = Button(this).apply {
            textSize = 11f
            isAllCaps = false
            setPadding(dp(6), dp(1), dp(6), dp(1))
            setOnClickListener { toggleAll() }
        }
        val params = WindowManager.LayoutParams(
            dp(112), dp(44), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(254)
        }
        try {
            wm.addView(button, params)
            allButton = button
            updateAllButton()
        } catch (e: Exception) {
            allButton = null
        }
    }

    private var lastNotifOn: Boolean? = null

    private fun refreshNotification() {
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification())
        } catch (e: Exception) { }
    }

    private fun updateAllButton() {
        val nowOn = anythingOn()
        if (lastNotifOn != nowOn) {
            lastNotifOn = nowOn
            refreshNotification()
        }
        val button = allButton ?: return
        if (anythingOn()) {
            button.text = "ВЫКЛ ВСЁ"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(150, 45, 45))
        } else {
            button.text = "ВКЛ ВСЁ"
            button.backgroundTintList = ColorStateList.valueOf(Color.rgb(35, 110, 70))
        }
    }

    /** One tap: if anything is running, stop everything; otherwise start MANS and Aim target picking. */
    private fun toggleAll() {
        settings = DodgeSettings.load(this)
        visionEngine.reset()
        targetWasForeground = false
        if (anythingOn()) {
            autoEnabled = false
            aimEnabled = false
            aimPicking = false
            removeAimPicker()
            hideAimMarker()
            removeRings()
            aimEngine.clear()
            Toast.makeText(this, "Всё выключено", Toast.LENGTH_SHORT).show()
        } else {
            autoEnabled = true
            if (captureWidth >= 100 && captureHeight >= 100) {
                aimEngine.clear()
                aimEnabled = true
                aimPicking = true
                showAimPicker()
            }
            Toast.makeText(this, "Всё включено: коснись врага для прицела", Toast.LENGTH_SHORT).show()
        }
        updateFloatingButton()
        updateAimButton()
    }

    private fun clampOverlayToScreen() {
        resizeHud()
        overlayParams?.let { params ->
            clampOverlayParams(params)
            try { floatingButton?.let { windowManager?.updateViewLayout(it, params) } } catch (ignored: Exception) { }
        }
    }

    private fun clampOverlayParams(params: WindowManager.LayoutParams) {
        val metrics = currentDisplayMetrics()
        params.x = params.x.coerceIn(0, (metrics.widthPixels - params.width).coerceAtLeast(0))
        params.y = params.y.coerceIn(0, (metrics.heightPixels - params.height).coerceAtLeast(0))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "Auto-Mans screen capture", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, CaptureService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(
            this, 32, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0),
        )
        val toggleIntent = Intent(this, CaptureService::class.java).setAction(ACTION_TOGGLE_ALL)
        val togglePending = PendingIntent.getService(
            this, 33, toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0),
        )
        val toggleTitle = if (anythingOn()) "Выкл всё" else "Вкл всё"
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Auto-Mans")
            .setContentText("Захват экрана активен • удерживай кнопку для остановки")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), toggleTitle, togglePending).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Остановить", pending).build())
            .build()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        scheduleCaptureReconfigure()
    }

    override fun onDestroy() {
        autoEnabled = false
        aimEnabled = false
        aimPicking = false
        targetWasForeground = false
        aimEngine.clear()
        removeAimPicker()
        try { hud?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        hud = null
        hudParams = null
        removeRings()
        try { dotsButton?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        try { allButton?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        allButton = null
        try { touchWatcher?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        dotsButton = null
        touchWatcher = null
        mainHandler.removeCallbacks(longPressStop)
        try { displayManager?.unregisterDisplayListener(displayListener) } catch (ignored: Exception) { }
        try { floatingButton?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        try { aimButton?.let { windowManager?.removeView(it) } } catch (ignored: Exception) { }
        floatingButton = null
        aimButton = null
        aimButtonParams = null
        try { display?.setSurface(null) } catch (ignored: Exception) { }
        try { display?.release() } catch (ignored: Exception) { }
        display = null
        try { reader?.setOnImageAvailableListener(null, null) } catch (ignored: Exception) { }
        try { reader?.close() } catch (ignored: Exception) { }
        reader = null
        try { projection?.stop() } catch (ignored: Exception) { }
        projection = null
        visionThread?.quitSafely()
        visionThread = null
        visionHandler = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
