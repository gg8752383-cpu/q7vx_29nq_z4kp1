package com.automans.mobile

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.view.View
import kotlin.math.min

/**
 * Touch-through drawing layer shown above the game.
 * Green arrow from the fighter = "move this way". Red ring + dashed line = "aim here".
 * Everything fades by itself when the helper stops updating it.
 */
class HudView(context: Context) : View(context) {
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val dash = DashPathEffect(floatArrayOf(28f, 20f), 0f)

    private var dodgeDx = 0f
    private var dodgeDy = 0f
    private var dodgeAt = 0L
    private var aimX = 0f
    private var aimY = 0f
    private var aimAt = 0L
    private var playerFx = 0.5f
    private var playerFy = 0.5f

    fun setDodge(dx: Float, dy: Float, playerX: Float, playerY: Float) {
        dodgeDx = dx
        dodgeDy = dy
        dodgeAt = SystemClock.uptimeMillis()
        playerFx = playerX
        playerFy = playerY
        invalidate()
    }

    fun setAim(x: Float, y: Float, playerX: Float, playerY: Float) {
        aimX = x
        aimY = y
        aimAt = SystemClock.uptimeMillis()
        playerFx = playerX
        playerFy = playerY
        invalidate()
    }

    fun clearAim() {
        aimAt = 0L
        invalidate()
    }

    fun clearAll() {
        aimAt = 0L
        dodgeAt = 0L
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val w = width.toFloat()
        val h = height.toFloat()
        if (w < 10f || h < 10f) return
        val minDim = min(w, h)
        val px = playerFx * w
        val py = playerFy * h
        var active = false

        val aimAge = now - aimAt
        if (aimAt != 0L && aimAge in 0L..650L) {
            active = true
            val alpha = fade(aimAge, 650L)
            drawAim(canvas, px, py, aimX, aimY, minDim, alpha)
        }

        val dodgeAge = now - dodgeAt
        if (dodgeAt != 0L && dodgeAge in 0L..420L) {
            active = true
            val alpha = fade(dodgeAge, 420L)
            drawArrow(canvas, px, py, dodgeDx, dodgeDy, minDim, alpha)
        }

        if (active) postInvalidateDelayed(70L)
    }

    private fun fade(age: Long, life: Long): Int {
        val left = 1f - age.toFloat() / life.toFloat()
        return (255f * left.coerceIn(0.25f, 1f)).toInt()
    }

    private fun drawArrow(canvas: Canvas, sx0: Float, sy0: Float, dx: Float, dy: Float, minDim: Float, alpha: Int) {
        val len = minDim * 0.22f
        val width = minDim * 0.012f + 4f
        val gap = minDim * 0.05f
        val sx = sx0 + dx * gap
        val sy = sy0 + dy * gap
        val ex = sx + dx * len
        val ey = sy + dy * len
        val head = width * 3.4f
        val nx = -dy
        val ny = dx
        val bx = ex - dx * head
        val by = ey - dy * head

        shadow.pathEffect = null
        shadow.strokeWidth = width + 9f
        shadow.alpha = (alpha * 0.55f).toInt()
        canvas.drawLine(sx, sy, bx, by, shadow)
        stroke.pathEffect = null
        stroke.color = Color.rgb(70, 235, 130)
        stroke.alpha = alpha
        stroke.strokeWidth = width
        canvas.drawLine(sx, sy, bx, by, stroke)

        path.reset()
        path.moveTo(ex, ey)
        path.lineTo(bx + nx * head * 0.85f, by + ny * head * 0.85f)
        path.lineTo(bx - nx * head * 0.85f, by - ny * head * 0.85f)
        path.close()
        shadow.strokeWidth = 9f
        canvas.drawPath(path, shadow)
        fill.color = Color.rgb(70, 235, 130)
        fill.alpha = alpha
        canvas.drawPath(path, fill)
    }

    private fun drawAim(canvas: Canvas, px: Float, py: Float, tx: Float, ty: Float, minDim: Float, alpha: Int) {
        val r = minDim * 0.038f
        val red = Color.rgb(255, 75, 75)

        // dashed line from the fighter to the aim point
        shadow.pathEffect = dash
        shadow.strokeWidth = 9f
        shadow.alpha = (alpha * 0.45f).toInt()
        canvas.drawLine(px, py, tx, ty, shadow)
        stroke.pathEffect = dash
        stroke.color = Color.WHITE
        stroke.alpha = (alpha * 0.85f).toInt()
        stroke.strokeWidth = 4f
        canvas.drawLine(px, py, tx, ty, stroke)
        shadow.pathEffect = null
        stroke.pathEffect = null

        // ring + crosshair at the aim point
        shadow.strokeWidth = r * 0.34f + 7f
        shadow.alpha = (alpha * 0.6f).toInt()
        canvas.drawCircle(tx, ty, r, shadow)
        stroke.color = red
        stroke.alpha = alpha
        stroke.strokeWidth = r * 0.34f
        canvas.drawCircle(tx, ty, r, stroke)
        val tick = r * 0.9f
        val inner = r * 0.55f
        for (i in 0 until 4) {
            val ux = if (i == 0) 1f else if (i == 1) -1f else 0f
            val uy = if (i == 2) 1f else if (i == 3) -1f else 0f
            canvas.drawLine(tx + ux * inner, ty + uy * inner, tx + ux * (r + tick), ty + uy * (r + tick), shadow)
        }
        stroke.strokeWidth = 5f
        for (i in 0 until 4) {
            val ux = if (i == 0) 1f else if (i == 1) -1f else 0f
            val uy = if (i == 2) 1f else if (i == 3) -1f else 0f
            canvas.drawLine(tx + ux * inner, ty + uy * inner, tx + ux * (r + tick), ty + uy * (r + tick), stroke)
        }
        fill.color = red
        fill.alpha = alpha
        canvas.drawCircle(tx, ty, r * 0.16f, fill)
    }
}
