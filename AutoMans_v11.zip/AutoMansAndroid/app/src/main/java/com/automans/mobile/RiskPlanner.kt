package com.automans.mobile

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Velocity is measured in screen-relative coordinates, so camera tracking is naturally included. */
data class MotionTrack(
    val x: Double,
    val y: Double,
    val vx: Double,
    val vy: Double,
    val radius: Double,
    val ageMs: Long,
    val hits: Int,
)

data class DodgeDecision(
    val dx: Float = 0f,
    val dy: Float = 0f,
    val threats: Int = 0,
    val riskBefore: Double = 0.0,
    val riskAfter: Double = 0.0,
    val reason: String = "нет подтверждённой угрозы",
) {
    val shouldDodge: Boolean get() = dx * dx + dy * dy > 0.20f
}

/** Pure decision layer. Safe to run in a local JVM test without Android classes. */
class RiskPlanner {
    private data class Threat(val track: MotionTrack, val relX: Double, val relY: Double, val safeRadius: Double)

    fun choose(
        width: Int,
        height: Int,
        settings: DodgeSettings,
        tracks: List<MotionTrack>,
    ): DodgeDecision {
        if (width < 1 || height < 1) return DodgeDecision(reason = "неверный размер экрана")
        val minDim = min(width, height).toDouble()
        val playerX = (settings.playerX.coerceIn(0.05f, 0.95f) * width).toDouble()
        val playerY = (settings.playerY.coerceIn(0.05f, 0.95f) * height).toDouble()
        val playerRadius = minDim * 0.038
        val threatCandidates = ArrayList<Threat>()
        // Sensitivity 1..10: low values need a longer, clearer track before the helper reacts.
        val sens = settings.sensitivity.coerceIn(1, 10)
        val minHits = if (sens <= 5) 3 else 2
        val stayGate = 0.60 - 0.045 * sens

        for (t in tracks) {
            if (!t.x.isFinite() || !t.y.isFinite() || !t.vx.isFinite() || !t.vy.isFinite()) continue
            if (t.ageMs !in 0L..380L || t.hits < minHits) continue
            val relX = t.x - playerX
            val relY = t.y - playerY
            val speed2 = t.vx * t.vx + t.vy * t.vy
            val distanceNow = hypot(relX, relY)
            val radius = playerRadius + t.radius.coerceIn(4.0, minDim * 0.045) + minDim * 0.018

            if (speed2 < 30.0 * 30.0) {
                // A large, nearly stationary newly appeared shape may be an area warning.
                if (sens >= 7 && t.radius >= minDim * 0.025 && distanceNow < minDim * 0.17) {
                    threatCandidates.add(Threat(t, relX, relY, radius + minDim * 0.045))
                }
                continue
            }

            val tClosest = (-(relX * t.vx + relY * t.vy) / speed2)
            if (tClosest < 0.0 && distanceNow > radius * 1.15) continue
            if (tClosest > 0.82 && distanceNow > radius * 1.20) continue
            val tc = tClosest.coerceIn(0.0, 0.82)
            val closest = hypot(relX + t.vx * tc, relY + t.vy * tc)
            if (closest <= radius * 1.30) {
                threatCandidates.add(Threat(t, relX, relY, radius))
            }
        }

        if (threatCandidates.isEmpty()) return DodgeDecision(reason = "движущаяся угроза не пересекает безопасную зону")

        val moveSpeed = minDim * 0.34
        val horizon = 0.64
        val steps = 8

        fun risk(dx: Double, dy: Double): Double {
            var total = 0.0
            for (threat in threatCandidates) {
                for (step in 0..steps) {
                    val time = horizon * step / steps
                    val relX = threat.relX + (threat.track.vx - dx * moveSpeed) * time
                    val relY = threat.relY + (threat.track.vy - dy * moveSpeed) * time
                    val distance = hypot(relX, relY)
                    val safe = threat.safeRadius
                    val discount = 1.0 - 0.28 * (time / horizon)
                    if (distance < safe) {
                        val penetration = (safe - distance) / safe
                        total += (0.20 + 1.9 * penetration * penetration) * discount
                    } else if (distance < safe * 1.30) {
                        val proximity = (safe * 1.30 - distance) / (safe * 0.30)
                        total += 0.075 * proximity * discount
                    } else if (distance < safe * 2.35) {
                        // A soft near-miss cost helps distinguish a clean side-step from running
                        // straight along a projectile lane when both candidates avoid immediate hit.
                        val proximity = (safe * 2.35 - distance) / (safe * 1.05)
                        total += 0.018 * proximity * discount
                    }
                }
            }
            return if (total.isFinite()) total else Double.MAX_VALUE / 4.0
        }

        val stayRisk = risk(0.0, 0.0)
        if (stayRisk < stayGate) {
            return DodgeDecision(threats = threatCandidates.size, riskBefore = stayRisk,
                riskAfter = stayRisk, reason = "траектория пока не требует манёвра")
        }

        var bestX = 0.0
        var bestY = 0.0
        var bestRisk = Double.MAX_VALUE
        // 16 directional candidates keep diagonal choices available on mobile controls.
        for (i in 0 until 16) {
            val angle = 2.0 * PI * i / 16.0
            val dx = cos(angle)
            val dy = sin(angle)
            var score = risk(dx, dy)
            // Tiny deterministic tie-break prevents arbitrary floating-point direction flicker.
            score += i * 1e-5
            if (score < bestRisk) {
                bestRisk = score
                bestX = dx
                bestY = dy
            }
        }

        if (!bestRisk.isFinite() || bestRisk == Double.MAX_VALUE) {
            return DodgeDecision(threats = threatCandidates.size, riskBefore = stayRisk,
                riskAfter = stayRisk, reason = "нет конечного безопасного кандидата")
        }
        if (bestRisk >= stayRisk * 0.98 && stayRisk < 0.45) {
            return DodgeDecision(threats = threatCandidates.size, riskBefore = stayRisk,
                riskAfter = bestRisk, reason = "не найдено улучшение, достаточно безопасно остаться")
        }
        val length = hypot(bestX, bestY).coerceAtLeast(0.0001)
        return DodgeDecision(
            dx = (bestX / length).toFloat(),
            dy = (bestY / length).toFloat(),
            threats = threatCandidates.size,
            riskBefore = stayRisk,
            riskAfter = bestRisk,
            reason = "прогноз пересечения; выбран наименее рискованный манёвр",
        )
    }
}
