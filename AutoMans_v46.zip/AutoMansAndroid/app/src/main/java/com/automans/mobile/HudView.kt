package com.automans.mobile

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/**
 * Touch-through drawing layer shown above the game.
 *  - Green chevrons from the fighter = "run this way".
 *  - Yellow ring = where the nearest enemy will be in a moment; small white ring = where he is now;
 *    the arrow between them is his movement; dashed line = aim direction from the fighter.
 * Positions are advanced by the measured speed while a frame is waiting, so the drawing does not trail behind.
 */
class HudView(context: Context) : View(context) {
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val dash = DashPathEffect(floatArrayOf(22f, 16f), 0f)

    /** 0.3 .. 1.0, set from the settings slider. */
    var intensity: Float = 0.85f

    private var dodgeDx = 0f
    private var dodgeDy = 0f
    private var dodgeAt = 0L
    private var aimX = 0f
    private var aimY = 0f
    private var aimVx = 0f
    private var aimVy = 0f
    private var predX = 0f
    private var predY = 0f
    private var aimAt = 0L
    private var others = IntArray(0)
    private var playerFx = 0.5f
    private var playerFy = 0.5f

    fun setDodge(dx: Float, dy: Float, playerX: Float, playerY: Float) {
        dodgeDx = dx
        dodgeDy = dy
        dodgeAt = SystemClock.uptimeMillis()
        playerFx = playerX
        playerFy = playerY
        invalidate()
    }

    fun setAim(
        x: Float, y: Float, vx: Float, vy: Float, nextX: Float, nextY: Float,
        playerX: Float, playerY: Float, otherEnemies: IntArray,
    ) {
        aimX = x
        aimY = y
        aimVx = vx
        aimVy = vy
        predX = nextX
        predY = nextY
        others = otherEnemies
        aimAt = SystemClock.uptimeMillis()
        playerFx = playerX
        playerFy = playerY
        invalidate()
    }

    fun clearAim() {
        aimAt = 0L
        invalidate()
    }

    fun clearAll() {
        aimAt = 0L
        dodgeAt = 0L
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val w = width.toFloat()
        val h = height.toFloat()
        if (w < 10f || h < 10f) return
        val minDim = min(w, h)
        val px = playerFx * w
        val py = playerFy * h
        var active = false

        val aimAge = now - aimAt
        if (aimAt != 0L && aimAge in 0L..600L) {
            active = true
            drawEnemies(canvas, px, py, minDim, aimAge)
        }
        val dodgeAge = now - dodgeAt
        if (dodgeAt != 0L && dodgeAge in 0L..420L) {
            active = true
            val a = alphaFor(dodgeAge, 420L)
            drawRoute(canvas, px, py, dodgeDx, dodgeDy, minDim, a)
        }
        if (active) postInvalidateDelayed(16L)
    }

    private fun alphaFor(age: Long, life: Long): Int {
        val left = 1f - age.toFloat() / life.toFloat()
        return (255f * left.coerceIn(0.2f, 1f) * intensity.coerceIn(0.3f, 1f)).toInt()
    }

    private fun drawEnemies(canvas: Canvas, px: Float, py: Float, minDim: Float, ageMs: Long) {
        val alpha = alphaFor(ageMs, 600L)
        val ahead = min(ageMs, 220L) / 1000f // advance by speed while waiting for the next frame
        val r = minDim * 0.030f

        val cx = aimX + aimVx * ahead
        val cy = aimY + aimVy * ahead
        val nx = predX + aimVx * ahead
        val ny = predY + aimVy * ahead
        val moving = hypot(nx - cx, ny - cy) > r * 0.7f

        // aim line from the fighter to the predicted point
        val lineLen = hypot(nx - px, ny - py)
        if (lineLen > minDim * 0.09f) {
            val ux = (nx - px) / lineLen
            val uy = (ny - py) / lineLen
            val sx = px + ux * minDim * 0.05f
            val sy = py + uy * minDim * 0.05f
            val ex = nx - ux * (r + 4f)
            val ey = ny - uy * (r + 4f)
            shadow.pathEffect = dash
            shadow.strokeWidth = 7f
            shadow.alpha = (alpha * 0.4f).toInt()
            canvas.drawLine(sx, sy, ex, ey, shadow)
            stroke.pathEffect = dash
            stroke.color = Color.WHITE
            stroke.alpha = (alpha * 0.8f).toInt()
            stroke.strokeWidth = 3f
            canvas.drawLine(sx, sy, ex, ey, stroke)
            shadow.pathEffect = null
            stroke.pathEffect = null
        }

        if (moving) {
            drawMoveArrow(canvas, cx, cy, nx, ny, r, alpha)
            drawRing(canvas, cx, cy, r * 0.42f, Color.WHITE, 3f, (alpha * 0.9f).toInt())
        }
        drawRing(canvas, nx, ny, r, Color.rgb(255, 225, 40), 4f, alpha)
        // four short ticks make the aim point easy to spot
        val gap = r * 1.15f
        val tick = r * 0.45f
        for (i in 0 until 4) {
            val ux = if (i == 0) 1f else if (i == 1) -1f else 0f
            val uy = if (i == 2) 1f else if (i == 3) -1f else 0f
            shadow.strokeWidth = 8f
            shadow.alpha = (alpha * 0.55f).toInt()
            canvas.drawLine(nx + ux * gap, ny + uy * gap, nx + ux * (gap + tick), ny + uy * (gap + tick), shadow)
            stroke.color = Color.rgb(255, 225, 40)
            stroke.alpha = alpha
            stroke.strokeWidth = 4f
            canvas.drawLine(nx + ux * gap, ny + uy * gap, nx + ux * (gap + tick), ny + uy * (gap + tick), stroke)
        }

        // other enemies: small ring where he is, tiny arrow where he is heading
        var i = 0
        while (i + 3 < others.size) {
            val ox = others[i].toFloat()
            val oy = others[i + 1].toFloat()
            val ex = others[i + 2].toFloat()
            val ey = others[i + 3].toFloat()
            if (hypot(ex - ox, ey - oy) > r * 0.7f) drawMoveArrow(canvas, ox, oy, ex, ey, r * 0.7f, (alpha * 0.8f).toInt())
            drawRing(canvas, ox, oy, r * 0.55f, Color.rgb(255, 225, 40), 3f, (alpha * 0.75f).toInt())
            i += 4
        }
    }

    private fun drawRing(canvas: Canvas, x: Float, y: Float, radius: Float, color: Int, width: Float, alpha: Int) {
        shadow.pathEffect = null
        shadow.strokeWidth = width + 4.5f
        shadow.alpha = (alpha * 0.55f).toInt()
        canvas.drawCircle(x, y, radius, shadow)
        stroke.pathEffect = null
        stroke.color = color
        stroke.alpha = alpha
        stroke.strokeWidth = width
        canvas.drawCircle(x, y, radius, stroke)
    }

    private fun drawMoveArrow(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, r: Float, alpha: Int) {
        val len = hypot(x1 - x0, y1 - y0)
        if (len < 1f) return
        val ux = (x1 - x0) / len
        val uy = (y1 - y0) / len
        val sx = x0 + ux * r * 0.5f
        val sy = y0 + uy * r * 0.5f
        val ex = x1 - ux * r * 1.05f
        val ey = y1 - uy * r * 1.05f
        if ((ex - sx) * ux + (ey - sy) * uy < 4f) return
        val head = r * 0.55f
        shadow.pathEffect = null
        shadow.strokeWidth = 8f
        shadow.alpha = (alpha * 0.5f).toInt()
        canvas.drawLine(sx, sy, ex, ey, shadow)
        stroke.pathEffect = null
        stroke.color = Color.WHITE
        stroke.alpha = alpha
        stroke.strokeWidth = 3.5f
        canvas.drawLine(sx, sy, ex, ey, stroke)
        path.reset()
        path.moveTo(ex + ux * head, ey + uy * head)
        path.lineTo(ex - uy * head * 0.7f, ey + ux * head * 0.7f)
        path.lineTo(ex + uy * head * 0.7f, ey - ux * head * 0.7f)
        path.close()
        fill.color = Color.WHITE
        fill.alpha = alpha
        canvas.drawPath(path, fill)
    }

    /** A row of growing chevrons >>> from the fighter in the escape direction, ending in a small ring. */
    private fun drawRoute(canvas: Canvas, sx: Float, sy: Float, dx: Float, dy: Float, minDim: Float, alpha: Int) {
        val green = Color.rgb(70, 235, 130)
        val nx = -dy
        val ny = dx
        val start = minDim * 0.07f
        val step = minDim * 0.055f
        val count = 4
        for (k in 0 until count) {
            val dist = start + k * step
            val cx = sx + dx * dist
            val cy = sy + dy * dist
            val size = minDim * (0.017f + 0.004f * k)
            val a = (alpha * (1f - 0.1f * k)).toInt()
            path.reset()
            path.moveTo(cx - dx * size * 0.6f + nx * size, cy - dy * size * 0.6f + ny * size)
            path.lineTo(cx + dx * size * 0.7f, cy + dy * size * 0.7f)
            path.lineTo(cx - dx * size * 0.6f - nx * size, cy - dy * size * 0.6f - ny * size)
            shadow.pathEffect = null
            shadow.strokeWidth = 11f
            shadow.alpha = (a * 0.5f).toInt()
            canvas.drawPath(path, shadow)
            stroke.pathEffect = null
            stroke.color = green
            stroke.alpha = a
            stroke.strokeWidth = 6f
            canvas.drawPath(path, stroke)
        }
        val endDist = start + count * step + minDim * 0.01f
        drawRing(canvas, sx + dx * endDist, sy + dy * endDist, minDim * 0.022f, green, 4f, (alpha * 0.8f).toInt())
    }
}
