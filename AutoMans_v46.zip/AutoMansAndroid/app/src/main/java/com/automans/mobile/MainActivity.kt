package com.automans.mobile

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequest = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DodgeSettings.migrate(this)
        AimLog.init(this)
        val prefs = getSharedPreferences("automans_settings", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            gravity = Gravity.TOP
        }
        layout.addView(TextView(this).apply {
            text = "AUTO-MANS • Max"
            textSize = 23f
        })
        layout.addView(TextView(this).apply {
            text = "Целишься ты сам. Когда белая линия коснулась красного кружка врага, помощник двигает прицел туда, где враг будет, и выстреливает один раз. Ничего не рисует на экране. Выключить и остановить можно в шторке уведомлений. Нужен запущенный Shizuku."
            textSize = 14f
            setPadding(0, dp(10), 0, dp(12))
        })

        layout.addView(TextView(this).apply {
            text = "Твой боец:"
            textSize = 14f
            setPadding(0, dp(6), 0, 0)
        })
        val brawlerList = BrawlerData.all.sortedBy { if (it.id == "Speedy") 0 else 1 }
        var brawlerId = prefs.getString("brawler", "Speedy") ?: "Speedy"
        layout.addView(android.widget.Spinner(this).apply {
            adapter = android.widget.ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                brawlerList.map { if (it.id == "Speedy") "Max (Speedy)" else it.title },
            )
            setSelection(brawlerList.indexOfFirst { it.id == brawlerId }.coerceAtLeast(0))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    val chosen = brawlerList[position].id
                    if (chosen != brawlerId) {
                        brawlerId = chosen
                        prefs.edit().putString("brawler", chosen).apply()
                    }
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }
        })

        layout.addView(Button(this).apply {
            text = "1. Разрешить поверх других приложений"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Включить управление касаниями"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "3. Запустить"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    layout.addView(TextView(this@MainActivity).apply { text = "Сначала разреши отображение поверх других приложений." })
                    return@setOnClickListener
                }
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val launch = { startActivityForResult(manager.createScreenCaptureIntent(), captureRequest) }
                if (ShizukuBridge.isRunning() && !ShizukuBridge.hasPermission()) {
                    ShizukuBridge.requestPermission { runOnUiThread { launch() } }
                } else launch()
            }
        })

        val logView = TextView(this).apply { textSize = 11f; setPadding(0, dp(8), 0, 0); setTextIsSelectable(true) }
        layout.addView(Button(this).apply {
            text = "Журнал: показать и скопировать"
            setOnClickListener {
                val t = AimLog.text(60)
                logView.text = if (t.isBlank()) "Журнал пуст: сначала поиграй." else t
                try {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("automans", t))
                } catch (ignored: Exception) { }
            }
        })
        layout.addView(logView)

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(layout, android.view.ViewGroup.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ))
        })

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 702)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated by Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service)
            else startService(service)
            finish()
        }
    }
}
