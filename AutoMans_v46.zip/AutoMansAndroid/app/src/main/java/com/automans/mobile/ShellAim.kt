package com.automans.mobile

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

/**
 * Holds the attack stick with the extra ADB finger, follows the predicted enemy position and
 * lets go once (one shot) when the white aim line sits on the hitbox. The player's own fingers are never touched.
 */
class ShellAim {
    private var holding = false
    private var startMs = 0L
    private var lastEndMs = 0L
    private var lastDirMs = 0L
    private var lastMoveMs = 0L
    private var baseX = 0f
    private var baseY = 0f
    private var reach = 0f
    private var baseRadius = 0f
    @Volatile var isHolding = false
        private set
    private var prevDx = 0f
    private var prevDy = 0f

    @Synchronized fun frame(
        dx: Float, dy: Float, hasDir: Boolean, distPx: Float,
        w: Int, h: Int, s: DodgeSettings, now: Long,
        lobbed: Boolean = false, rangePx: Float = 0f,
    ) {
        if (w < 100 || h < 100 || !ShellTouch.ready) { if (holding) cancel(); return }
        val minDim = min(w, h).toFloat()
        val radius = minDim * s.attackRadiusPct.coerceIn(0.04f, 0.14f)
        val bx = w * s.attackX.coerceIn(0.65f, 0.97f)
        val by = h * s.attackY.coerceIn(0.55f, 0.95f)
        val userOnStick = ShellTouch.fingerNear(bx, by, radius * 1.5f)

        if (holding) {
            if (userOnStick) { AimLog.add("ADB: ты взялся за стик атаки, отпускаю"); cancel(); return }
            if (!hasDir) {
                if (now - lastDirMs > 300L) cancel()
                return
            }
            lastDirMs = now
            val held = now - startMs
            if (held > 900L) { cancel(); return }
            if (now - lastMoveMs >= 18L) {
                val rr = if (lobbed && rangePx > 1f) baseRadius * (distPx / rangePx).coerceIn(0.12f, 1f) else reach
                ShellTouch.move(baseX + dx * rr, baseY + dy * rr)
                lastMoveMs = now
            }
            if (held >= 230L) {
                // lined up: the stick direction hardly changed since the previous frame
                val half = atan2(0.045 * minDim, max(distPx, 60f).toDouble())
                val need = cos(half * 0.6).coerceIn(0.97, 0.9995).toFloat()
                if (prevDx * dx + prevDy * dy >= need) {
                    ShellTouch.up()
                    holding = false
                    isHolding = false
                    lastEndMs = now
                    MansAccessibilityService.shotCounter++
                    AimLog.add("ADB ВЫСТРЕЛ: держал $held мс, линия на цели")
                    return
                }
            }
            prevDx = dx
            prevDy = dy
            return
        }
        if (!hasDir || userOnStick) return
        if (now - lastEndMs < 450L) return
        baseX = bx
        baseY = by
        reach = radius * 1.6f
        baseRadius = radius
        if (!ShellTouch.down(bx, by)) return
        val r0 = if (lobbed && rangePx > 1f) radius * (distPx / rangePx).coerceIn(0.12f, 1f) else reach
        ShellTouch.move(bx + dx * r0, by + dy * r0)
        holding = true
        isHolding = true
        startMs = now
        lastDirMs = now
        lastMoveMs = now
        prevDx = dx
        prevDy = dy
        AimLog.add("ADB НАЖАЛ стик атаки: направление %.2f,%.2f".format(java.util.Locale.US, dx, dy))
    }

    /** Let go without a shot: slide back to the stick centre first. */
    @Synchronized fun cancel() {
        if (!holding) return
        ShellTouch.move(baseX, baseY)
        ShellTouch.up()
        holding = false
        isHolding = false
        lastEndMs = android.os.SystemClock.elapsedRealtime()
        AimLog.add("ADB ОТМЕНА выстрела")
    }
}
