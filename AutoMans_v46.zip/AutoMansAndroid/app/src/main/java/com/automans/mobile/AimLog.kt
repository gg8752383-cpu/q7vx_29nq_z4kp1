package com.automans.mobile

import android.content.Context
import android.os.SystemClock
import java.io.File

/** Tiny text journal of what the helper did, so a bad shot can be explained from a few pasted lines. */
object AimLog {
    private const val FILE = "aimlog.txt"
    private const val MAX_LINES = 250
    private val lines = ArrayList<String>()
    private var loaded = false
    private var file: File? = null
    private var dirty = 0
    private val t0 = SystemClock.elapsedRealtime()

    @Synchronized fun init(context: Context) {
        if (file != null) return
        file = File(context.applicationContext.filesDir, FILE)
        if (!loaded) {
            loaded = true
            try { file?.takeIf { it.exists() }?.readLines()?.let { lines.addAll(it.takeLast(MAX_LINES)) } } catch (ignored: Exception) { }
        }
    }

    @Synchronized fun add(msg: String) {
        val sec = (SystemClock.elapsedRealtime() - t0) / 1000.0
        lines.add(String.format(java.util.Locale.US, "%.1f %s", sec, msg))
        while (lines.size > MAX_LINES) lines.removeAt(0)
        dirty++
        if (dirty >= 6) flush()
    }

    @Synchronized fun flush() {
        dirty = 0
        try { file?.writeText(lines.joinToString("\n")) } catch (ignored: Exception) { }
    }

    @Synchronized fun text(maxLines: Int = 80): String {
        flush()
        return lines.takeLast(maxLines).joinToString("\n")
    }

    @Synchronized fun clear() {
        lines.clear()
        flush()
    }
}
