package com.automans.mobile

import android.media.Image
import java.nio.ByteBuffer
import java.util.Arrays
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Template-free screen motion detector. It pairs the disappearance of a moving compact shape
 * with its appearance in the next position, then tracks the resulting motion vector.
 * This can detect many visible moving projectiles, but is not a classifier for every attack/AoE.
 */
class VisionDodgeEngine {
    private data class Blob(
        val x: Double,
        val y: Double,
        val radius: Double,
        val pixels: Int,
        val deltaR: Double,
        val deltaG: Double,
        val deltaB: Double,
        val foregroundDelta: Double,
        val currentFeature: Double,
    )
    private data class Observation(
        val x: Double,
        val y: Double,
        val vx: Double,
        val vy: Double,
        val radius: Double,
        val pixels: Int,
    )
    private data class Track(
        var x: Double,
        var y: Double,
        var vx: Double,
        var vy: Double,
        var radius: Double,
        var lastSeenMs: Long,
        var lastUpdateMs: Long,
        var hits: Int,
    )
    private data class PairCandidate(
        val newIndex: Int,
        val oldIndex: Int,
        val quality: Double,
    )

    private var gridW = 0
    private var gridH = 0
    private var sourceW = 0
    private var sourceH = 0
    private var previousPixels = IntArray(0)
    private var currentPixels = IntArray(0)
    private var motionMask = ByteArray(0)
    private var visited = ByteArray(0)
    private var queue = IntArray(0)
    private val tracks = ArrayList<Track>()
    private val planner = RiskPlanner()
    private var lastProcessedMs = 0L
    private var previousFrameMs = 0L
    private var lastDecision = DodgeDecision(reason = "жду первый кадр")
    @Volatile var lastBlobCount: Int = 0
        private set
    @Volatile var lastTrackCount: Int = 0
        private set
    @Volatile var lastThreatCount: Int = 0
        private set
    @Volatile var lastPairCount: Int = 0
        private set

    @Synchronized fun reset() {
        gridW = 0
        gridH = 0
        sourceW = 0
        sourceH = 0
        previousPixels = IntArray(0)
        currentPixels = IntArray(0)
        motionMask = ByteArray(0)
        visited = ByteArray(0)
        queue = IntArray(0)
        tracks.clear()
        lastProcessedMs = 0L
        previousFrameMs = 0L
        lastDecision = DodgeDecision(reason = "геометрия экрана изменена")
        lastBlobCount = 0
        lastTrackCount = 0
        lastThreatCount = 0
        lastPairCount = 0
    }

    /** Returns null when a frame is deliberately skipped to limit CPU use. */
    @Synchronized fun process(image: Image, nowMs: Long, settings: DodgeSettings): DodgeDecision? {
        if (nowMs - lastProcessedMs < 78L) return null
        lastProcessedMs = nowMs
        val w = image.width
        val h = image.height
        if (w < 100 || h < 100) return null
        ensureBuffers(w, h)
        samplePixels(image, currentPixels)

        if (previousPixels.isEmpty() || previousPixels.size != currentPixels.size) {
            previousPixels = currentPixels.copyOf()
            previousFrameMs = nowMs
            lastDecision = DodgeDecision(reason = "собираю базовый кадр")
            return lastDecision
        }

        val frameDeltaMs = (nowMs - previousFrameMs).coerceIn(45L, 300L)
        buildMotionMask(settings)
        val blobs = extractBlobs()
        lastBlobCount = blobs.size
        val observations = pairMovingBlobs(blobs, frameDeltaMs / 1000.0, min(w, h).toDouble())
        lastPairCount = observations.size
        updateTracks(observations, nowMs, min(w, h).toDouble())

        val plannerTracks = tracks.mapNotNull { t ->
            val age = nowMs - t.lastSeenMs
            if (age < 0L || age > 380L) return@mapNotNull null
            val dt = age / 1000.0
            MotionTrack(
                x = t.x + t.vx * dt,
                y = t.y + t.vy * dt,
                vx = t.vx,
                vy = t.vy,
                radius = t.radius,
                ageMs = age,
                hits = t.hits,
            )
        }
        lastTrackCount = plannerTracks.size
        lastDecision = planner.choose(w, h, settings, plannerTracks)
        lastThreatCount = lastDecision.threats

        val oldPrevious = previousPixels
        previousPixels = currentPixels
        currentPixels = oldPrevious
        previousFrameMs = nowMs
        return lastDecision
    }

    @Synchronized fun statusLine(): String =
        "пятен: $lastBlobCount • пар движ.: $lastPairCount • треков: $lastTrackCount • угроз: $lastThreatCount"

    private fun ensureBuffers(w: Int, h: Int) {
        if (w == sourceW && h == sourceH && gridW > 0 && gridH > 0) return
        sourceW = w
        sourceH = h
        val scale = max(1.0, max(w, h).toDouble() / 480.0)
        gridW = max(1, (w / scale).toInt())
        gridH = max(1, (h / scale).toInt())
        val n = gridW * gridH
        previousPixels = IntArray(0)
        currentPixels = IntArray(n)
        motionMask = ByteArray(n)
        visited = ByteArray(n)
        queue = IntArray(n)
        tracks.clear()
    }

    private fun samplePixels(image: Image, target: IntArray) {
        val plane = image.planes.firstOrNull() ?: return
        val buffer: ByteBuffer = plane.buffer
        val baseOffset = buffer.position()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val w = image.width
        val h = image.height
        var out = 0
        for (gy in 0 until gridH) {
            val sy = ((gy + 0.5) * h / gridH).toInt().coerceIn(0, h - 1)
            val row = sy * rowStride
            for (gx in 0 until gridW) {
                val sx = ((gx + 0.5) * w / gridW).toInt().coerceIn(0, w - 1)
                val idx = baseOffset + row + sx * pixelStride
                if (idx < baseOffset || idx + 2 >= buffer.limit()) {
                    target[out++] = 0
                } else {
                    val r = buffer.get(idx).toInt() and 0xFF
                    val g = buffer.get(idx + 1).toInt() and 0xFF
                    val b = buffer.get(idx + 2).toInt() and 0xFF
                    target[out++] = (r shl 16) or (g shl 8) or b
                }
            }
        }
    }

    private fun buildMotionMask(settings: DodgeSettings) {
        Arrays.fill(motionMask, 0.toByte())
        val playerX = settings.playerX * sourceW
        val playerY = settings.playerY * sourceH
        val playerIgnore = min(sourceW, sourceH) * 0.025f
        var idx = 0
        for (gy in 0 until gridH) {
            val ny = (gy + 0.5f) / gridH
            val sy = (gy + 0.5f) * sourceH / gridH
            for (gx in 0 until gridW) {
                val nx = (gx + 0.5f) / gridW
                val sx = (gx + 0.5f) * sourceW / gridW
                if (isUiRegion(nx, ny)) {
                    idx++
                    continue
                }
                val dxPlayer = sx - playerX
                val dyPlayer = sy - playerY
                if (dxPlayer * dxPlayer + dyPlayer * dyPlayer < playerIgnore * playerIgnore) {
                    idx++
                    continue
                }
                val a = currentPixels[idx]
                val b = previousPixels[idx]
                val r = (a shr 16) and 0xFF
                val g = (a shr 8) and 0xFF
                val blue = a and 0xFF
                val pr = (b shr 16) and 0xFF
                val pg = (b shr 8) and 0xFF
                val pb = b and 0xFF
                val difference = abs(r - pr) + abs(g - pg) + abs(blue - pb)
                val high = max(r, max(g, blue))
                val low = min(r, min(g, blue))
                val saturation = high - low
                if (difference >= 78 && (saturation >= 28 || (high >= 205 && low >= 145))) {
                    motionMask[idx] = 1
                }
                idx++
            }
        }
    }

    private fun isUiRegion(x: Float, y: Float): Boolean {
        if (y < 0.055f || y > 0.965f) return true
        if (x < 0.17f && y > 0.67f) return true
        if (x > 0.82f && y > 0.64f) return true
        if (x < 0.18f && y < 0.23f) return true
        return false
    }

    private fun featureScore(rgb: Int): Double {
        val r = (rgb shr 16) and 0xFF
        val g = (rgb shr 8) and 0xFF
        val b = rgb and 0xFF
        val high = max(r, max(g, b))
        val low = min(r, min(g, b))
        // Brightness dominates so white projectile sprites remain trackable over green/sandy maps.
        return high * 0.72 + (high - low) * 0.28
    }

    private fun extractBlobs(): List<Blob> {
        Arrays.fill(visited, 0.toByte())
        val blobs = ArrayList<Blob>(32)
        val n = motionMask.size
        val sampleScaleX = sourceW.toDouble() / gridW
        val sampleScaleY = sourceH.toDouble() / gridH
        val minDim = min(sourceW, sourceH).toDouble()

        for (start in 0 until n) {
            if (motionMask[start].toInt() == 0 || visited[start].toInt() != 0) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = 1
            var count = 0
            var sumX = 0.0
            var sumY = 0.0
            var deltaR = 0.0
            var deltaG = 0.0
            var deltaB = 0.0
            var foregroundDelta = 0.0
            var currentFeature = 0.0
            var minX = gridW
            var maxX = 0
            var minY = gridH
            var maxY = 0
            while (head < tail) {
                val current = queue[head++]
                val x = current % gridW
                val y = current / gridW
                count++
                sumX += x
                sumY += y
                minX = min(minX, x)
                maxX = max(maxX, x)
                minY = min(minY, y)
                maxY = max(maxY, y)
                val a = currentPixels[current]
                val b = previousPixels[current]
                deltaR += ((a shr 16) and 0xFF) - ((b shr 16) and 0xFF)
                deltaG += ((a shr 8) and 0xFF) - ((b shr 8) and 0xFF)
                deltaB += (a and 0xFF) - (b and 0xFF)
                val cf = featureScore(a)
                currentFeature += cf
                foregroundDelta += cf - featureScore(b)

                for (oy in -1..1) {
                    val ny = y + oy
                    if (ny !in 0 until gridH) continue
                    for (ox in -1..1) {
                        if (ox == 0 && oy == 0) continue
                        val nx = x + ox
                        if (nx !in 0 until gridW) continue
                        val next = ny * gridW + nx
                        if (motionMask[next].toInt() != 0 && visited[next].toInt() == 0) {
                            visited[next] = 1
                            if (tail < queue.size) queue[tail++] = next
                        }
                    }
                }
            }
            val boxW = maxX - minX + 1
            val boxH = maxY - minY + 1
            if (count !in 2..150 || boxW > 34 || boxH > 34) continue
            val x = (sumX / count + 0.5) * sampleScaleX
            val y = (sumY / count + 0.5) * sampleScaleY
            val radius = (sqrt(count.toDouble()) * (sampleScaleX + sampleScaleY) * 0.28)
                .coerceIn(4.0, minDim * 0.04)
            blobs.add(Blob(
                x, y, radius, count, deltaR, deltaG, deltaB,
                foregroundDelta / count, currentFeature / count,
            ))
        }
        // Busy fight scenes can produce hundreds of tiny change components. Pairing is O(n^2),
        // so keep the strongest 64 candidates to bound CPU time on mid-range Android devices.
        return blobs.sortedByDescending { it.pixels }.take(64)
    }

    private fun pairMovingBlobs(blobs: List<Blob>, frameSeconds: Double, minDim: Double): List<Observation> {
        if (blobs.size < 2 || frameSeconds <= 0.0) return emptyList()
        val candidates = ArrayList<PairCandidate>()
        for (i in blobs.indices) {
            val a = blobs[i]
            val magA = sqrt(a.deltaR * a.deltaR + a.deltaG * a.deltaG + a.deltaB * a.deltaB)
            if (magA < 80.0) continue
            for (j in i + 1 until blobs.size) {
                val b = blobs[j]
                val distance = hypot(b.x - a.x, b.y - a.y)
                if (distance < minDim * 0.006 || distance > minDim * 0.28) continue
                val ratio = min(a.pixels, b.pixels).toDouble() / max(a.pixels, b.pixels).toDouble()
                if (ratio < 0.24) continue
                val magB = sqrt(b.deltaR * b.deltaR + b.deltaG * b.deltaG + b.deltaB * b.deltaB)
                if (magB < 80.0) continue
                val correlation = (a.deltaR * b.deltaR + a.deltaG * b.deltaG + a.deltaB * b.deltaB) / (magA * magB)
                if (correlation > -0.48) continue

                val aIsNew = when {
                    a.foregroundDelta > 2.0 && b.foregroundDelta < -2.0 -> true
                    b.foregroundDelta > 2.0 && a.foregroundDelta < -2.0 -> false
                    // Fallback for effects whose average brightness changes little: choose the
                    // component whose current pixels look more projectile-like/bright.
                    abs(a.currentFeature - b.currentFeature) >= 9.0 -> a.currentFeature > b.currentFeature
                    else -> continue
                }
                val quality = correlation + (1.0 - ratio) * 0.20
                candidates.add(if (aIsNew) PairCandidate(i, j, quality) else PairCandidate(j, i, quality))
            }
        }
        candidates.sortBy { it.quality }
        val used = BooleanArray(blobs.size)
        val observations = ArrayList<Observation>()
        for (candidate in candidates) {
            if (used[candidate.newIndex] || used[candidate.oldIndex]) continue
            val newBlob = blobs[candidate.newIndex]
            val oldBlob = blobs[candidate.oldIndex]
            val dx = newBlob.x - oldBlob.x
            val dy = newBlob.y - oldBlob.y
            val vx = (dx / frameSeconds).coerceIn(-minDim * 3.0, minDim * 3.0)
            val vy = (dy / frameSeconds).coerceIn(-minDim * 3.0, minDim * 3.0)
            if (hypot(vx, vy) < minDim * 0.035) continue
            used[candidate.newIndex] = true
            used[candidate.oldIndex] = true
            observations.add(Observation(
                x = newBlob.x,
                y = newBlob.y,
                vx = vx,
                vy = vy,
                radius = max(newBlob.radius, oldBlob.radius),
                pixels = newBlob.pixels + oldBlob.pixels,
            ))
        }
        return observations
    }

    private fun updateTracks(observations: List<Observation>, nowMs: Long, minDim: Double) {
        val originalTrackCount = tracks.size
        val usedTracks = BooleanArray(originalTrackCount)
        for (observation in observations.sortedByDescending { it.pixels }) {
            var bestIndex = -1
            var bestDistance = Double.MAX_VALUE
            for (i in 0 until originalTrackCount) {
                if (usedTracks[i]) continue
                val track = tracks[i]
                val age = nowMs - track.lastSeenMs
                if (age !in 0L..360L) continue
                val dt = age / 1000.0
                val px = track.x + track.vx * dt
                val py = track.y + track.vy * dt
                val distance = hypot(observation.x - px, observation.y - py)
                val expected = hypot(track.vx, track.vy) * dt
                val gate = (18.0 + minDim * 0.018 + expected * 0.55).coerceIn(35.0, 145.0)
                if (distance <= gate && distance < bestDistance) {
                    bestDistance = distance
                    bestIndex = i
                }
            }
            if (bestIndex >= 0) {
                usedTracks[bestIndex] = true
                val t = tracks[bestIndex]
                val elapsed = ((nowMs - t.lastUpdateMs).coerceAtLeast(45L)) / 1000.0
                val measuredX = ((observation.x - t.x) / elapsed).coerceIn(-minDim * 3.0, minDim * 3.0)
                val measuredY = ((observation.y - t.y) / elapsed).coerceIn(-minDim * 3.0, minDim * 3.0)
                // Direct displacement of the paired old/new blobs is less camera-jitter-sensitive;
                // smooth it with the inter-frame track estimate instead of trusting either alone.
                t.vx = (observation.vx * 0.68 + measuredX * 0.32).coerceIn(-minDim * 3.0, minDim * 3.0)
                t.vy = (observation.vy * 0.68 + measuredY * 0.32).coerceIn(-minDim * 3.0, minDim * 3.0)
                t.x = observation.x
                t.y = observation.y
                t.radius = t.radius * 0.45 + observation.radius * 0.55
                t.lastSeenMs = nowMs
                t.lastUpdateMs = nowMs
                t.hits = (t.hits + 1).coerceAtMost(20)
            } else {
                tracks.add(Track(observation.x, observation.y, observation.vx, observation.vy,
                    observation.radius, nowMs, nowMs, 1))
            }
        }
        tracks.removeAll { nowMs - it.lastSeenMs > 380L }
        if (tracks.size > 90) {
            tracks.sortByDescending { it.hits * 100L - (nowMs - it.lastSeenMs) }
            while (tracks.size > 90) tracks.removeAt(tracks.lastIndex)
        }
    }
}
