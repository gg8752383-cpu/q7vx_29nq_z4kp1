package com.automans.mobile

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Centre of one detected enemy health bar, in the engine's downscaled grid coordinates. */
data class EnemyBar(val x: Double, val y: Double, val widthCells: Int)

/**
 * Finds enemy health bars: thin, solid, saturated red horizontal bars shown above enemies.
 * Pure Kotlin (no Android classes) so it can be tested on a normal JVM with a screenshot.
 */
class EnemyBarFinder {
    private var mask = ByteArray(0)
    private var queue = IntArray(0)

    private fun isEnemyRed(c: Int): Boolean {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        return abs(r - 233) <= 30 && abs(g - 22) <= 40 && abs(b - 47) <= 40
    }

    fun find(pixels: IntArray, gridW: Int, gridH: Int): List<EnemyBar> {
        val n = gridW * gridH
        if (n <= 0 || pixels.size < n) return emptyList()
        if (mask.size != n) {
            mask = ByteArray(n)
            queue = IntArray(n)
        }
        for (i in 0 until n) mask[i] = if (isEnemyRed(pixels[i])) 1 else 0

        val minW = max(4, (gridW * 0.010).toInt())
        val maxW = max(minW + 1, (gridW * 0.16).toInt())
        val result = ArrayList<EnemyBar>()

        for (start in 0 until n) {
            if (mask[start].toInt() != 1) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            mask[start] = 2
            var count = 0
            var sumX = 0.0
            var sumY = 0.0
            var minX = gridW
            var maxX = 0
            var minY = gridH
            var maxY = 0
            while (head < tail) {
                val cur = queue[head++]
                val x = cur % gridW
                val y = cur / gridW
                count++
                sumX += x
                sumY += y
                minX = min(minX, x)
                maxX = max(maxX, x)
                minY = min(minY, y)
                maxY = max(maxY, y)
                for (oy in -1..1) {
                    val ny = y + oy
                    if (ny < 0 || ny >= gridH) continue
                    for (ox in -1..1) {
                        val nx = x + ox
                        if (nx < 0 || nx >= gridW) continue
                        val next = ny * gridW + nx
                        if (mask[next].toInt() == 1) {
                            mask[next] = 2
                            queue[tail++] = next
                        }
                    }
                }
            }
            val boxW = maxX - minX + 1
            val boxH = maxY - minY + 1
            if (boxW < minW || boxW > maxW) continue
            if (boxH > 8 || boxW < boxH * 2) continue
            if (count < boxW * boxH * 0.5) continue
            result.add(EnemyBar(sumX / count, sumY / count, boxW))
        }
        return result
    }
}
