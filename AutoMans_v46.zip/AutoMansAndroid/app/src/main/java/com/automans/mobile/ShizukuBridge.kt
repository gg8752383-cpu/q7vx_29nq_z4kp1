package com.automans.mobile

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Runs shell commands with ADB rights through the Shizuku app (already started on the phone). */
object ShizukuBridge {
    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (ignored: Throwable) { false }

    fun hasPermission(): Boolean = try {
        isRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (ignored: Throwable) { false }

    fun requestPermission(onResult: (Boolean) -> Unit) {
        try {
            val listener = object : Shizuku.OnRequestPermissionResultListener {
                override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                    Shizuku.removeRequestPermissionResultListener(this)
                    onResult(grantResult == PackageManager.PERMISSION_GRANTED)
                }
            }
            Shizuku.addRequestPermissionResultListener(listener)
            Shizuku.requestPermission(4242)
        } catch (e: Throwable) {
            onResult(false)
        }
    }

    /** Starts a process with shell rights. newProcess is private in the library, so it is reached by reflection. */
    fun start(cmd: Array<String>): Process? = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java,
        )
        m.isAccessible = true
        m.invoke(null, cmd, null, null) as? Process
    } catch (e: Throwable) {
        null
    }

    /** Runs one command and returns everything it printed (stdout + stderr), cut to maxChars. */
    fun run(command: String, maxChars: Int = 6000): String {
        val p = start(arrayOf("sh", "-c", "$command 2>&1")) ?: return "(не удалось запустить команду через Shizuku)"
        return try {
            val text = p.inputStream.bufferedReader().readText()
            try { p.waitFor() } catch (ignored: Exception) { }
            if (text.length > maxChars) text.substring(0, maxChars) + "\n…(обрезано)" else text
        } catch (e: Throwable) {
            "(ошибка чтения: ${e.message})"
        }
    }
}
