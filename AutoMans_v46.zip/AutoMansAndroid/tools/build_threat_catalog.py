#!/usr/bin/env python3
"""Build a searchable threat catalog from the exported Null's Brawl CSV tables."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "reference_data"
OUT = DATA / "NullsBrawl_ThreatCatalog.json"


def read_rows(filename: str):
    """Read every CSV record while skipping the exporter's second, type-only row."""
    path = DATA / filename
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    type_words = {"string", "int", "boolean", "float", "bool", "long"}
    if rows:
        values = {(str(v or "").strip().lower()) for v in rows[0].values() if str(v or "").strip()}
        if values and values.issubset(type_words):
            rows = rows[1:]
    return rows


def load_table(filename: str, key: str):
    """Index entity tables by a unique name; audit tables must use read_rows()."""
    out = {}
    for row in read_rows(filename):
        name = (row.get(key) or "").strip()
        if not name:
            continue
        if (row.get("Disabled") or "").strip().lower() in {"true", "1", "yes"}:
            continue
        out[name] = row
    return out


def names(value):
    return [part.strip() for part in str(value or "").replace(",", ";").split(";") if part.strip()]


def number(row, field, default=0.0):
    try:
        value = float(str(row.get(field, "")).strip())
        return value if value == value and abs(value) != float("inf") else default
    except (ValueError, TypeError):
        return default


def truthy(value):
    return str(value or "").strip().lower() in {"true", "1", "yes"}


def main():
    characters = load_table("characters.csv", "Name")
    skills = load_table("skills.csv", "Name")
    projectiles = load_table("projectiles_logic.csv", "Name")
    areas = load_table("area_effects_logic.csv", "Name")
    threat_map = load_table("nulls_character_threat_map.csv", "CharacterName")
    # This is a relationship table, not an entity table: SourceFile repeats by design.
    # Keep rows as a list or all but one link per CSV will silently disappear.
    audit_rows = read_rows("nulls_reference_audit_clean.csv")
    missing = [r for r in audit_rows if (r.get("Result") or "").strip().upper() != "OK"]

    area_index = {}
    area_link_fields = (
        "ChainAreaEffect", "ChainAreaEffect2", "ChainAreaEffect3",
        "OverchargedChainAreaEffect", "OverchargedChainAreaEffect2",
        "OverchargedChainAreaEffect3", "ChildAreaEffect", "RelatedImmunityAreas",
    )
    for area_name, area in areas.items():
        radius = number(area, "Radius", 0)
        linked_areas = []
        for field in area_link_fields:
            linked_areas.extend(names(area.get(field)))
        area_index[area_name] = {
            "radius": radius,
            "duration_ms": number(area, "TimeMs", 0),
            "min_duration_ms": number(area, "MinTimeMs", 0),
            "type": (area.get("Type") or "").strip(),
            "affect_projectiles": truthy(area.get("AffectProjectiles")),
            "ignore_characters": truthy(area.get("IgnoreCharacters")),
            "linked_areas": list(dict.fromkeys(linked_areas)),
            "spawn_projectile": (area.get("BulletExplosionBullet") or "").strip(),
        }

    projectile_index = {}
    projectile_area_fields = (
        "SpawnAreaEffectObject", "SpawnAreaEffectObject2", "SpawnAreaEffectTrail",
        "OnCreateAreaEffect", "SpawnAreaEffectObjectsAdditional",
    )
    for projectile_name, projectile in projectiles.items():
        linked_areas = []
        for field in projectile_area_fields:
            linked_areas.extend(names(projectile.get(field)))
        projectile_index[projectile_name] = {
            "speed": number(projectile, "Speed", 0),
            "radius": number(projectile, "Radius", 0),
            "pre_explosion_ms": number(projectile, "PreExplosionTimeMs", 0),
            "trigger_delay_ms": number(projectile, "TriggerWithDelayMs", 0),
            "gravity": number(projectile, "Gravity", 0),
            "is_beam": truthy(projectile.get("IsBeam")),
            "is_homing": truthy(projectile.get("IsHomingMissile")) or truthy(projectile.get("IsFriendlyHomingMissile")),
            "is_bouncing": truthy(projectile.get("IsBouncing")),
            "pierces_characters": truthy(projectile.get("PiercesCharacters")),
            "pierces_environment": truthy(projectile.get("PiercesEnvironment")),
            "spawn_character": (projectile.get("SpawnCharacter") or "").strip(),
            "spawn_item": (projectile.get("SpawnItem") or "").strip(),
            "chain_projectile": (projectile.get("ChainBullet") or "").strip(),
            "linked_areas": list(dict.fromkeys(linked_areas)),
        }

    def skill_profile(skill_name):
        if not skill_name or skill_name not in skills:
            return None
        row = skills[skill_name]
        projectile_names = []
        for field in ("Projectiles", "OverchargedProjectiles", "OverchargedChainProjectile"):
            projectile_names.extend(names(row.get(field)))
        area_names = []
        for field in ("AreaEffectObject", "AreaEffectObject2", "OverchargedAreaEffectObject", "OverchargedAreaEffectObject2"):
            area_names.extend(names(row.get(field)))
        linked_skills = []
        for field in ("SecondarySkill", "SecondarySkill2", "SecondarySkill3", "SecondarySkill4"):
            linked_skills.extend(names(row.get(field)))
        summoned = []
        for field in ("SummonedCharacters", "OverchargedSummonedCharacters"):
            summoned.extend(names(row.get(field)))
        projectile_names = list(dict.fromkeys(projectile_names))
        area_names = list(dict.fromkeys(area_names))
        return {
            "name": skill_name,
            "behavior": (row.get("BehaviorType") or "").strip(),
            "range": number(row, "CastingRange", 0),
            "cast_ms": number(row, "CastingTime", 0),
            "active_ms": number(row, "ActiveTime", 0),
            "damage": number(row, "Damage", 0),
            "linked_skills": list(dict.fromkeys(linked_skills)),
            "summoned_characters": list(dict.fromkeys(summoned)),
            "projectiles": [
                {"name": name, **projectile_index[name]} for name in projectile_names if name in projectile_index
            ],
            "unresolved_projectiles": [name for name in projectile_names if name not in projectile_index],
            "areas": [
                {"name": name, **area_index[name]} for name in area_names if name in area_index
            ],
            "unresolved_areas": [name for name in area_names if name not in area_index],
        }

    character_index = {}
    for name, character in characters.items():
        attack = (character.get("WeaponSkill") or "").strip()
        ulti = (character.get("UltimateSkill") or "").strip()
        direct_proj = names(character.get("AutoAttackProjectile"))
        overcharged_direct_proj = names(character.get("OverchargedAutoAttackProjectile"))
        direct_area = names(character.get("AreaEffect")) + names(character.get("DeathAreaEffect")) + names(character.get("DeathOverchargedAreaEffect"))
        threat_row = threat_map.get(name, {})
        character_index[name] = {
            "item_name": (character.get("ItemName") or "").strip(),
            "movement_type": (character.get("MovementType") or "").strip(),
            "speed": number(character, "Speed", 0),
            "health": number(character, "Hitpoints", 0),
            "collision_radius": number(character, "CollisionRadius", 0),
            "weapon": skill_profile(attack),
            "ultimate": skill_profile(ulti),
            "overcharged_ultimate": skill_profile((character.get("OverchargedUltimateSkill") or "").strip()),
            "direct_projectiles": [
                {"name": p, **projectile_index[p]} for p in direct_proj if p in projectile_index
            ],
            "overcharged_direct_projectiles": [
                {"name": p, **projectile_index[p]} for p in overcharged_direct_proj if p in projectile_index
            ],
            "direct_areas": [
                {"name": a, **area_index[a]} for a in direct_area if a in area_index
            ],
            "unresolved_direct_projectiles": [p for p in direct_proj + overcharged_direct_proj if p not in projectile_index],
            "unresolved_direct_areas": [a for a in direct_area if a not in area_index],
            "mapped_weapon_projectiles": names(threat_row.get("WeaponProjectiles")),
            "mapped_ultimate_projectiles": names(threat_row.get("UltimateProjectiles")),
            "mapped_weapon_areas": names(threat_row.get("WeaponAreaEffects")),
            "mapped_ultimate_areas": names(threat_row.get("UltimateAreaEffects")),
        }

    catalog = {
        "schema_version": 1,
        "source": "User-provided Null's Brawl CSV exports",
        "runtime_note": "Metadata catalog only. The Android visual detector does not yet identify projectile names from pixels, so it cannot select these per-name profiles automatically.",
        "counts": {
            "characters": len(character_index), "skills": len(skills),
            "projectiles": len(projectile_index), "areas": len(area_index),
            "audit_links": len(audit_rows), "audit_ok": len(audit_rows) - len(missing),
            "audit_missing": len(missing),
        },
        "characters": character_index,
        "projectiles": projectile_index,
        "areas": area_index,
        "missing_links": [
            {"source_file": r.get("SourceFile", ""), "source_name": r.get("SourceName", ""),
             "source_field": r.get("SourceField", ""), "target_file": r.get("TargetFile", ""),
             "target_name": r.get("TargetName", ""), "result": r.get("Result", "")}
            for r in missing
        ],
    }
    OUT.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote {OUT}")
    print(json.dumps(catalog["counts"], ensure_ascii=False))

if __name__ == "__main__":
    main()
