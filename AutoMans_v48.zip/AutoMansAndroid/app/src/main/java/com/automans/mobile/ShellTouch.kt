package com.automans.mobile

import android.content.Context
import android.os.SystemClock
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.Writer
import kotlin.math.hypot

/**
 * Touch control through Shizuku (ADB rights): sees the player's fingers on the real touchscreen and adds
 * one more finger of its own in a spare slot. The player's own touches are never cancelled by it.
 */
object ShellTouch {
    @Volatile var ready = false
        private set
    @Volatile var rotation = 1
    @Volatile var screenW = 2340
    @Volatile var screenH = 1080

    private var panelW = 1080
    private var panelH = 2340
    private var proc: Process? = null
    private var writer: Writer? = null
    private val lock = Any()
    @Volatile private var starting = false
    /** "evdev" (writes into the touchscreen), "im" (injects Android touch events) or "ro" (only watches). */
    @Volatile var bridgeMode = ""
        private set
    private var sentRot = -1
    private var sentW = 0
    private var sentH = 0

    /** Player's fingers in panel coordinates: slot -> [x, y, downAtMs, downX, downY]. */
    private val fingers = HashMap<Int, DoubleArray>()
    @Volatile var onTap: ((Float, Float) -> Unit)? = null
    /** Called when a finger of the player went down or moved (from the bridge's reading thread). */
    @Volatile var onFinger: (() -> Unit)? = null
    /** Called when the bridge has made a shot by itself. */
    @Volatile var onShot: (() -> Unit)? = null
    @Volatile private var cfgLine = ""
    @Volatile private var cfgSentLine = ""
    /** When the player last touched, moved or lifted a finger on the left half (the move stick). */
    @Volatile private var lastLeftMs = 0L

    private fun leftFingerDown(): Boolean = synchronized(fingers) {
        fingers.values.any { toScreen(it[0].toFloat(), it[1].toFloat())[0] < screenW * 0.5f }
    }
    /** 0 while a finger rests on the left half; otherwise the time since the player last used it. */
    fun leftIdleMs(now: Long): Long = if (leftFingerDown()) 0L else now - lastLeftMs
    fun leftTouchedSince(t: Long): Boolean = lastLeftMs >= t || leftFingerDown()

    /** Why the bridge does not own the touchscreen (empty = nothing wrong, it just waits for a pause in the touches). */
    @Volatile var proxyNote = ""

    /** One short line for the notification: is the bridge up and does it own the touchscreen. */
    fun statusText(): String = when {
        !ready -> "ADB: не запущен"
        proxyActive -> "захват экрана: да"
        proxyNote.isNotEmpty() -> proxyNote
        else -> "захват экрана: ждёт паузы в касаниях"
    }

    /** True while the bridge owns the touchscreen (every touch goes through it, so nothing can undo our moves). */
    @Volatile var proxyActive = false
        private set
    @Volatile private var wantFlag = false
    @Volatile private var wantAt = 0L
    @Volatile private var beatGen = 0

    /** Called while the game is in front: asks the bridge to take the touchscreen over (and keeps asking); false gives it back. */
    fun wantProxy(on: Boolean) {
        val changed = on != wantFlag
        wantFlag = on
        if (on) wantAt = SystemClock.elapsedRealtime()
        if (changed && ready) send("P ${if (on) 1 else 0}")
    }

    fun stop() {
        beatGen++
        proxyActive = false
        synchronized(lock) {
            try { writer?.write("Q\n"); writer?.flush() } catch (ignored: Exception) { }
            try { proc?.destroy() } catch (ignored: Exception) { }
            writer = null
            proc = null
            ready = false
            cfgSentLine = ""
            fingers.clear()
        }
    }

    /** Call off the main thread. Returns a short human-readable status that is also written to the journal. */
    fun start(context: Context): String {
        if (ready || starting) return "уже запущено"
        starting = true
        try {
            if (!ShizukuBridge.hasPermission()) return log("Shizuku: нет разрешения")
            val info = ShizukuBridge.run("getevent -lp", 60000)
            val dev = parseDevice(info) ?: return log("тачскрин не найден в getevent")
            panelW = dev.maxX + 1
            panelH = dev.maxY + 1
            val is64 = android.os.Process.is64Bit()
            val apk = context.packageCodePath
            val extras = dev.extras.joinToString(",") { "${it[0]}=${it[1]}" }
            val cmd = "CLASSPATH=$apk exec app_process /system/bin com.automans.mobile.InputBridge " +
                "${dev.path} ${dev.maxSlot} ${if (is64) 24 else 16} \"$extras\" - \"${dev.name}\" 2>&1"
            val p = ShizukuBridge.start(arrayOf("sh", "-c", cmd)) ?: return log("не удалось запустить мост")
            val rd = BufferedReader(InputStreamReader(p.inputStream))
            val latch = java.util.concurrent.CountDownLatch(1)
            val gotReady = java.util.concurrent.atomic.AtomicBoolean(false)
            val firstLines = StringBuffer()
            // blocking reads in their own thread: a remote pipe from Shizuku never reports "ready"
            Thread {
                try {
                    while (true) {
                        val line = rd.readLine() ?: break
                        if (!gotReady.get()) {
                            if (line.trim().startsWith("READY")) {
                                bridgeMode = line.trim().removePrefix("READY").trim()
                                synchronized(lock) {
                                    proc = p
                                    writer = OutputStreamWriter(p.outputStream)
                                    ready = true
                                }
                                gotReady.set(true)
                                latch.countDown()
                            } else {
                                if (firstLines.length < 600) firstLines.append(line).append(" | ")
                                if (line.startsWith("INF") || line.startsWith("ERR")) AimLog.add("ADB: $line")
                            }
                        } else handleLine(line)
                    }
                } catch (ignored: Throwable) {
                } finally {
                    if (!gotReady.get()) firstLines.append("(поток закрылся)")
                    ready = false
                    proxyActive = false
                    latch.countDown()
                }
            }.also { it.isDaemon = true }.start()
            latch.await(15, java.util.concurrent.TimeUnit.SECONDS)
            if (!ready) {
                try { p.destroy() } catch (ignored: Exception) { }
                return log("мост не стартовал: $firstLines")
            }
            cfgSentLine = ""
            syncGeometry(true)
            // every second: "I am alive, I do / do not want the screen"; without it the bridge gives the screen back to the system
            val gen = ++beatGen
            Thread {
                while (ready && gen == beatGen) {
                    val w = wantFlag && SystemClock.elapsedRealtime() - wantAt < 1500L
                    send("P ${if (w) 1 else 0}")
                    val cl = cfgLine
                    if (cl.isNotEmpty()) send(cl)
                    try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
                }
            }.also { it.isDaemon = true }.start()
            return log("ADB-касания готовы (режим $bridgeMode): ${dev.path} ${dev.name} ${panelW}x$panelH слотов ${dev.maxSlot + 1}")
        } catch (e: Throwable) {
            return log("ошибка запуска: ${e.message}")
        } finally {
            starting = false
        }
    }

    private fun log(s: String): String { AimLog.add("ADB: $s"); return s }

    private class Dev(val path: String, val name: String, val maxX: Int, val maxY: Int, val maxSlot: Int, val extras: List<IntArray>)

    private fun parseDevice(text: String): Dev? {
        val blocks = text.split("add device ")
        for (b in blocks) {
            if (!b.contains("INPUT_PROP_DIRECT") || !b.contains("ABS_MT_POSITION_X")) continue
            val path = Regex("(/dev/input/event\\d+)").find(b)?.value ?: continue
            fun maxOf(axis: String): Int? =
                Regex("$axis\\s*:.*?max\\s+(\\d+)").find(b)?.groupValues?.get(1)?.toIntOrNull()
            val mx = maxOf("ABS_MT_POSITION_X") ?: continue
            val my = maxOf("ABS_MT_POSITION_Y") ?: continue
            val slot = (maxOf("ABS_MT_SLOT") ?: 9).coerceIn(2, 31)
            val extras = ArrayList<IntArray>()
            maxOf("ABS_MT_PRESSURE")?.let { extras.add(intArrayOf(0x3a, (it / 3).coerceAtLeast(1))) }
            maxOf("ABS_MT_TOUCH_MAJOR")?.let { extras.add(intArrayOf(0x30, (it / 4).coerceAtLeast(1))) }
            maxOf("ABS_MT_TOUCH_MINOR")?.let { extras.add(intArrayOf(0x31, (it / 4).coerceAtLeast(1))) }
            maxOf("ABS_MT_WIDTH_MAJOR")?.let { extras.add(intArrayOf(0x32, (it / 4).coerceAtLeast(1))) }
            val name = Regex("name:\\s+\"([^\"]*)\"").find(b)?.groupValues?.get(1) ?: ""
            return Dev(path, name, mx, my, slot, extras)
        }
        return null
    }

    private fun handleLine(line: String) {
        var t0Finger = false
        run {
            run {
                val t = line.trim().split(' ')
                if (t.isEmpty()) return
                if (t[0] == "GRAB") {
                    proxyActive = t.size >= 2 && t[1] == "1"
                    if (proxyActive) proxyNote = ""
                    AimLog.add("ADB: захват экрана " + if (proxyActive) "включён" else "снят")
                    return
                }
                if (t[0] == "ERR" || t[0] == "INF") {
                    if (line.contains("захват экрана не удался")) proxyNote = "захват экрана: НЕТ (система не разрешила)"
                    else if (line.contains("захват снят: события не доходят")) proxyNote = "захват экрана: НЕТ (события не доходят)"
                    AimLog.add("ADB: $line")
                    return
                }
                if (t[0] == "NOSHOT") { AimLog.add("ПОМОЩЬ: " + line.trim().removePrefix("NOSHOT").trim()); return }
                if (t[0] == "SHOT") {
                    // SHOT ok slot dist lead speed perp tol picAge fingerAge
                    if (t.size >= 10) {
                        AimLog.add("ВЫСТРЕЛ: враг ${t[3]} px, упреждение ${t[4]} px, скорость врага ${t[5]} px/с, линия прошла в ${t[6]} px от него (допуск ${t[7]}), картинке ${t[8]} мс, отчёту пальца ${t[9]} мс, ход ${if (t[1] == "1") "ок" else "ОШИБКА"}")
                    }
                    if (t.size < 2 || t[1] == "1") { try { onShot?.invoke() } catch (ignored: Throwable) { } }
                    return
                }
                t0Finger = t[0] == "D" || t[0] == "M"
                val now = SystemClock.elapsedRealtime().toDouble()
                synchronized(fingers) {
                    when (t[0]) {
                        "D" -> if (t.size >= 4) {
                            val x = t[2].toDouble(); val y = t[3].toDouble()
                            fingers[t[1].toInt()] = doubleArrayOf(x, y, now, x, y, x, y, now, now)
                            if (toScreen(x.toFloat(), y.toFloat())[0] < screenW * 0.5f) lastLeftMs = now.toLong()
                        }
                        "M" -> if (t.size >= 4) {
                            fingers[t[1].toInt()]?.let {
                                it[5] = it[0]; it[6] = it[1]; it[7] = it[8]
                                it[0] = t[2].toDouble(); it[1] = t[3].toDouble(); it[8] = now
                            }
                            if (toScreen(t[2].toFloat(), t[3].toFloat())[0] < screenW * 0.5f) lastLeftMs = now.toLong()
                        }
                        "U" -> if (t.size >= 2) {
                            val f = fingers.remove(t[1].toInt())
                            if (f != null && toScreen(f[0].toFloat(), f[1].toFloat())[0] < screenW * 0.5f) lastLeftMs = now.toLong()
                            if (f != null && now - f[2] < 350.0 && hypot(f[0] - f[3], f[1] - f[4]) < panelW * 0.04) {
                                val s = toScreen(f[3].toFloat(), f[4].toFloat())
                                try { onTap?.invoke(s[0], s[1]) } catch (ignored: Throwable) { }
                            }
                        }
                    }
                }
            }
        }
        if (t0Finger) { try { onFinger?.invoke() } catch (ignored: Throwable) { } }
    }

    /**
     * The move joystick as a vector (screen direction x strength 0..1): the finger that went down on the left half,
     * measured from where it first touched. Zero when the player is standing still.
     */
    fun moveVector(minDim: Float): FloatArray {
        var best: DoubleArray? = null
        synchronized(fingers) {
            for (f in fingers.values) {
                val d = toScreen(f[3].toFloat(), f[4].toFloat())
                if (d[0] >= screenW * 0.5f) continue
                if (best == null || f[2] < best!![2]) best = f
            }
            val f = best ?: return floatArrayOf(0f, 0f)
            val a = toScreen(f[3].toFloat(), f[4].toFloat())
            val b = toScreen(f[0].toFloat(), f[1].toFloat())
            val dx = b[0] - a[0]
            val dy = b[1] - a[1]
            val len = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (len < minDim * 0.012f) return floatArrayOf(0f, 0f)
            val strength = (len / (minDim * 0.07f)).coerceAtMost(1f)
            return floatArrayOf(dx / len * strength, dy / len * strength)
        }
    }

    /** True when one of the player's fingers is within radiusPx of the screen point (x, y). */
    fun fingerNear(x: Float, y: Float, radiusPx: Float): Boolean {
        synchronized(fingers) {
            for (f in fingers.values) {
                val s = toScreen(f[0].toFloat(), f[1].toFloat())
                if (hypot((s[0] - x).toDouble(), (s[1] - y).toDouble()) <= radiusPx) return true
            }
        }
        return false
    }

    private fun toScreen(px: Float, py: Float): FloatArray {
        val w = screenW.toFloat(); val h = screenH.toFloat()
        val fx = px / panelW; val fy = py / panelH
        return when (rotation) {
            1 -> floatArrayOf(fy * w, (1f - fx) * h)
            3 -> floatArrayOf((1f - fy) * w, fx * h)
            2 -> floatArrayOf((1f - fx) * w, (1f - fy) * h)
            else -> floatArrayOf(fx * w, fy * h)
        }
    }

    private fun toPanel(sx: Float, sy: Float): IntArray {
        val fx = (sx / screenW).coerceIn(0f, 1f); val fy = (sy / screenH).coerceIn(0f, 1f)
        val (u, v) = when (rotation) {
            1 -> Pair(1f - fy, fx)
            3 -> Pair(fy, 1f - fx)
            2 -> Pair(1f - fx, 1f - fy)
            else -> Pair(fx, fy)
        }
        return intArrayOf((u * (panelW - 1)).toInt(), (v * (panelH - 1)).toInt())
    }

    /** Tells the bridge how the screen is turned, so it can convert panel coordinates to screen coordinates. */
    fun syncGeometry(force: Boolean = false) {
        if (!force && sentRot == rotation && sentW == screenW && sentH == screenH) return
        if (send("T $rotation $screenW $screenH $panelW $panelH")) { sentRot = rotation; sentW = screenW; sentH = screenH }
    }

    private fun send(line: String): Boolean {
        synchronized(lock) {
            val w = writer ?: return false
            return try { w.write(line); w.write("\n"); w.flush(); true } catch (e: Exception) { ready = false; false }
        }
    }

    /**
     * The player's finger that went down on the attack stick: [slot, x, y, downAtMs] in screen pixels, or null.
     */
    fun attackFinger(baseX: Float, baseY: Float, radius: Float): DoubleArray? {
        synchronized(fingers) {
            var best: DoubleArray? = null
            var bestSlot = -1
            for ((slot, f) in fingers) {
                val d = toScreen(f[3].toFloat(), f[4].toFloat())
                if (hypot((d[0] - baseX).toDouble(), (d[1] - baseY).toDouble()) > radius * 1.6) continue
                if (best == null || f[2] < best!![2]) { best = f; bestSlot = slot }
            }
            val f = best ?: return null
            val now = toScreen(f[0].toFloat(), f[1].toFloat())
            // how fast the finger moves (screen px/s, from its last two reports) and how old its last report is
            val prev = toScreen(f[5].toFloat(), f[6].toFloat())
            val dtp = f[8] - f[7]
            var vx = 0.0
            var vy = 0.0
            if (dtp in 2.0..40.0) { vx = (now[0] - prev[0]) / dtp * 1000.0; vy = (now[1] - prev[1]) / dtp * 1000.0 }
            val age = (SystemClock.elapsedRealtime() - f[8]).coerceAtLeast(0.0)
            return doubleArrayOf(bestSlot.toDouble(), now[0].toDouble(), now[1].toDouble(), f[2], vx, vy, age)
        }
    }

    private fun appendF(sb: StringBuilder, v: Float) {
        val r = Math.round(v * 10f)
        if (r < 0) sb.append('-')
        val a = Math.abs(r)
        sb.append(a / 10).append('.').append(a % 10)
    }

    /** Hands the shot settings (attack button place and size, range, lobbed or not, on/off) to the bridge when they change. */
    fun assistConfig(c: AssistCore.Cfg) {
        val sb = StringBuilder(80).append("C ")
        appendF(sb, c.bx); sb.append(' '); appendF(sb, c.by); sb.append(' '); appendF(sb, c.radius); sb.append(' ')
        appendF(sb, c.minDim); sb.append(' '); appendF(sb, c.rangePx); sb.append(' ')
        sb.append(if (c.lobbed) 1 else 0).append(' ').append(if (c.on) 1 else 0)
        val line = sb.toString()
        cfgLine = line
        if (line != cfgSentLine && send(line)) cfgSentLine = line
    }

    /** Hands the enemies of the newest picture (and how old it is) to the bridge, which decides about the shot by itself. */
    fun assistFrame(ageMs: Float, sn: EnemyAutoAim.Snapshot) {
        val n = sn.n.coerceAtMost(12)
        val sb = StringBuilder(48 + n * AssistCore.STRIDE * 8)
        sb.append("E ").append(ageMs.toInt()).append(' ')
        appendF(sb, sn.originX); sb.append(' '); appendF(sb, sn.originY); sb.append(' ').append(n)
        for (i in 0 until n * AssistCore.STRIDE) { sb.append(' '); appendF(sb, sn.d[i]) }
        send(sb.toString())
    }

    /** Moves the player's own finger to (sx, sy) and lifts it there: one shot at the new aim. */
    fun fire(slot: Int, sx: Float, sy: Float): Boolean {
        val p = toPanel(sx, sy)
        synchronized(fingers) { fingers.remove(slot) }
        return send("F $slot ${p[0]} ${p[1]}")
    }

    /** True when the bridge can take the move stick over from the player's own finger (injected-events mode). */
    fun canTake(): Boolean = ready && bridgeMode == "im"
    fun takeStart(sx: Float, sy: Float): Boolean { val p = toPanel(sx, sy); return send("G ${p[0]} ${p[1]}") }
    fun takeSteer(sx: Float, sy: Float): Boolean { val p = toPanel(sx, sy); return send("S ${p[0]} ${p[1]}") }
    fun takeEnd(): Boolean = send("H")

    /** The player's move finger (earliest finger on the left half): [x, y, downX, downY] in screen pixels, or null. */
    fun leftFinger(): FloatArray? {
        synchronized(fingers) {
            var best: DoubleArray? = null
            for (f in fingers.values) {
                val d = toScreen(f[3].toFloat(), f[4].toFloat())
                if (d[0] >= screenW * 0.5f) continue
                if (best == null || f[2] < best!![2]) best = f
            }
            val f = best ?: return null
            val a = toScreen(f[0].toFloat(), f[1].toFloat())
            val b = toScreen(f[3].toFloat(), f[4].toFloat())
            return floatArrayOf(a[0], a[1], b[0], b[1])
        }
    }

    fun fingerCount(): Int = synchronized(fingers) { fingers.size }

    fun down(sx: Float, sy: Float): Boolean { val p = toPanel(sx, sy); return send("D ${p[0]} ${p[1]}") }
    fun move(sx: Float, sy: Float): Boolean { val p = toPanel(sx, sy); return send("M ${p[0]} ${p[1]}") }
    fun up(): Boolean = send("U")
}
